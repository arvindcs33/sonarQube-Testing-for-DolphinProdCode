package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;
import com.dolphin.cdcDataMigration.util.MethodUtil;

public class PclientDAO {
	

	 private final Logger logger=LoggerFactory.getLogger(DolphinAppCaseDAO.class);
		
		@Autowired
		DolphinConfiguration dolphinConfiguration;


	public boolean getPcliIdExistOrNot(String wiName) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_CASE_ID3);
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	if(wiNameInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,wiNameInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("SELECT_CASE_ID2 Exist or Not Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}

	public void insert_NG_NB_PROPOSER_DETAILS(String wiName, String proposer, String occupation, String middleName,
			String firstName, String lastName, String dateOfBirth, String gender, String typeOfVisa,
			String prefMailAddress, String idProofProp, String nationality, String natureOfDuties, String maritalStatus,
			String title, String emailId, String exactIncome, String dobProof, String addrProofProp, String clientId,
			String politicalExp, String preferredLanguage, String education, String industryType, String panNumber,
			String eiaNoAvailable, String eiaNoAvailable2, String eiaNumber, String repository, String neftBankAccNo,
			String dateOfIncor, String fatherNameHusbandName, String countryResidingIn, String organizationType,
			String annuityOption, String aadhaarNumber, String aadhaarEnrolNo) {
		
	
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_PROPOSER_DETAILS2);
	        //---------------------------: Number :----------------------------------
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	        Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	        Integer preferredLanguageInt=MethodUtil.StringToIntConverter(preferredLanguage);
	        Integer eiaNumberInt=MethodUtil.StringToIntConverter(eiaNumber);
	      //---------------------------: Date :----------------------------------
	        Long dateOfBirthInt=MethodUtil.StringToLongConverter(dateOfBirth);
	        Long dateOfIncorInt=MethodUtil.StringToLongConverter(dateOfIncor);
	          
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter++,proposer);
	        pstmt.setString(counter++,occupation);
	        pstmt.setString(counter++,middleName);
	        pstmt.setString(counter++,firstName);
	        pstmt.setString(counter++,lastName);
	        
	        if(dateOfBirthInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfBirthInt));
	        }
	        
	        pstmt.setString(counter++,gender);
	        pstmt.setString(counter++,typeOfVisa);
	        pstmt.setString(counter++,prefMailAddress);
	        pstmt.setString(counter++,idProofProp);
	        pstmt.setString(counter++,nationality);
	        pstmt.setString(counter++,natureOfDuties);
	        
	        if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }
	        
	        pstmt.setString(counter++,title);
	        pstmt.setString(counter++,emailId);
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	        
	        if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }
	        
	        pstmt.setString(counter++,addrProofProp);
	        pstmt.setString(counter++,clientId);
	        pstmt.setString(counter++,politicalExp);
	        
	        if(preferredLanguageInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, preferredLanguageInt);
			    }
	        
	        pstmt.setString(counter++,education);
	        pstmt.setString(counter++,industryType);
	        pstmt.setString(counter++,panNumber);
	        pstmt.setString(counter++,eiaNoAvailable);
	        pstmt.setString(counter++,eiaNoAvailable2);
	        
	        if(eiaNumberInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, eiaNumberInt);
			    }
	        
	        pstmt.setString(counter++,repository);
	        pstmt.setString(counter++,neftBankAccNo);
	        
	        if(dateOfIncorInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfIncorInt));
	        }
	        
	        pstmt.setString(counter++,fatherNameHusbandName);
	        pstmt.setString(counter++,countryResidingIn);
	        pstmt.setString(counter++,organizationType);
	        pstmt.setString(counter++,annuityOption);
	        pstmt.setString(counter++,aadhaarNumber);
	        pstmt.setString(counter++,aadhaarEnrolNo);
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_PROPOSER_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		
	}


	public void update_NG_NB_PROPOSER_DETAILS(String wiName, String proposer, String occupation, String middleName,
			String firstName, String lastName, String dateOfBirth, String gender, String typeOfVisa,
			String prefMailAddress, String idProofProp, String nationality, String natureOfDuties, String maritalStatus,
			String title, String emailId, String exactIncome, String dobProof, String addrProofProp, String clientId,
			String politicalExp, String preferredLanguage, String education, String industryType, String panNumber,
			String eiaNoAvailable, String eiaNoAvailable2, String eiaNumber, String repository, String neftBankAccNo,
			String dateOfIncor, String fatherNameHusbandName, String countryResidingIn, String organizationType,
			String annuityOption, String aadhaarNumber, String aadhaarEnrolNo) {
		

		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_PROPOSER_DETAILS2);
	        //---------------------------: Number :----------------------------------
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	        Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	        Integer preferredLanguageInt=MethodUtil.StringToIntConverter(preferredLanguage);
	        Integer eiaNumberInt=MethodUtil.StringToIntConverter(eiaNumber);
	      //---------------------------: Date :----------------------------------
	        Long dateOfBirthInt=MethodUtil.StringToLongConverter(dateOfBirth);
	        Long dateOfIncorInt=MethodUtil.StringToLongConverter(dateOfIncor);
	          
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter++,proposer);
	        pstmt.setString(counter++,occupation);
	        pstmt.setString(counter++,middleName);
	        pstmt.setString(counter++,firstName);
	        pstmt.setString(counter++,lastName);
	        
	        if(dateOfBirthInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfBirthInt));
	        }
	        
	        pstmt.setString(counter++,gender);
	        pstmt.setString(counter++,typeOfVisa);
	        pstmt.setString(counter++,prefMailAddress);
	        pstmt.setString(counter++,idProofProp);
	        pstmt.setString(counter++,nationality);
	        pstmt.setString(counter++,natureOfDuties);
	        
	        if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }
	        
	        pstmt.setString(counter++,title);
	        pstmt.setString(counter++,emailId);
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	        
	        if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }
	        
	        pstmt.setString(counter++,addrProofProp);
	        pstmt.setString(counter++,clientId);
	        pstmt.setString(counter++,politicalExp);
	        
	        if(preferredLanguageInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, preferredLanguageInt);
			    }
	        
	        pstmt.setString(counter++,education);
	        pstmt.setString(counter++,industryType);
	        pstmt.setString(counter++,panNumber);
	        pstmt.setString(counter++,eiaNoAvailable);
	        pstmt.setString(counter++,eiaNoAvailable2);
	        
	        if(eiaNumberInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, eiaNumberInt);
			    }
	        
	        pstmt.setString(counter++,repository);
	        pstmt.setString(counter++,neftBankAccNo);
	        
	        if(dateOfIncorInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfIncorInt));
	        }
	        
	        pstmt.setString(counter++,fatherNameHusbandName);
	        pstmt.setString(counter++,countryResidingIn);
	        pstmt.setString(counter++,organizationType);
	        pstmt.setString(counter++,annuityOption);
	        pstmt.setString(counter++,aadhaarNumber);
	        pstmt.setString(counter++,aadhaarEnrolNo);
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_PROPOSER_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	
		
	}

	public void insert_NG_NB_POLICY_VALIDATION_DETAILS(String wiName, String creditScore, String incomeSegment) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_POLICY_VALIDATION_DETAILS2);
	        
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer creditScoreInt=MethodUtil.StringToIntConverter(creditScore);
	        Integer incomeSegmentInt=MethodUtil.StringToIntConverter(incomeSegment);
	        
	        
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        if(creditScoreInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, creditScoreInt);
			    }
	        
	        if(incomeSegmentInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, incomeSegmentInt);
			    }
	        
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_POLICY_VALIDATION_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
			
	}

	public void update_NG_NB_POLICY_VALIDATION_DETAILS(String wiName, String creditScore, String incomeSegment) {

		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_POLICY_VALIDATION_DETAILS2);
	        
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer creditScoreInt=MethodUtil.StringToIntConverter(creditScore);
	        Integer incomeSegmentInt=MethodUtil.StringToIntConverter(incomeSegment);
	        
	        
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        if(creditScoreInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, creditScoreInt);
			    }
	        
	        if(incomeSegmentInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, incomeSegmentInt);
			    }
	        
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_POLICY_VALIDATION_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		
	}

	public void insert_NG_NB_L2BI_DETAILS(String wiName, String insured, String occupation, String middleName,
			String firstName, String lastName, String dob, String gender, String typeOfVisa, String nationality,
			String natureOfDuties, String maritalStatus, String incomeSource, String title, String emailId,
			String exactIncome, String dobProof, String clientId, String relationshipWithProposer, String education,
			String industryType, String fatherNameHusbandName, String organizationType) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_L2BI_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer incomeSourceInt=MethodUtil.StringToIntConverter(incomeSource);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	        Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	          
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter++,insured);
	        pstmt.setString(counter++,occupation);
	        pstmt.setString(counter++,middleName);
	        pstmt.setString(counter++,firstName);
	        pstmt.setString(counter++,lastName);
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	        pstmt.setString(counter++,gender);
	        pstmt.setString(counter++,typeOfVisa);
	        pstmt.setString(counter++,nationality);
	        pstmt.setString(counter++,natureOfDuties);
	        
	        if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }
	        
	        if(incomeSourceInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, incomeSourceInt);
			    }
	        
	        pstmt.setString(counter++,title);
	        pstmt.setString(counter++,emailId);
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	        
	        if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }
	        
	        pstmt.setString(counter++,clientId);
	        pstmt.setString(counter++,relationshipWithProposer);
	        pstmt.setString(counter++,education);
	        pstmt.setString(counter++,industryType);
	        pstmt.setString(counter++,fatherNameHusbandName);
	        pstmt.setString(counter++,organizationType);
	      
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_L2BI_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
			
	}

	public void update_NG_NB_L2BI_DETAILS(String wiName, String insured, String occupation, String middleName,
			String firstName, String lastName, String dob, String gender, String typeOfVisa, String nationality,
			String natureOfDuties, String maritalStatus, String incomeSource, String title, String emailId,
			String exactIncome, String dobProof, String clientId, String relationshipWithProposer, String education,
			String industryType, String fatherNameHusbandName, String organizationType) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_L2BI_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer incomeSourceInt=MethodUtil.StringToIntConverter(incomeSource);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	        Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	          
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter++,insured);
	        pstmt.setString(counter++,occupation);
	        pstmt.setString(counter++,middleName);
	        pstmt.setString(counter++,firstName);
	        pstmt.setString(counter++,lastName);
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	        pstmt.setString(counter++,gender);
	        pstmt.setString(counter++,typeOfVisa);
	        pstmt.setString(counter++,nationality);
	        pstmt.setString(counter++,natureOfDuties);
	        
	        if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }
	        
	        if(incomeSourceInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, incomeSourceInt);
			    }
	        
	        pstmt.setString(counter++,title);
	        pstmt.setString(counter++,emailId);
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	        
	        if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }
	        
	        pstmt.setString(counter++,clientId);
	        pstmt.setString(counter++,relationshipWithProposer);
	        pstmt.setString(counter++,education);
	        pstmt.setString(counter++,industryType);
	        pstmt.setString(counter++,fatherNameHusbandName);
	        pstmt.setString(counter++,organizationType);
	      
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_L2BI_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void insert_NG_NB_LIST_NOMINEE_DETAILS(String wiName, String nominee, String middleName, String firstName,
			String lastName, String dob, String gender, String relationshipProposer, String nationality,
			String percentage, String title, String emailId, String clientId, String education, String industryType,
			String panNumber, String reasonForNomination) {

		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_NOMINEE_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	          
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter++,nominee);
	        pstmt.setString(counter++,middleName);
	        pstmt.setString(counter++,firstName);
	        pstmt.setString(counter++,lastName);
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	        pstmt.setString(counter++,gender);
	        pstmt.setString(counter++,relationshipProposer);
	        pstmt.setString(counter++,nationality);
	        pstmt.setString(counter++,percentage);
	        pstmt.setString(counter++,title);
	        pstmt.setString(counter++,emailId);
	    
	        pstmt.setString(counter++,clientId);
	        pstmt.setString(counter++,education);
	        pstmt.setString(counter++,industryType);
	        pstmt.setString(counter++,panNumber);
	        pstmt.setString(counter++,reasonForNomination);
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_LIST_NOMINEE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_NG_NB_LIST_NOMINEE_DETAILS(String wiName, String nominee, String middleName, String firstName,
			String lastName, String dob, String gender, String relationshipProposer, String nationality,
			String percentage, String title, String emailId, String clientId, String education, String industryType,
			String panNumber, String reasonForNomination) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_NOMINEE_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	          
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter++,nominee);
	        pstmt.setString(counter++,middleName);
	        pstmt.setString(counter++,firstName);
	        pstmt.setString(counter++,lastName);
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	        pstmt.setString(counter++,gender);
	        pstmt.setString(counter++,relationshipProposer);
	        pstmt.setString(counter++,nationality);
	        pstmt.setString(counter++,percentage);
	        pstmt.setString(counter++,title);
	        pstmt.setString(counter++,emailId);
	    
	        pstmt.setString(counter++,clientId);
	        pstmt.setString(counter++,education);
	        pstmt.setString(counter++,industryType);
	        pstmt.setString(counter++,panNumber);
	        pstmt.setString(counter++,reasonForNomination);
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_LIST_NOMINEE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	
	}

}
