package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.serviceImpl.DolphinTablesTopicListener;
import com.dolphin.cdcDataMigration.util.DPHConstants;

@Service
public class DolphinCustomerDeclarationDAO {

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	private final Logger logger = LoggerFactory.getLogger(DolphinCustomerDeclarationDAO.class);
	
	public boolean getAppCaseExistOrNot(String wiName) {
		
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_CUSTOMER_DECLARATION);
	    	pstmt.setString(counter, wiName);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		return returnOut;
	}
	
	public void insert_NG_NB_CUSTOMER_INFORMATION(String customerId,String caseId,String customerSignDate,String custId,String replacePolicySale,String custClassification) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_CUSTOMER_INFORMATION);
	    	if("null".equals(customerId)) {
	    	pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    	pstmt.setInt(counter++, Integer.parseInt(customerId));
	    	}
	    	
	    	if("null".equals(caseId)) {
	    	pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    	pstmt.setInt(counter++, Integer.parseInt(caseId));
	    	}
	    	
	    	
	    	pstmt.setString(counter++, customerSignDate);
	    	pstmt.setString(counter++, custId);
	    	pstmt.setString(counter++, replacePolicySale);
	    	pstmt.setString(counter++, custClassification);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CUSTOMER_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_CUSTOMER_INFORMATION(String customerId,String caseId,String customerSignDate,String custId,String replacePolicySale,String custClassification) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_CUSTOMER_INFORMATION);
			if("null".equals(customerId)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    	}else {
		    	pstmt.setInt(counter++, Integer.parseInt(customerId));
		    	}
	        pstmt.setString(counter++, customerSignDate);
	        pstmt.setString(counter++, custId);
	        pstmt.setString(counter++, replacePolicySale);
	        pstmt.setString(counter++, custClassification);
	        if("null".equals(caseId)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(caseId));
		    }
		    	
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CUSTOMER_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String caseId,String mnylSSNCode,String mnylApplicationID,String solId,String agentSignDate,String wmsSerialNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_CD_NG_NB_AGENT_INFORMATION);
	    	if("null".equals(caseId)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(caseId));
		    }
	    	pstmt.setString(counter++, mnylSSNCode);
	    	pstmt.setString(counter++, mnylApplicationID);
	    	pstmt.setString(counter++, solId);
	    	pstmt.setString(counter++, agentSignDate);
	    	pstmt.setString(counter++, wmsSerialNumber);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String caseId,String mnylSSNCode,String mnylApplicationID,String solId,String agentSignDate,String wmsSerialNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.UPDATE_CD_NG_NB_AGENT_INFORMATION);
	        pstmt.setString(counter++, mnylSSNCode);
	        pstmt.setString(counter++, mnylApplicationID);
	        pstmt.setString(counter++, solId);
	        pstmt.setString(counter++, agentSignDate);
	        pstmt.setString(counter++, wmsSerialNumber);
	        if("null".equals(caseId)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(caseId));
		    }
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
}
