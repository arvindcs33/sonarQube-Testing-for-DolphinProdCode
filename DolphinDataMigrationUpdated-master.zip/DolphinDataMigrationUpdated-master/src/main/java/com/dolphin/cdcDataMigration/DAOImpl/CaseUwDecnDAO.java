package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;
import com.dolphin.cdcDataMigration.util.MethodUtil;

public class CaseUwDecnDAO {

	 private final Logger logger=LoggerFactory.getLogger(DolphinAppCaseDAO.class);
		
		@Autowired
		DolphinConfiguration dolphinConfiguration;

	    public boolean getCaseIdExistOrNot(String wiName) {
	    	boolean returnOut=false;
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
		    	int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.SELECT_CASE_ID2);
		    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
		    	if(wiNameInt==null) {
		    		return false;
			    }else {
			    	pstmt.setInt(counter,wiNameInt);
		    	}
		    	ResultSet rset=pstmt.executeQuery();
		    	if(rset.next()) {
		    		returnOut=true;
		    	}
		    }catch(Exception ec) {
		    	logger.error("SELECT_CASE_ID2 Exist or Not Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
			return returnOut;
	    }

	    public void insert_NG_NB_DECISION_SECTION_UW(String wiName, String smokerClassRevised, String totalPremium,
			String assessedIncome) {

			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_DECISION_SECTION_UW);
		        
		        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
		        Integer totalPremiumInt=MethodUtil.StringToIntConverter(totalPremium);
		        
		        if(wiNameInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, wiNameInt);
			    }
		        
		        pstmt.setString(counter++,smokerClassRevised);
		        
		        if(totalPremiumInt==null) {
				      pstmt.setNull(counter++, Types.INTEGER);	
				    }else {
				      pstmt.setInt(counter++, totalPremiumInt);
				    }
		        
		        pstmt.setString(counter++,assessedIncome);
		        
		        pstmt.execute();
		        
			}catch(Exception ec) {
		    	logger.error("INSERT_NG_NB_DECISION_SECTION_UW Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		
		
	     }

	     public void update_NG_NB_DECISION_SECTION_UW(String wiName, String smokerClassRevised, String totalPremium,
			String assessedIncome) {

				Connection conn=null;
			    PreparedStatement pstmt=null;
				try {
					int counter=1;
			    	conn= dolphinConfiguration.getDolphinConnection();
			        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_DECISION_SECTION_UW);
			        
			        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			        Integer totalPremiumInt=MethodUtil.StringToIntConverter(totalPremium);
			        
			        if(wiNameInt==null) {
				      pstmt.setNull(counter++, Types.INTEGER);	
				    }else {
				      pstmt.setInt(counter++, wiNameInt);
				    }
			        
			        pstmt.setString(counter++,smokerClassRevised);
			        
			        if(totalPremiumInt==null) {
					      pstmt.setNull(counter++, Types.INTEGER);	
					    }else {
					      pstmt.setInt(counter++, totalPremiumInt);
					    }
			        
			        pstmt.setString(counter++,assessedIncome);
			        
			        pstmt.execute();
			        
				}catch(Exception ec) {
			    	logger.error("UPDATE_NG_NB_DECISION_SECTION_UW Error",ec);
			    }
			    finally {
			    	if(conn!=null) {
			    		try {
			    		conn.close();
			    		}catch(Exception ec) {
			    			logger.error("error while closing the connection",ec);
			    		}
			    		
			    	}
			    	if(pstmt!=null) {
			    	    try {
			    		   pstmt.close();
				    	}catch(Exception ec) {
				    		logger.error("error while closing the connection",ec);
				    	}
			    	}
			    }
				
		
	     }

}
