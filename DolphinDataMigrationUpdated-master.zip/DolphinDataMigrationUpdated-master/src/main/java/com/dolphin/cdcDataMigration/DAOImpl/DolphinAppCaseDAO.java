package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ResourceProperties.Strategy;
import org.springframework.stereotype.Service;
import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.serviceImpl.DolphinTablesTopicListener;
import com.dolphin.cdcDataMigration.util.DPHConstants;

@Service
public class DolphinAppCaseDAO {

	private final Logger logger = LoggerFactory.getLogger(DolphinAppCaseDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean getAppCaseExistOrNot(String wiName) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_APP_CASE);
	    	pstmt.setString(counter, wiName);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	public void insert_NG_NB_CEIP_DETAILS(String bdmID,String enrollerID,String finderID,String businessType,String companyName,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_CEIP_DETAILS);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, bdmID);
	    	pstmt.setString(counter++, enrollerID);
	    	pstmt.setString(counter++, finderID);
	    	pstmt.setString(counter++, businessType);
	    	pstmt.setString(counter++, companyName);
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_CEIP_DETAILS(String bdmID,String enrollerID,String finderID,String businessType,String companyName,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_CEIP_DETAILS);
	    	pstmt.setString(counter++, bdmID);
	    	pstmt.setString(counter++, enrollerID);
	    	pstmt.setString(counter++, finderID);
	    	pstmt.setString(counter++, businessType);
	    	pstmt.setString(counter++, companyName);
	    	pstmt.setString(counter++, wiName);
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void insert_NG_NB_EXT_TABLE(String wiName,String planName,String channel,String workStatus,String l2BiName,String priorityType,String medNonMed) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_TABLE);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, planName);
	    	pstmt.setString(counter++, channel);
	    	pstmt.setString(counter++, workStatus);
	    	pstmt.setString(counter++, l2BiName);
	    	pstmt.setString(counter++, priorityType);
	    	pstmt.setString(counter++, medNonMed);
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_EXT_TABLE(String wiName, String planName, String channel, String workStatus,String l2BiName,String  priorityType,String medNonMed) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_TABLE);
	    	pstmt.setString(counter++, planName);
	    	pstmt.setString(counter++, channel);
	    	pstmt.setString(counter++, workStatus);
	    	pstmt.setString(counter++, l2BiName);
	    	pstmt.setString(counter++, priorityType);
	    	pstmt.setString(counter++, medNonMed);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_POLICY_DETAILS(String wiName, String appRecieveDate,String proposalNumber, String objOfInsurance,String ruralurbanSocial,String srcOfSale,String prevProposalNumber,String crmLeadid,String productSolution,String comboProposalNumber,String lifeStage,String qRops,String sparcLeadSrc) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_POLICY_DETAILS);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, appRecieveDate);
	    	pstmt.setString(counter++, proposalNumber);
	    	pstmt.setString(counter++, objOfInsurance);
	    	pstmt.setString(counter++, ruralurbanSocial);
	    	pstmt.setString(counter++, srcOfSale);
	    	pstmt.setString(counter++, appRecieveDate);
	    	pstmt.setString(counter++, prevProposalNumber);
	    	pstmt.setString(counter++, ruralurbanSocial);
	    	pstmt.setString(counter++, ruralurbanSocial);
	    	pstmt.setString(counter++, crmLeadid);
	    	pstmt.setString(counter++, productSolution);
	    	pstmt.setString(counter++, comboProposalNumber);
	    	pstmt.setString(counter++, lifeStage);
	    	pstmt.setString(counter++, qRops);
	    	pstmt.setString(counter++, sparcLeadSrc);
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_POLICY_DETAILS(String wiName, String appRecieveDate,String proposalNumber, String objOfInsurance,String ruralurbanSocial,String srcOfSale,String prevProposalNumber,String crmLeadid,String productSolution,String comboProposalNumber,String lifeStage,String qRops,String sparcLeadSrc) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_POLICY_DETAILS);
	        pstmt.setString(counter++, appRecieveDate);
	    	pstmt.setString(counter++, proposalNumber);
	    	pstmt.setString(counter++, objOfInsurance);
	    	pstmt.setString(counter++, ruralurbanSocial);
	    	pstmt.setString(counter++, srcOfSale);
	    	pstmt.setString(counter++, appRecieveDate);
	    	pstmt.setString(counter++, prevProposalNumber);
	    	pstmt.setString(counter++, ruralurbanSocial);
	    	pstmt.setString(counter++, ruralurbanSocial);
	    	pstmt.setString(counter++, crmLeadid);
	    	pstmt.setString(counter++, productSolution);
	    	pstmt.setString(counter++, comboProposalNumber);
	    	pstmt.setString(counter++, lifeStage);
	    	pstmt.setString(counter++, qRops);
	    	pstmt.setString(counter++, sparcLeadSrc);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_PROPOSER_DETAILS(String wiName,String eiaNoAvailable) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_PROPOSER_DETAILS);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, eiaNoAvailable);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_PROPOSER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_PROPOSER_DETAILS(String wiName,String eiaNoAvailable) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_PROPOSER_DETAILS);
	        pstmt.setString(counter++, eiaNoAvailable);
	        pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_PROPOSER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void insert_NG_NB_LIST_AGENT_DETAILS(String wiName,String goCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_AGENT_DETAILS);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, goCode);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_LIST_AGENT_DETAILS(String wiName,String goCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_AGENT_DETAILS);
	        pstmt.setString(counter++, goCode);
	        pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void insert_NG_NB_POLICY_VALIDATION_DETAILS(String wiName,String satrightPassCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_POLICY_VALIDATION_DETAILS);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, satrightPassCode);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_VALIDATION_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_POLICY_VALIDATION_DETAILS(String wiName,String satrightPassCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_POLICY_VALIDATION_DETAILS);
	        pstmt.setString(counter++, satrightPassCode);
	        pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String wiName,String sp_cert_no) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_AGENT_INFORMATION);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, sp_cert_no);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_VALIDATION_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String wiName,String sp_cert_no) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_AGENT_INFORMATION);
	        pstmt.setString(counter++, sp_cert_no);
	        pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_DEFENCE_DETAILS(String wiName,String defenceChannelCase,String armyNumber,String unitName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_DEFENCE_DETAILS);
	    	pstmt.setString(counter++, wiName);
	    	pstmt.setString(counter++, defenceChannelCase);
	    	pstmt.setString(counter++, armyNumber);
	    	pstmt.setString(counter++, unitName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_VALIDATION_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_DEFENCE_DETAILS(String wiName,String defenceChannelCase,String armyNumber,String unitName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_DEFENCE_DETAILS);
	        pstmt.setString(counter++, defenceChannelCase);
	        pstmt.setString(counter++, armyNumber);
	        pstmt.setString(counter++, unitName);
	        pstmt.setString(counter++, wiName);
	        
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

}
