package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;
import com.dolphin.cdcDataMigration.util.MethodUtil;

@Service
public class PaymentDAO {
	

	private final Logger logger = LoggerFactory.getLogger(DolphinAppCaseDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	
	
	public boolean paymentDetailoExistOrNot(String wiName) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_PAYMENT_DETAILS);
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	if(wiNameInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,wiNameInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_PAYMENT_DETAILS Exist or Not Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	
	
	
	
	//=================================================-: Dolphin Table NG_NB_PAYMENT_DETAILS :-=============================================================================================
	
	
	public void insert_NG_NB_PAYMENT_DETAILS(String wiName,String bankAccNo,String micrCode,
			String ifscCode,String bankName,String initPremPaid,String initPremMethod,String modeOfPay)
	{
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_PAYMENT_DETAILS);
	        Integer micrCodeInt=MethodUtil.StringToIntConverter(micrCode);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer initPermMethodint=MethodUtil.StringToIntConverter(initPremMethod);
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        pstmt.setString(counter++,bankAccNo);
	        if(micrCodeInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,micrCodeInt);	
	        }
	        
	        
	        pstmt.setString(counter++,ifscCode);
	        pstmt.setString(counter++,bankName);
	        
	        pstmt.setString(counter++,initPremPaid);
	        
	        if(initPermMethodint==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,initPermMethodint);
	        }
	        pstmt.setString(counter++,modeOfPay);
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_PAYMENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void update_NG_NB_PAYMENT_DETAILS(String wiName,String bankAccNo,String micrCode,
			String ifscCode,String bankName,String initPremPaid,String initPremMethod,String modeOfPay)
	{
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_PAYMENT_DETAILS);
	        Integer micrCodeInt=MethodUtil.StringToIntConverter(micrCode);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer initPermMethodint=MethodUtil.StringToIntConverter(initPremMethod);
	        pstmt.setString(counter++,bankAccNo);
	        if(micrCodeInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,micrCodeInt);	
	        }
	        pstmt.setString(counter++,ifscCode);
	        pstmt.setString(counter++,bankName);
	        pstmt.setString(counter++,initPremPaid);
	        if(initPermMethodint==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,initPermMethodint);
	        }
	        pstmt.setString(counter++,modeOfPay);
	        if(wiNameInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, wiNameInt);
			}
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("Update NG_NB_PAYMENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	

//=================================================-: Dolphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :-=============================================================================================
	


	public void insert_NG_NB_RENEWAL_PREMIUM_DETAILS(String wiName,String bankAccountNumber,String micrCode,String ifscCode,String bankNameBranch,
			     String billDrawDate1,String ccExpiryDate,String ccNo,String payorSameProp,String typeOfAccount,String ccHolderName,
			     String accountHolderName,String renewalPremiumMethod)
	{
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_RENEWAL_PREMIUM_DETAILS);
	        Integer typeOfAccountInt=MethodUtil.StringToIntConverter(typeOfAccount);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer micrCodeInt=MethodUtil.StringToIntConverter(micrCode);
	        Integer renewalPremiumMethodInt=MethodUtil.StringToIntConverter(renewalPremiumMethod);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        pstmt.setString(counter++,bankAccountNumber);
	        if(micrCodeInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
		        pstmt.setInt(counter,micrCodeInt);
	        }
	        pstmt.setString(counter,ifscCode);
	        pstmt.setString(counter,bankNameBranch);
	        pstmt.setString(counter,billDrawDate1);
	        pstmt.setString(counter,ccExpiryDate);
	        pstmt.setString(counter,ccNo);
	        pstmt.setString(counter,payorSameProp);
	        if(typeOfAccountInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, typeOfAccountInt);
	        }
	        pstmt.setString(counter,ccHolderName);
	        pstmt.setString(counter,accountHolderName);
	        if(renewalPremiumMethodInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, renewalPremiumMethodInt);
	        }
	        
	        pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_RENEWAL_PREMIUM_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void update_NG_NB_RENEWAL_PREMIUM_DETAILS(String bankAccountNumber,String micrCode,String ifscCode,String bankNameBranch,
		     String billDrawDate1,String ccExpiryDate,String ccNo,String payorSameProp,String typeOfAccount,String ccHolderName,
		     String accountHolderName,String renewalPremiumMethod,String wiName)
	 {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_RENEWAL_PREMIUM_DETAILS);
	        Integer typeOfAccountInt=MethodUtil.StringToIntConverter(typeOfAccount);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer micrCodeInt=MethodUtil.StringToIntConverter(micrCode);
	        Integer renewalPremiumMethodInt=MethodUtil.StringToIntConverter(renewalPremiumMethod);
	        pstmt.setString(counter++,bankAccountNumber);
	        if(micrCodeInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
		        pstmt.setInt(counter++,micrCodeInt);
	        }
	        pstmt.setString(counter++,ifscCode);
	        pstmt.setString(counter++,bankNameBranch);
	        pstmt.setString(counter++,billDrawDate1);
	        pstmt.setString(counter++,ccExpiryDate);
	        pstmt.setString(counter++,ccNo);
	        pstmt.setString(counter++,payorSameProp);
	        if(typeOfAccountInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, typeOfAccountInt);
	        }
	        pstmt.setString(counter++,ccHolderName);
	        pstmt.setString(counter++,accountHolderName);
	        
	        if(renewalPremiumMethodInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, renewalPremiumMethodInt);
	        }
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	       
	        pstmt.execute();
	        
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_RENEWAL_PREMIUM_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
//=================================================-: Dolphin Table NG_NB_NEFT_DETAILS :-=============================================================================================
	
	
     public void insert_NG_NB_NEFT_DETAILS(String wiName,String accNoNeft,String micrNeft,String holderNameNeft,String ifscNeft,
		     String nameBranchNeft,String typeOfAccNeft)
      {
	     Connection conn=null;
         PreparedStatement pstmt=null;
	   try {
		
		 int counter=1;
    	 conn= dolphinConfiguration.getDolphinConnection();
    	 pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_NEFT_DETAILS);
         Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
         if(wiNameInt==null) {
        	 pstmt.setNull(counter++, Types.INTEGER);
         }else {
        	 pstmt.setInt(counter++, wiNameInt);
         }
         pstmt.setString(counter++,accNoNeft);
         Integer micrNeftInt=MethodUtil.StringToIntConverter(micrNeft);
         if(micrNeftInt==null) {
        	 pstmt.setNull(counter++,Types.INTEGER);
         }else {
        	 pstmt.setInt(counter++,micrNeftInt);	 
         }
         pstmt.setString(counter++,holderNameNeft);
         pstmt.setString(counter++,ifscNeft);
         pstmt.setString(counter++,nameBranchNeft);
         Integer typeOfAccNeftInt=MethodUtil.StringToIntConverter(typeOfAccNeft);
         if(typeOfAccNeftInt==null) {
        	 pstmt.setNull(counter++,Types.INTEGER);	 
         }else {
             pstmt.setInt(counter++,typeOfAccNeftInt);
         }
         pstmt.execute();
   	
       }catch(Exception ec) {
   	     logger.error("INSERT_NG_NB_RENEWAL_PREMIUM_DETAILS Error",ec);
       }
      finally {
   	   if(conn!=null) {
   		try {
   		conn.close();
   		}catch(Exception ec) {
   			logger.error("error while closing the connection",ec);
   		}
   		
     }
   	 if(pstmt!=null) {
   	    try {
   		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
      }
   }



     public void update_NG_NB_NEFT_DETAILS(String accNoNeft,String micrNeft,String holderNameNeft,String ifscNeft,
    	     String nameBranchNeft,String typeOfAccNeft,String wiName)
     {
    	Connection conn=null;
       PreparedStatement pstmt=null;
    	try 
    	{
    		int counter=1;
       	   conn= dolphinConfiguration.getDolphinConnection();
           pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_NEFT_DETAILS);
           pstmt.setString(counter++,accNoNeft);
           Integer micrNeftInt=MethodUtil.StringToIntConverter(micrNeft);
           if(micrNeftInt==null) {
          	 pstmt.setNull(counter++,Types.INTEGER);
           }else {
          	 pstmt.setInt(counter++,micrNeftInt);	 
           }
           pstmt.setString(counter++,holderNameNeft);
           pstmt.setString(counter++,ifscNeft);
           pstmt.setString(counter++,nameBranchNeft);
           Integer typeOfAccNeftInt=MethodUtil.StringToIntConverter(typeOfAccNeft);
           if(typeOfAccNeftInt==null) {
          	 pstmt.setNull(counter++,Types.INTEGER);	 
           }else {
               pstmt.setInt(counter++,typeOfAccNeftInt);
           }
           Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
           if(wiNameInt==null) {
          	 pstmt.setNull(counter++, Types.INTEGER);
           }else {
          	 pstmt.setInt(counter++, wiNameInt);
           }
           pstmt.execute();
       	
           
       	
       }catch(Exception ec) {
       	logger.error("UPDATE_NG_NB_NEFT_DETAILS Error",ec);
       }
       finally {
       	if(conn!=null) {
       		try {
       		conn.close();
       		}catch(Exception ec) {
       			logger.error("error while closing the connection",ec);
       		}
       		
       	}
       	if(pstmt!=null) {
       	    try {
       		   pstmt.close();
    	    	}catch(Exception ec) {
    	    		logger.error("error while closing the connection",ec);
    	    	}
       	  }
         }
      }


	
   //=================================================-: Dolphin Table NG_NB_EXT_TABLE :-=============================================================================================
 	
	
	
	public void insert_NG_NB_EXT_TABLE(String payorClientId,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_TABLE2);
	        Integer payorClientIdInt=MethodUtil.StringToIntConverter(payorClientId);
	        if(payorClientIdInt==null){
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	            pstmt.setInt(counter++, payorClientIdInt);
	        }
	        
	        pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("insert_NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_EXT_TABLE(String payorClientId,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_TABLE2);
	        Integer payorClientIdInt=MethodUtil.StringToIntConverter(payorClientId);
	        if(payorClientIdInt==null){
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	            pstmt.setInt(counter++, payorClientIdInt);
	        }
	        pstmt.setString(counter++, wiName);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	
}
