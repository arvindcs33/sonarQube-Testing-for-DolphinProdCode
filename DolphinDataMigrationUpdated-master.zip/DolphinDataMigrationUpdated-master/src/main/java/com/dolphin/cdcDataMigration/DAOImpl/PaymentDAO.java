package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;

@Service

public class PaymentDAO {
	

	private final Logger logger = LoggerFactory.getLogger(DolphinAppCaseDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean getCaseIdExistOrNot(String wiName) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_CASE_ID2);
	    	pstmt.setString(counter, wiName);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_ID2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	public boolean getBankAccountNumberExistOrNot(String bankAccountNumber) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_REN_PREM_ACC_NUM);
	    	pstmt.setString(counter, bankAccountNumber);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_ID2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	public boolean getAccNoNeftExistOrNot(String accNoNeft) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_NEFT_BANK_ACCT_NUM);
	    	pstmt.setString(counter, accNoNeft);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_ID2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	public boolean getPayorClientIdExistOrNot(String payorClientId) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_PAYER_ID);
	    	pstmt.setString(counter, payorClientId);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_ID2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	
	//=================================================-: Dolphin Table NG_NB_PAYMENT_DETAILS :-=============================================================================================
	
	
	public void insert_NG_NB_PAYMENT_DETAILS(String wiName,String bankAccNo,String micrCode,
			String ifscCode,String bankName,String initPremPaid,String initPremMethod,String modeOfPay)
	{
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_PAYMENT_DETAILS);
	        
	        pstmt.setString(counter,wiName);
	        pstmt.setString(counter,"");
	        if("null".equals(wiName)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(wiName));
		    }
	        
	        pstmt.setString(counter,bankAccNo);
	        pstmt.setString(counter,micrCode);
	       
	        pstmt.setString(counter,ifscCode);
	        pstmt.setString(counter,bankName);
	        pstmt.setString(counter,initPremPaid);
	        pstmt.setString(counter,initPremMethod);
	        pstmt.setString(counter,modeOfPay);
	        
	        pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_COVERAGE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void update_NG_NB_PAYMENT_DETAILS(String wiName,String bankAccNo,String micrCode,
			String ifscCode,String bankName,String initPremPaid,String initPremMethod,String modeOfPay)
	{
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_PAYMENT_DETAILS);
	        
	        pstmt.setString(counter,wiName);
	        pstmt.setString(counter,"");
	        if("null".equals(wiName)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(wiName));
		    }
	        
	        pstmt.setString(counter,bankAccNo);
	        pstmt.setString(counter,micrCode);
	       
	        pstmt.setString(counter,ifscCode);
	        pstmt.setString(counter,bankName);
	        pstmt.setString(counter,initPremPaid);
	        pstmt.setString(counter,initPremMethod);
	        pstmt.setString(counter,modeOfPay);
	        
	        pstmt.execute();
	    	
	      
	    	
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_PAYMENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	

//=================================================-: Dolphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :-=============================================================================================
	


	public void insert_NG_NB_RENEWAL_PREMIUM_DETAILS(String bankAccountNumber,String micrCode,String ifscCode,String bankNameBranch,
			     String billDrawDate1,String ccExpiryDate,String ccNo,String payorSameProp,String typeOfAccount,String ccHolderName,
			     String accountHolderName)
	{
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_RENEWAL_PREMIUM_DETAILS);
	        
	        pstmt.setString(counter,bankAccountNumber);
	        pstmt.setString(counter,"");
	        if("null".equals(bankAccountNumber)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(bankAccountNumber));
		    }
	        
	        pstmt.setString(counter,micrCode);
	        pstmt.setString(counter,ifscCode);
	        pstmt.setString(counter,bankNameBranch);
	        
	        pstmt.setString(counter,billDrawDate1);
	        pstmt.setString(counter,ccExpiryDate);
	        pstmt.setString(counter,ccNo);
	        pstmt.setString(counter,payorSameProp);
	        pstmt.setString(counter,typeOfAccount);
	        pstmt.setString(counter,ccHolderName);
	       
	        pstmt.setString(counter,accountHolderName);
	        
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_RENEWAL_PREMIUM_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void update_NG_NB_RENEWAL_PREMIUM_DETAILS(String bankAccountNumber,String micrCode,String ifscCode,String bankNameBranch,
		     String billDrawDate1,String ccExpiryDate,String ccNo,String payorSameProp,String typeOfAccount,String ccHolderName,
		     String accountHolderName)
	 {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_RENEWAL_PREMIUM_DETAILS);
	        
	        pstmt.setString(counter,bankAccountNumber);
	        pstmt.setString(counter,"");
	        if("null".equals(bankAccountNumber)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(bankAccountNumber));
		    }
	        
	        pstmt.setString(counter,micrCode);
	        pstmt.setString(counter,ifscCode);
	        pstmt.setString(counter,bankNameBranch);
	        
	        pstmt.setString(counter,billDrawDate1);
	        pstmt.setString(counter,ccExpiryDate);
	        pstmt.setString(counter,ccNo);
	        pstmt.setString(counter,payorSameProp);
	        pstmt.setString(counter,typeOfAccount);
	        pstmt.setString(counter,ccHolderName);
	       
	        pstmt.setString(counter,accountHolderName);
	        
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_RENEWAL_PREMIUM_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
//=================================================-: Dolphin Table NG_NB_NEFT_DETAILS :-=============================================================================================
	
	
     public void insert_NG_NB_NEFT_DETAILS(String accNoNeft,String micrNeft,String holderNameNeft,String ifscNeft,
		     String nameBranchNeft,String typeOfAccNeft)
      {
	     Connection conn=null;
         PreparedStatement pstmt=null;
	   try {
		
		 int counter=1;
    	 conn= dolphinConfiguration.getDolphinConnection();
         pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_NEFT_DETAILS);
       
         pstmt.setString(counter,accNoNeft);
         pstmt.setString(counter,"");
         if("null".equals(accNoNeft)) {
	    	pstmt.setNull(counter++, Types.INTEGER);	
	      }else {
	        pstmt.setInt(counter++, Integer.parseInt(accNoNeft));
	     }
       
         pstmt.setString(counter,micrNeft);
         pstmt.setString(counter,holderNameNeft);
         pstmt.setString(counter,ifscNeft);
       
         pstmt.setString(counter,nameBranchNeft);
         pstmt.execute();
   	
       }catch(Exception ec) {
   	     logger.error("INSERT_NG_NB_RENEWAL_PREMIUM_DETAILS Error",ec);
       }
      finally {
   	   if(conn!=null) {
   		try {
   		conn.close();
   		}catch(Exception ec) {
   			logger.error("error while closing the connection",ec);
   		}
   		
     }
   	 if(pstmt!=null) {
   	    try {
   		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
      }
   }



     public void update_NG_NB_NEFT_DETAILS(String accNoNeft,String micrNeft,String holderNameNeft,String ifscNeft,
    	     String nameBranchNeft,String typeOfAccNeft)
     {
    	Connection conn=null;
       PreparedStatement pstmt=null;
    	try 
    	{
    		int counter=1;
       	conn= dolphinConfiguration.getDolphinConnection();
           pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_NEFT_DETAILS);
           
           pstmt.setString(counter,accNoNeft);
           pstmt.setString(counter,"");
           if("null".equals(accNoNeft)) {
    	    	pstmt.setNull(counter++, Types.INTEGER);	
    	    }else {
    	      pstmt.setInt(counter++, Integer.parseInt(accNoNeft));
    	    }
           
           pstmt.setString(counter,micrNeft);
           pstmt.setString(counter,holderNameNeft);
           pstmt.setString(counter,ifscNeft);
           
           pstmt.setString(counter,nameBranchNeft);
           pstmt.execute();
       	
           
       	
       }catch(Exception ec) {
       	logger.error("UPDATE_NG_NB_RENEWAL_PREMIUM_DETAILS Error",ec);
       }
       finally {
       	if(conn!=null) {
       		try {
       		conn.close();
       		}catch(Exception ec) {
       			logger.error("error while closing the connection",ec);
       		}
       		
       	}
       	if(pstmt!=null) {
       	    try {
       		   pstmt.close();
    	    	}catch(Exception ec) {
    	    		logger.error("error while closing the connection",ec);
    	    	}
       	  }
         }
      }


	
   //=================================================-: Dolphin Table NG_NB_EXT_TABLE :-=============================================================================================
 	
	
	
	public void insert_NG_NB_EXT_TABLE(String payorClientId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_TABLE2);
	        pstmt.setString(counter++, payorClientId);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_EXT_TABLE(String payorClientId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_TABLE2);
	        pstmt.setString(counter++, payorClientId);
	       
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	


	
	




}
