package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;

@Service
public class AgentDAO {

	private final Logger logger = LoggerFactory.getLogger(DolphinAppCaseDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean getAgentExistOrNot(String strAgentCode) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_AGENT);
	    	pstmt.setString(counter, strAgentCode);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_AGENT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	public void insert_NG_NB_LIST_AGENT_DETAILS_GRID(String strAgentCd,String strAgentName,String strAgentStatus,String goCode,String afterJoiningDate,
			String reportingManagerCode,String reportingManagerName,String agentContactNumber,String agentEmail,String currentUlipStartDate,
			String currentUlipEndDate,String previousUlipStartDate,String previousUlipEndDate,String currentAmlStartDate,String currentAmlEndDate
			,String previousAmlStartDate,String previousAmlEndDate) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_AGENT_DETAILS_GRID);
	        pstmt.setString(counter,strAgentCd);
	        pstmt.setString(counter,strAgentName);
	        pstmt.setString(counter,"");
	        if("null".equals(strAgentStatus)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(strAgentStatus));
		    }
	        
	        pstmt.setString(counter,goCode);
	        pstmt.setString(counter,afterJoiningDate);
	        pstmt.setString(counter,reportingManagerCode);
	        pstmt.setString(counter,reportingManagerCode);
	        pstmt.setString(counter,reportingManagerName);
	        pstmt.setString(counter,agentContactNumber);
	        pstmt.setString(counter,agentEmail);
	        pstmt.setString(counter,currentUlipStartDate);
	        pstmt.setString(counter,currentUlipEndDate);
	        pstmt.setString(counter,previousUlipStartDate);
	        pstmt.setString(counter,previousUlipEndDate);
	        pstmt.setString(counter,currentAmlStartDate);
	        pstmt.setString(counter,currentAmlEndDate);
	        pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_LIST_AGENT_DETAILS_GRID(String strAgentCd,String strAgentName,String strAgentStatus,String goCode,String afterJoiningDate,
			String reportingManagerCode,String reportingManagerName,String agentContactNumber,String agentEmail,String currentUlipStartDate,
			String currentUlipEndDate,String previousUlipStartDate,String previousUlipEndDate,String currentAmlStartDate,String currentAmlEndDate
			,String previousAmlStartDate,String previousAmlEndDate) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_AGENT_DETAILS_GRID);
	        
	        pstmt.setString(counter,strAgentName);
	        pstmt.setString(counter,"");
	        if("null".equals(strAgentStatus)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(strAgentStatus));
		    }
	        
	        pstmt.setString(counter,goCode);
	        pstmt.setString(counter,afterJoiningDate);
	        pstmt.setString(counter,reportingManagerCode);
	        pstmt.setString(counter,reportingManagerCode);
	        pstmt.setString(counter,reportingManagerName);
	        pstmt.setString(counter,agentContactNumber);
	        pstmt.setString(counter,agentEmail);
	        pstmt.setString(counter,currentUlipStartDate);
	        pstmt.setString(counter,currentUlipEndDate);
	        pstmt.setString(counter,previousUlipStartDate);
	        pstmt.setString(counter,previousUlipEndDate);
	        pstmt.setString(counter,currentAmlStartDate);
	        pstmt.setString(counter,currentAmlEndDate);
	        pstmt.setString(counter,strAgentCd);
	        pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String agentcCde,String spCrtFktNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_MA_NG_NB_AGENT_INFORMATION);
	        pstmt.setString(counter++, agentcCde);
	    	pstmt.setString(counter++, spCrtFktNumber);
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String agentCode,String spCrtFktNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_MA_NG_NB_AGENT_INFORMATION);
	        pstmt.setString(counter++, spCrtFktNumber);
	    	pstmt.setString(counter++, agentCode);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
}
