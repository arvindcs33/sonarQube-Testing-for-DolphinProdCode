package com.dolphin.cdcDataMigration.util;

public class MethodUtil {

	public static String removeUnRequiredCharacterCaseId(String caseId) {
	     if(caseId==null || "".equals(caseId) || "null".equals(caseId)) {
	    	 return caseId;
	     }
		
		String tempCaseId=caseId;
		tempCaseId=tempCaseId.replaceAll("-", "");
		tempCaseId=tempCaseId.replaceAll("NB", "");
		tempCaseId=tempCaseId.replaceAll("Dolphin", "");
	    
		return tempCaseId;
	}
	
	
}
