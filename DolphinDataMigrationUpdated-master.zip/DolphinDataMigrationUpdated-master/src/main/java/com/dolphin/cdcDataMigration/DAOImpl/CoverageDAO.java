package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;

@Service
public class CoverageDAO {


	private final Logger logger = LoggerFactory.getLogger(DolphinAppCaseDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean getCaseIdExistOrNot(String wiName) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_CASE_ID);
	    	pstmt.setString(counter, wiName);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_ID Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	
	public void insert_NG_NB_COVERAGE_DETAILS(String wiName,String premiumPayTerm,String reqModalPremium,
			String coverageTerm,String sumAssured,String atp,String totalReqPremium,String nonForfeiture,
			String bonusOption,String modeOfPay,String productName,String modalPremium,String afyp,
			String vestingAge,String effectiveDate,String deathBenefit,String gipPayoutDay,String gipPayoutMethod,
			String smokerClass,String empDiscount, String guaranteeDeathBenefit,String saveMoreTomorrow,
			String coverageString,String maturityAge, String lifeEvent) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_COVERAGE_DETAILS);
	        
	        pstmt.setString(counter,wiName);
	        pstmt.setString(counter,"");
	        if("null".equals(wiName)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(wiName));
		    }
	        
	        pstmt.setString(counter,premiumPayTerm);
	        pstmt.setString(counter,reqModalPremium);
	       
	        pstmt.setString(counter,coverageTerm);
	        pstmt.setString(counter,sumAssured);
	        pstmt.setString(counter,atp);
	        pstmt.setString(counter,totalReqPremium);
	        pstmt.setString(counter,nonForfeiture);
	        
	        pstmt.setString(counter,bonusOption);
	        pstmt.setString(counter,modeOfPay);
	        pstmt.setString(counter,productName);
	        pstmt.setString(counter,modalPremium);
	        pstmt.setString(counter,afyp);
	        
	        pstmt.setString(counter,vestingAge);
	        pstmt.setString(counter,effectiveDate);
	        pstmt.setString(counter,deathBenefit);
	        pstmt.setString(counter,gipPayoutDay);
	        pstmt.setString(counter,gipPayoutMethod);
	        
	        pstmt.setString(counter,smokerClass);
	        pstmt.setString(counter,empDiscount);
	        pstmt.setString(counter,guaranteeDeathBenefit);
	        pstmt.setString(counter,saveMoreTomorrow);
	        
	        pstmt.setString(counter,coverageString);
	        pstmt.setString(counter,maturityAge);
	        pstmt.setString(counter,lifeEvent);
	       
	        pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_COVERAGE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_COVERAGE_DETAILS(String wiName,String premiumPayTerm,String reqModalPremium,
			String coverageTerm,String sumAssured,String atp,String totalReqPremium,String nonForfeiture,
			String bonusOption,String modeOfPay,String productName,String modalPremium,String afyp,
			String vestingAge,String effectiveDate,String deathBenefit,String gipPayoutDay,String gipPayoutMethod,
			String smokerClass,String empDiscoun, String guaranteeDeathBenefit,String saveMoreTomorrow,
			String coverageString,String maturityAge, String lifeEvent) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_COVERAGE_DETAILS);
	        
	        pstmt.setString(counter,wiName);
	        pstmt.setString(counter,"");
	        if("null".equals(wiName)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(wiName));
		    }
	        
	        pstmt.setString(counter,premiumPayTerm);
	        pstmt.setString(counter,reqModalPremium);
	       
	        pstmt.setString(counter,coverageTerm);
	        pstmt.setString(counter,sumAssured);
	        pstmt.setString(counter,atp);
	        pstmt.setString(counter,totalReqPremium);
	        pstmt.setString(counter,nonForfeiture);
	        
	        pstmt.setString(counter,bonusOption);
	        pstmt.setString(counter,modeOfPay);
	        pstmt.setString(counter,productName);
	        pstmt.setString(counter,modalPremium);
	        pstmt.setString(counter,afyp);
	        
	        pstmt.setString(counter,vestingAge);
	        pstmt.setString(counter,effectiveDate);
	        pstmt.setString(counter,deathBenefit);
	        pstmt.setString(counter,gipPayoutDay);
	        pstmt.setString(counter,gipPayoutMethod);
	        
	        pstmt.setString(counter,smokerClass);
	        pstmt.setString(counter,empDiscoun);
	        pstmt.setString(counter,guaranteeDeathBenefit);
	        pstmt.setString(counter,saveMoreTomorrow);
	        
	        pstmt.setString(counter,coverageString);
	        pstmt.setString(counter,maturityAge);
	        pstmt.setString(counter,lifeEvent);
	       
	        pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_COVERAGE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	

	public void insert_NG_NB_FUND_SELECTED(String stp) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_FUND_SELECTED);
	        pstmt.setString(counter++,stp);
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_FUND_SELECTED Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_FUND_SELECTED(String stp) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_FUND_SELECTED);
	        pstmt.setString(counter++, stp);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_FUND_SELECTED Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void insert_NG_NB_EXT_TABLE1(String adjustedAfyp,String adjustedMfyp) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_TABLE1);
	        pstmt.setString(counter++,adjustedAfyp);
	        pstmt.setString(counter++, adjustedMfyp);
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_EXT_TABLE1 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_EXT_TABLE1(String adjustedAfyp,String adjustedMfyp) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_TABLE1);
	        pstmt.setString(counter++, adjustedAfyp);
	        pstmt.setString(counter++, adjustedMfyp);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_EXT_TABLE1 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	
	
	public void insert_NG_NB_SUC_PARAMETERS(String fsa,String msa) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_SUC_PARAMETERS);
	        pstmt.setString(counter++, fsa);
	        pstmt.setString(counter++, msa);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_SUC_PARAMETERS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_SUC_PARAMETERS(String fsa,String msa) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_SUC_PARAMETERS);
	        pstmt.setString(counter++, fsa);
	        pstmt.setString(counter++, msa);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_SUC_PARAMETERS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	


}
