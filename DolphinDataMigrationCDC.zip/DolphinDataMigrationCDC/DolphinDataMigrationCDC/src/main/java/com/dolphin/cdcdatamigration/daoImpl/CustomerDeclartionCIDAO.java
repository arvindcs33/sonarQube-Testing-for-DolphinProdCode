package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class CustomerDeclartionCIDAO {
    private final Logger logger=LoggerFactory.getLogger(CustomerDeclartionCIDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;

	
	public boolean getMnylCustomerInformationExistOrNot(String customerId) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.NG_NB_CUSTOMER_INFORMATION_CTR_INFRMTION_CI_SELECT);
	    	Integer customerIdInt=MethodUtil.StringToIntConverter(customerId);
	    	if(customerIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,customerIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting MNYL_CUSTOMER_INFORMATION ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	public void insert_NG_NB_CUSTOMER_INFORMATION(String customerId,
	String wiName,
	String customerSignDate,
	String replacementPolicySale,
	String custClass,
	String irpScore) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
		 
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.NG_NB_CUSTOMER_INFORMATION_CTR_INFRMTION_CI_INSERT);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	Integer customerIdInt=MethodUtil.StringToIntConverter(customerId);
	        Long customerSignDateLong=MethodUtil.StringToLongConverter(customerSignDate);
	        if(customerIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,customerIdInt);
	        }
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);
	        }
	        
	        if(customerSignDateLong==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(customerSignDateLong));
	        }
	        
	        if(MethodUtil.isNull(customerId)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++,customerId);
	        }
	        
	        if(MethodUtil.isNull(replacementPolicySale)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++, replacementPolicySale);
	        }
	        
	        if(MethodUtil.isNull(custClass)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++,custClass);
	        }
	        
	        if(MethodUtil.isNull(irpScore)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++, irpScore);
	        }
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO NG_NB_CUSTOMER_INFORMATION getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
	
public void update_NG_NB_CUSTOMER_INFORMATION(String customerId,
		String wiName,
		String customerSignDate,
		String replacementPolicySale,
		String custClass,
		String irpScore) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.NG_NB_CUSTOMER_INFORMATION_CTR_INFRMTION_CI_UPDATE);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	Integer customerIdInt=MethodUtil.StringToIntConverter(customerId);
	        Long customerSignDateLong=MethodUtil.StringToLongConverter(customerSignDate);
	       
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);
	        }
	        
	        if(customerSignDateLong==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(customerSignDateLong));
	        }
	        
	        if(MethodUtil.isNull(customerId)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++,customerId);
	        }
	        
	        if(MethodUtil.isNull(replacementPolicySale)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++, replacementPolicySale);
	        }
	        
	        if(MethodUtil.isNull(custClass)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++,custClass);
	        }
	        
	        if(MethodUtil.isNull(irpScore)) {
	        	pstmt.setNull(counter++,Types.VARCHAR)	;
	        }else {
	        pstmt.setString(counter++, irpScore);
	        }
	        
	        if(customerIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,customerIdInt);
	        }
	        
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO NG_NB_CUSTOMER_INFORMATION getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
public void insert_NG_NB_AGENT_INFORMATION_CTR_INFRMTION_CI(String wiName,String ssnCode,
		String applicationId,String solId,String agentSignDate,String wmsSerialNo,String custId) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
				Long agentSignDateLong=MethodUtil.StringToLongConverter(agentSignDate);
		    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
		    	Integer custIdInt=MethodUtil.StringToIntConverter(custId);
			    conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.NG_NB_AGENT_INFORMATION_CTR_INFRMTION_CI_INSERT);
		       
		    	if(custIdInt==null) {
		        	pstmt.setNull(counter++,Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, custIdInt);
		        }
		    	
		    	if(wiNameInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, wiNameInt);
		        }
		    	
		    	if(MethodUtil.isNull(ssnCode)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	    pstmt.setString(counter++, ssnCode);
		    	}
		    	
		    	if(MethodUtil.isNull(applicationId)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	pstmt.setString(counter++, applicationId);
		    	}
		    	
		    	if(MethodUtil.isNull(solId)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	pstmt.setString(counter++, solId);
		    	}
		    	
		    	
		    	if(agentSignDateLong==null) {
		    		pstmt.setNull(counter++, Types.DATE);
		        }else {
		        	pstmt.setTimestamp(counter++, new Timestamp(agentSignDateLong));
		        	
		        }
		    	
		    	if(MethodUtil.isNull(wmsSerialNo)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	    pstmt.setString(counter++, wmsSerialNo);
		    	}
		    	
		    	pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("INSERTING INTO NG_NB_AGENT_INFORMATION getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}
		
	public void update_NG_NB_AGENT_INFORMATION_CTR_INFRMTION_CI(String wiName,String ssnCode,
			String applicationId,String solId,String agentSignDate,String wmsSerialNo,String custId) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	Long agentSignDateLong=MethodUtil.StringToLongConverter(agentSignDate);
		    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
		    	Integer custIdInt=MethodUtil.StringToIntConverter(custId);
		    	pstmt=conn.prepareStatement(DPHConstants.NG_NB_CUSTOMER_INFORMATION_CTR_INFRMTION_CI_UPDATE);
		    	if(wiNameInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, wiNameInt);
		        }
		    	
		    	if(MethodUtil.isNull(ssnCode)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	    pstmt.setString(counter++, ssnCode);
		    	}
		    	
		    	if(MethodUtil.isNull(applicationId)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	pstmt.setString(counter++, applicationId);
		    	}
		    	
		    	if(MethodUtil.isNull(solId)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	pstmt.setString(counter++, solId);
		    	}
		    	
		    	if(agentSignDateLong==null) {
		    		pstmt.setNull(counter++, Types.DATE);
		        }else {
		        	pstmt.setTimestamp(counter++, new Timestamp(agentSignDateLong));
		        	
		        }
		    	if(MethodUtil.isNull(wmsSerialNo)) {
		    		pstmt.setNull(counter++,Types.VARCHAR);	
		    	}else {
		    	    pstmt.setString(counter++, wmsSerialNo);
		    	}
		    	
		    	if(custIdInt==null) {
		        	pstmt.setNull(counter++,Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, custIdInt);
		        }
		    	
		    	pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("INSERTING INTO NG_NB_POLICY_VALIDATION_DETAILS getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}
	
	
	   public void insert_NG_NB_POLICY_VALIDATION_DETAILS_CTR_INFRMTION_CI(String wiName,String irpReq,String customerId) {
				
				Connection conn=null;
			    PreparedStatement pstmt=null;
				try {
					int counter=1;
					
			    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			    	Integer customerIdInt=MethodUtil.StringToIntConverter(customerId);
				    conn= dolphinConfiguration.getDolphinConnection();
			    	pstmt=conn.prepareStatement(DPHConstants.NG_NB_POLICY_VALIDATION_DETAILS_CTR_INFRMTION_INSERT);
			    	
			    	if(customerIdInt==null) {
			        	pstmt.setNull(counter++, Types.INTEGER);	
			        }else {
			        	pstmt.setInt(counter++, customerIdInt);
			        }
			        
			    	if(wiNameInt==null) {
			        	pstmt.setNull(counter++, Types.INTEGER);	
			        }else {
			        	pstmt.setInt(counter++, wiNameInt);
			        }
			    	if(MethodUtil.isNull(irpReq)) {
			    		pstmt.setNull(counter++,Types.VARCHAR);	
			    	}else {
			    	    pstmt.setString(counter++, irpReq);
			    	}
			    	pstmt.execute();
			    }catch(Exception ec) {
			    	logger.error("INSERTING INTO NG_NB_POLICY_VALIDATION_DETAILS getting Error",ec);
			    }
			    finally {
			    	if(conn!=null) {
			    		try {
			    		conn.close();
			    		}catch(Exception ec) {
			    			logger.error("error while closing the connection",ec);
			    		}
			    		
			    	}
			    	if(pstmt!=null) {
			    	    try {
			    		   pstmt.close();
				    	}catch(Exception ec) {
				    		logger.error("error while closing the connection",ec);
				    	}
			    	}
			    }
				
			}
			
		public void update_NG_NB_POLICY_VALIDATION_DETAILS_CTR_INFRMTION_CI(String wiName,String irpReq,String customerId) {
				
				Connection conn=null;
			    PreparedStatement pstmt=null;
				try {
					int counter=1;
			    	conn= dolphinConfiguration.getDolphinConnection();
			    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			    	Integer customerIdInt=MethodUtil.StringToIntConverter(customerId);
			    	pstmt=conn.prepareStatement(DPHConstants.NG_NB_POLICY_VALIDATION_DETAILS_CTR_INFRMTION_UPDATE);
			    	
			    	if(MethodUtil.isNull(irpReq)) {
			    		pstmt.setNull(counter++,Types.VARCHAR);	
			    	}else {
			    	    pstmt.setString(counter++, irpReq);
			    	}
			    	
			    	if(wiNameInt==null) {
			    		pstmt.setNull(counter++, Types.INTEGER);
			    	}else {
			    		pstmt.setInt(counter++, wiNameInt);
			    	}
			    	
			    	if(customerIdInt==null) {
			    		pstmt.setNull(counter++, Types.INTEGER);
			    	}else {
			    		pstmt.setInt(counter++, customerIdInt);
			    	}
			    	pstmt.execute();
			    }catch(Exception ec) {
			    	logger.error("INSERTING INTO NG_NB_POLICY VALIDATION_DETAILS getting Error",ec);
			    }
			    finally {
			    	if(conn!=null) {
			    		try {
			    		conn.close();
			    		}catch(Exception ec) {
			    			logger.error("error while closing the connection",ec);
			    		}
			    		
			    	}
			    	if(pstmt!=null) {
			    	    try {
			    		   pstmt.close();
				    	}catch(Exception ec) {
				    		logger.error("error while closing the connection",ec);
				    	}
			    	}
			    }
				
			}
	
}
