package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class PClientDAO {

	private final Logger logger = LoggerFactory.getLogger(PClientDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean getPcliIdExistOrNot(String pcliId,Integer addition) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_CASE_ID3);
	    	Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	    	if(pcliIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,pcliIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("SELECT_CASE_ID2 Exist or Not Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}

	public void insert_NG_NB_PROPOSER_DETAILS(String pcliId, String proposer, String occupation, String middleName,
			String firstName, String lastName, String dateOfBirth, String gender, String typeOfVisa,
			String prefMailAddress, String idProofProp, String nationality, String natureOfDuties, String maritalStatus,
			String title, String emailId, String exactIncome, String dobProof, String addrProofProp, String clientId,
			String politicalExp, String preferredLanguage, String education, String industryType, String panNumber,
			String eiaNoAvailable, String eiaNoAvailable2, String eiaNumber, String repository, String neftBankAccNo,
			String dateOfIncor, String fatherNameHusbandName, String countryResidingIn, String organizationType,
			String annuityOption, String aadhaarNumber, String aadhaarEnrolNo,Integer addition) {
		
	
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_PROPOSER_DETAILS2);
	        //---------------------------: Number :----------------------------------
	        Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId, addition);
	        //Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	       // Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	       // Integer preferredLanguageInt=MethodUtil.StringToIntConverter(preferredLanguage);
	        Long eiaNumberLong=MethodUtil.StringToLongConverter(eiaNumber);
	      //---------------------------: Date :----------------------------------
	        Long dateOfBirthInt=MethodUtil.StringToLongConverter(dateOfBirth);
	        Long dateOfIncorInt=MethodUtil.StringToLongConverter(dateOfIncor);
	          
	        if(pcliIdInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, pcliIdInt);
		    }
	        
	        if(MethodUtil.isNull(proposer)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,proposer);
	        }
	        
	        if(MethodUtil.isNull(occupation)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,occupation);
	        }
	        
	        if(MethodUtil.isNull(middleName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,middleName);
	        }
	        
	        if(MethodUtil.isNull(firstName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,firstName);
	        }
	        
	        if(MethodUtil.isNull(lastName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,lastName);
	        }
	        
	        if(dateOfBirthInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfBirthInt));
	        }
	       
	        if(MethodUtil.isNull(gender)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,gender);
	        }
	        
	        if(MethodUtil.isNull(typeOfVisa)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,typeOfVisa);
	        }
	        
	        if(MethodUtil.isNull(prefMailAddress)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,prefMailAddress);
	        }
	        
	        if(MethodUtil.isNull(idProofProp)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,idProofProp);
	        }
	        
	        if(MethodUtil.isNull(nationality)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,nationality);
	        }
	        
	        if(MethodUtil.isNull(natureOfDuties)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,natureOfDuties);
	        }
	        /*  Commented discuss with mangaleshwar
	        if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }
	        */
	        pstmt.setNull(counter++, Types.INTEGER);	
	        
	        if(MethodUtil.isNull(title)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,title);
	        }
	        
	        if(MethodUtil.isNull(emailId)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,emailId);
	        }
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	     
	        //
	        pstmt.setNull(counter++, Types.INTEGER);
	        /*commented as per mangaleshwar
	        if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }
	        */
	        if(MethodUtil.isNull(addrProofProp)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,addrProofProp);
	        }
	        
	        if(MethodUtil.isNull(clientId)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,clientId);
	        }
	        
	        //pstmt.setString(counter++,politicalExp);//Discuss with Mangaleshwar
	        pstmt.setNull(counter++,Types.VARCHAR);
	      
	        /*  Discuss with Mangaleshwar
	        if(preferredLanguageInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, preferredLanguageInt);
			    }
	        */
	        pstmt.setNull(counter++, Types.INTEGER);	
	        

	        if(MethodUtil.isNull(education)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,education);
	        }
	        
	        if(MethodUtil.isNull(industryType)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,industryType);
	        }
	        
	        if(MethodUtil.isNull(panNumber)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,panNumber);
	        }
	        

	        if(MethodUtil.isNull(eiaNoAvailable)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,eiaNoAvailable);
	        }
	    
	        if(MethodUtil.isNull(eiaNoAvailable2)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,eiaNoAvailable2);
	        
	        }
	        
	        if(eiaNumberLong==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setLong(counter++, eiaNumberLong);
			    }
	        

	        if(MethodUtil.isNull(repository)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,repository);
	        }
	        

	        if(MethodUtil.isNull(neftBankAccNo)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,neftBankAccNo);
	        }
	        
	        if(dateOfIncorInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfIncorInt));
	        }
	        

	        if(MethodUtil.isNull(fatherNameHusbandName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,fatherNameHusbandName);
	        }
	       
	        if(MethodUtil.isNull(countryResidingIn)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,countryResidingIn);
	        }
	        

	        if(MethodUtil.isNull(organizationType)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,organizationType);
	        }
	        

	        if(MethodUtil.isNull(annuityOption)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,annuityOption);
	        }
	        

	        if(MethodUtil.isNull(aadhaarNumber)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,aadhaarNumber);
	        }
	        

	        if(MethodUtil.isNull(aadhaarEnrolNo)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,aadhaarEnrolNo);
	        }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_PROPOSER_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		
	}


	public void update_NG_NB_PROPOSER_DETAILS(String pcliId, String proposer, String occupation, String middleName,
			String firstName, String lastName, String dateOfBirth, String gender, String typeOfVisa,
			String prefMailAddress, String idProofProp, String nationality, String natureOfDuties, String maritalStatus,
			String title, String emailId, String exactIncome, String dobProof, String addrProofProp, String clientId,
			String politicalExp, String preferredLanguage, String education, String industryType, String panNumber,
			String eiaNoAvailable, String eiaNoAvailable2, String eiaNumber, String repository, String neftBankAccNo,
			String dateOfIncor, String fatherNameHusbandName, String countryResidingIn, String organizationType,
			String annuityOption, String aadhaarNumber, String aadhaarEnrolNo,Integer addition) {
		

		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_PROPOSER_DETAILS2);
	      //---------------------------: Number :----------------------------------
	        Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	        //Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	       // Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	       // Integer preferredLanguageInt=MethodUtil.StringToIntConverter(preferredLanguage);
	        Long eiaNumberLong=MethodUtil.StringToLongConverter(eiaNumber);
	      //---------------------------: Date :----------------------------------
	        Long dateOfBirthInt=MethodUtil.StringToLongConverter(dateOfBirth);
	        Long dateOfIncorInt=MethodUtil.StringToLongConverter(dateOfIncor);
	          
	        
	        
	        if(MethodUtil.isNull(proposer)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,proposer);
	        }
	        
	        if(MethodUtil.isNull(occupation)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,occupation);
	        }
	        
	        if(MethodUtil.isNull(middleName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,middleName);
	        }
	        
	        if(MethodUtil.isNull(firstName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,firstName);
	        }
	        
	        if(MethodUtil.isNull(lastName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,lastName);
	        }
	        
	        if(dateOfBirthInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfBirthInt));
	        }
	       
	        if(MethodUtil.isNull(gender)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,gender);
	        }
	        
	        if(MethodUtil.isNull(typeOfVisa)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,typeOfVisa);
	        }
	        
	        if(MethodUtil.isNull(prefMailAddress)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,prefMailAddress);
	        }
	        
	        if(MethodUtil.isNull(idProofProp)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,idProofProp);
	        }
	        
	        if(MethodUtil.isNull(nationality)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,nationality);
	        }
	        
	        if(MethodUtil.isNull(natureOfDuties)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,natureOfDuties);
	        }
	        /*  Commented discuss with mangaleshwar
	        if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }
	        */
	        pstmt.setNull(counter++, Types.INTEGER);	
	        
	        if(MethodUtil.isNull(title)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,title);
	        }
	        
	        if(MethodUtil.isNull(emailId)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,emailId);
	        }
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	     
	        //
	        pstmt.setNull(counter++, Types.INTEGER);
	        /*commented as per mangaleshwar
	        if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }
	        */
	        if(MethodUtil.isNull(addrProofProp)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,addrProofProp);
	        }
	        
	        if(MethodUtil.isNull(clientId)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,clientId);
	        }
	        
	        //pstmt.setString(counter++,politicalExp);//Discuss with Mangaleshwar
	        pstmt.setNull(counter++,Types.VARCHAR);
	      
	        /*  Discuss with Mangaleshwar
	        if(preferredLanguageInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, preferredLanguageInt);
			    }
	        */
	        pstmt.setNull(counter++, Types.INTEGER);	
	        

	        if(MethodUtil.isNull(education)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,education);
	        }
	        
	        if(MethodUtil.isNull(industryType)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,industryType);
	        }
	        
	        if(MethodUtil.isNull(panNumber)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,panNumber);
	        }
	        

	        if(MethodUtil.isNull(eiaNoAvailable)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,eiaNoAvailable);
	        }
	    
	        if(MethodUtil.isNull(eiaNoAvailable2)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,eiaNoAvailable2);
	        
	        }
	        
	        if(eiaNumberLong==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setLong(counter++, eiaNumberLong);
			    }
	        

	        if(MethodUtil.isNull(repository)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,repository);
	        }
	        

	        if(MethodUtil.isNull(neftBankAccNo)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,neftBankAccNo);
	        }
	        
	        if(dateOfIncorInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dateOfIncorInt));
	        }
	        

	        if(MethodUtil.isNull(fatherNameHusbandName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,fatherNameHusbandName);
	        }
	       
	        if(MethodUtil.isNull(countryResidingIn)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,countryResidingIn);
	        }
	        

	        if(MethodUtil.isNull(organizationType)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,organizationType);
	        }
	        

	        if(MethodUtil.isNull(annuityOption)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,annuityOption);
	        }
	        

	        if(MethodUtil.isNull(aadhaarNumber)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,aadhaarNumber);
	        }
	        

	        if(MethodUtil.isNull(aadhaarEnrolNo)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,aadhaarEnrolNo);
	        }
	        
	        if(pcliIdInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, pcliIdInt);
			    }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_PROPOSER_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	
		
	}

	public void insert_NG_NB_POLICY_VALIDATION_DETAILS(String pcliId, String creditScore, String incomeSegment) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_POLICY_VALIDATION_DETAILS2);
	        
	        Integer pcliIdnt=MethodUtil.StringToIntConverter(pcliId);
	        Integer creditScoreInt=MethodUtil.StringToIntConverter(creditScore);
	        Integer incomeSegmentInt=MethodUtil.StringToIntConverter(incomeSegment);
	        
	        
	        if(pcliIdnt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, pcliIdnt);
		    }
	        
	        if(creditScoreInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, creditScoreInt);
			    }
	        
	        if(incomeSegmentInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, incomeSegmentInt);
			    }
	        
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_POLICY_VALIDATION_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
			
	}

	public void update_NG_NB_POLICY_VALIDATION_DETAILS(String pcliId, String creditScore, String incomeSegment,Integer addition) {

		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_POLICY_VALIDATION_DETAILS2);
	        
	        Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	        Integer creditScoreInt=MethodUtil.StringToIntConverter(creditScore);
	        Integer incomeSegmentInt=MethodUtil.StringToIntConverter(incomeSegment);
	
	        if(creditScoreInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, creditScoreInt);
		    }
	        
	        if(incomeSegmentInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, incomeSegmentInt);
		    }
	       
            if(pcliIdInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, pcliIdInt);
		    }
	        
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_POLICY_VALIDATION_DETAILS2 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		
	}

	public void insert_NG_NB_L2BI_DETAILS(String pcliId, String insured, String occupation, String middleName,
			String firstName, String lastName, String dob, String gender, String typeOfVisa, String nationality,
			String natureOfDuties, String maritalStatus, String incomeSource, String title, String emailId,
			String exactIncome, String dobProof, String clientId, String relationshipWithProposer, String education,
			String industryType, String fatherNameHusbandName, String organizationType,Integer addition) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_L2BI_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	       // Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer incomeSourceInt=MethodUtil.StringToIntConverter(incomeSource);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	        //Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	          
	        if(pcliIdInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, pcliIdInt);
		    }
	        
	        if(MethodUtil.isNull(insured)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	            pstmt.setString(counter++,insured);
	        }
	        
	        if(MethodUtil.isNull(occupation)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,occupation);
	        }
	        
	        if(MethodUtil.isNull(middleName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,middleName);
	        }
	        
	        if(MethodUtil.isNull(firstName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,firstName);
	        }
	        
	        if(MethodUtil.isNull(lastName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,lastName);
	        }
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	     //   if(MethodUtil.isNull(gender)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	      /*  }else {
	        pstmt.setString(counter++,gender);
	        } */
	        
	        if(MethodUtil.isNull(typeOfVisa)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,typeOfVisa);
	        }
	        
	        if(MethodUtil.isNull(nationality)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,nationality);
	        }
	        
	        if(MethodUtil.isNull(natureOfDuties)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,natureOfDuties);
	        }
	        
	        //if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			  /*  }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }*/
	        
	        if(incomeSourceInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, incomeSourceInt);
			    }
	        
	        if(MethodUtil.isNull(title)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,title);
	        }
	        
	        if(MethodUtil.isNull(emailId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,emailId);
	        }
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	        
	        //if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			  /*  }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }*/
	        
	        if(MethodUtil.isNull(clientId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,clientId);
	        }
	        
	        if(MethodUtil.isNull(relationshipWithProposer)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,relationshipWithProposer);
	        }
	        
	        if(MethodUtil.isNull(education)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	            pstmt.setString(counter++,education);
	        }
	        
	        if(MethodUtil.isNull(industryType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,industryType);
	        }
	        
	        if(MethodUtil.isNull(fatherNameHusbandName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,fatherNameHusbandName);
	        }
	        
	        if(MethodUtil.isNull(organizationType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,organizationType);
	        }
	      
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_L2BI_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
			
	}

	public void update_NG_NB_L2BI_DETAILS(String pcliId, String insured, String occupation, String middleName,
			String firstName, String lastName, String dob, String gender, String typeOfVisa, String nationality,
			String natureOfDuties, String maritalStatus, String incomeSource, String title, String emailId,
			String exactIncome, String dobProof, String clientId, String relationshipWithProposer, String education,
			String industryType, String fatherNameHusbandName, String organizationType,Integer addition) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_L2BI_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	        //Integer maritalStatusInt=MethodUtil.StringToIntConverter(maritalStatus);
	        Integer incomeSourceInt=MethodUtil.StringToIntConverter(incomeSource);
	        Integer exactIncomeInt=MethodUtil.StringToIntConverter(exactIncome);
	        //Integer dobProofInt=MethodUtil.StringToIntConverter(dobProof);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	          
	        
	        
	        if(MethodUtil.isNull(insured)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,insured);
	        }
	        
	        if(MethodUtil.isNull(occupation)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,occupation);
	        }
	        
	        if(MethodUtil.isNull(middleName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,middleName);
	        }
	        
	        if(MethodUtil.isNull(firstName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,firstName);
	        }
	        
	        if(MethodUtil.isNull(lastName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,lastName);
	        }
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	    //    if(MethodUtil.isNull(gender)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	     /*   }else {
	        pstmt.setString(counter++,gender);
	        }
	      */  
	        if(MethodUtil.isNull(typeOfVisa)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,typeOfVisa);
	        }
	        
	        if(MethodUtil.isNull(nationality)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,nationality);
	        }
	        
	        if(MethodUtil.isNull(natureOfDuties)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,natureOfDuties);
	        }
	        
	       // if(maritalStatusInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			 /*   }else {
			      pstmt.setInt(counter++, maritalStatusInt);
			    }
	          */
	        
	        if(incomeSourceInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, incomeSourceInt);
			    }
	        
	        if(MethodUtil.isNull(title)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,title);
	        }
	        
	        if(MethodUtil.isNull(emailId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,emailId);
	        }
	        
	        
	        if(exactIncomeInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, exactIncomeInt);
			    }
	        
	        //if(dobProofInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			 /*
		     }else {
			      pstmt.setInt(counter++, dobProofInt);
			    }
	         */
	        if(MethodUtil.isNull(clientId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,clientId);
	        }
	        
	        if(MethodUtil.isNull(relationshipWithProposer)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,relationshipWithProposer);
	        }
	        
	        if(MethodUtil.isNull(education)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,education);
	        }
	        
	        if(MethodUtil.isNull(industryType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,industryType);
	        }
	        
	        if(MethodUtil.isNull(fatherNameHusbandName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,fatherNameHusbandName);
	        }
	        
	        if(MethodUtil.isNull(organizationType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,organizationType);
	        }
	        
	        if(pcliIdInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, pcliIdInt);
			    }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_L2BI_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void insert_NG_NB_LIST_NOMINEE_DETAILS(String pcliId, String nominee, String middleName, String firstName,
			String lastName, String dob, String gender, String relationshipProposer, String nationality,
			String percentage, String title, String emailId, String clientId, String education, String industryType,
			String panNumber, String reasonForNomination,Integer addition) {

		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_NOMINEE_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	        if(pcliIdInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			    }else {
			      pstmt.setInt(counter++, pcliIdInt);
			    }  
	        
	        if(MethodUtil.isNull(nominee)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	            pstmt.setString(counter++,nominee);
	        }
	        
	        if(MethodUtil.isNull(middleName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,middleName);
	        }
	        
	        if(MethodUtil.isNull(firstName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,firstName);
	        }
	        
	        if(MethodUtil.isNull(lastName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,lastName);
	        }
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	       // if(MethodUtil.isNull(gender)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	       /* }else {
	        pstmt.setString(counter++,gender);
	        }
	       */ 
	        	
	        if(MethodUtil.isNull(relationshipProposer)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,relationshipProposer);
	        }
	        
	        if(MethodUtil.isNull(nationality)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,nationality);
	        }
	        
	        if(MethodUtil.isNull(percentage)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,percentage);
	        }
	        
	        if(MethodUtil.isNull(title)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,title);
	        }
	        
	        if(MethodUtil.isNull(emailId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,emailId);
	        }
	        
	        if(MethodUtil.isNull(clientId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,clientId);
	        }
	        
	       // if(MethodUtil.isNull(education)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	       /* }else {
	        pstmt.setString(counter++,education);
	        }*/
	        
	       // if(MethodUtil.isNull(industryType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	       /* }else {
	        pstmt.setString(counter++,industryType);
	        }
	        */
	        if(MethodUtil.isNull(panNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,panNumber);
	        }
	        
	        if(MethodUtil.isNull(reasonForNomination)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,reasonForNomination);
	        }
	        
	        
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_LIST_NOMINEE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_NG_NB_LIST_NOMINEE_DETAILS(String pcliId, String nominee, String middleName, String firstName,
			String lastName, String dob, String gender, String relationshipProposer, String nationality,
			String percentage, String title, String emailId, String clientId, String education, String industryType,
			String panNumber, String reasonForNomination,Integer addition) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_NOMINEE_DETAILS);
	        //---------------------------: Number :----------------------------------
	        Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	        
	      //---------------------------: Date :----------------------------------
	        Long dobInt=MethodUtil.StringToLongConverter(dob);
	          
	        
	        
	        if(MethodUtil.isNull(nominee)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	            pstmt.setString(counter++,nominee);
	        }
	        
	        if(MethodUtil.isNull(middleName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,middleName);
	        }
	        
	        if(MethodUtil.isNull(firstName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,firstName);
	        }
	        
	        if(MethodUtil.isNull(lastName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,lastName);
	        }
	        
	        if(dobInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(dobInt));
	        }
	        
	       // if(MethodUtil.isNull(gender)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	       /* }else {
	        pstmt.setString(counter++,gender);
	        }
	       */ 
	        	
	        if(MethodUtil.isNull(relationshipProposer)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,relationshipProposer);
	        }
	        
	        if(MethodUtil.isNull(nationality)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,nationality);
	        }
	        
	        if(MethodUtil.isNull(percentage)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,percentage);
	        }
	        
	        if(MethodUtil.isNull(title)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,title);
	        }
	        
	        if(MethodUtil.isNull(emailId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,emailId);
	        }
	        
	        if(MethodUtil.isNull(clientId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,clientId);
	        }
	        
	       // if(MethodUtil.isNull(education)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	       /* }else {
	        pstmt.setString(counter++,education);
	        }*/
	        
	       // if(MethodUtil.isNull(industryType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	       /* }else {
	        pstmt.setString(counter++,industryType);
	        }
	        */
	        if(MethodUtil.isNull(panNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,panNumber);
	        }
	        
	        if(MethodUtil.isNull(reasonForNomination)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,reasonForNomination);
	        }
	        
	        if(pcliIdInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, pcliIdInt);
		    }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_LIST_NOMINEE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	
	}
	
}
