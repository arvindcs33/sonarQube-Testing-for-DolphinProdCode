package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class CaseAgentDAO {

	private final Logger logger = LoggerFactory.getLogger(CaseAgentDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration; 
	
	public boolean getCaseAgentExistOrNot(String caseId) {
		
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_CASE_AGENT);
	    	if(caseIdInt==null) {
	    		return false;
	    	}else {
	    		pstmt.setInt(counter, caseIdInt);	
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String wiName,String agentCode,String agentName,String commissionShare,String caseAgentID) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			//Integer caseAgentIDInt=MethodUtil.StringToIntConverterWithAddition(caseAgentID, DPHConstants.FIVE_CRORE);
			Integer commissionShareInt=MethodUtil.StringToIntConverter(commissionShare);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_CA_NG_NB_AGENT_INFORMATION);
	        if(wiNameInt==null) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        if(wiNameInt==null) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        if(MethodUtil.isNull(agentCode)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	   pstmt.setString(counter++, agentCode);
	        }
	        
	        if(MethodUtil.isNull(agentName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, agentName);	
	        }
	    	
	    	if(commissionShareInt==null) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, commissionShareInt);
		    }
	    	
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String wiName,String agentCode,String agentName,String commissionShare,String caseAgentID) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			Integer commissionShareInt=MethodUtil.StringToIntConverter(commissionShare);
			Integer caseAgentIDInt=MethodUtil.StringToIntConverter(caseAgentID);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_CA_NG_NB_AGENT_INFORMATION);
	        
	        if(MethodUtil.isNull(agentCode)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	   pstmt.setString(counter++, agentCode);
	        }
	        
	        if(MethodUtil.isNull(agentName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, agentName);	
	        }
	    	
	    	
	    	if(commissionShareInt==null) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, commissionShareInt);
		    }
	    	
	    	if(wiNameInt==null) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
}
