package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class MNYLMoneyDAO {

private final Logger logger=LoggerFactory.getLogger(MNYLMoneyDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;

	public boolean getMnylMoneyexistOrNot(String wiName) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_MONEY_SELECT);
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	if(wiNameInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,wiNameInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting MNYL_MONEY ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}

	
	
	
	public void insert_PClientAddress(String policyId,String moneyStatus,String clearedAmount,String unclearedAmount) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_MONEY_INSERT);
	        Double clearedAmountDouble=MethodUtil.StringToDoubleConverter(clearedAmount, 3);
	    	Double unclearedAmountDouble=MethodUtil.StringToDoubleConverter(unclearedAmount, 3);
	        if(MethodUtil.isNull(policyId)){
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,policyId );	
	        }
	        
	        if(MethodUtil.isNull(moneyStatus)){
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,moneyStatus );	
	        }
	    	
	    	if(clearedAmountDouble==null) {
	    		pstmt.setNull(counter++, Types.DOUBLE);
	    	}else {
	    		pstmt.setDouble(counter++, clearedAmountDouble);
	    	}
	    	
	    	if(unclearedAmountDouble==null) {
	    		pstmt.setNull(counter++, Types.DOUBLE);
	    	}else {
	    		pstmt.setDouble(counter++, unclearedAmountDouble);	
	    	}
	    	
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO MNYL_MONEY getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
	
public void update_PClientAddress(String policyId,String moneyStatus,String clearedAmount,String unclearedAmount) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_MONEY_UPDATE);
	        
	    	Double clearedAmountDouble=MethodUtil.StringToDoubleConverter(clearedAmount, 3);
	    	Double unclearedAmountDouble=MethodUtil.StringToDoubleConverter(unclearedAmount, 3);
	       
	        
	    	if(MethodUtil.isNull(moneyStatus)){
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,moneyStatus );	
	        }
	    	
	    	if(clearedAmountDouble==null) {
	    		pstmt.setNull(counter++, Types.DOUBLE);
	    	}else {
	    		pstmt.setDouble(counter++, clearedAmountDouble);
	    	}
	    	
	    	if(unclearedAmountDouble==null) {
	    		pstmt.setNull(counter++, Types.DOUBLE);
	    	}else {
	    		pstmt.setDouble(counter++, unclearedAmountDouble);	
	    	}
	    	
	    	if(MethodUtil.isNull(policyId)){
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,policyId );	
	        }
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO MNYL_MONEY getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

}
