package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class CasePlanFundsDAO {
	
	    private final Logger logger=LoggerFactory.getLogger(CaseCancelNeedDAO.class);
		
		@Autowired
		DolphinConfiguration dolphinConfiguration;
        
		@Autowired
		@Qualifier(value = "masterMap")
		Map<String,Map<String,Map>> masterMap;
		
		public boolean getCasePlanFundsExistOrNot(String wiName) {
			boolean returnOut=false;
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
		    	int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_PLAN_FUNDS_SELECT);
		    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
		    	if(wiNameInt==null) {
		    		return false;
			    }else {
			    	pstmt.setInt(counter,wiNameInt);
		    	}
		    	ResultSet rset=pstmt.executeQuery();
		    	if(rset.next()) {
		    		returnOut=true;
		    	}
		    }catch(Exception ec) {
		    	logger.error(" Error while getting CASE_PLAN_FUNDS ",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
			return returnOut;
		}
		
		public void insert_MnylCasePlanFunds(String caseId,String fundId,String mnylAllocatePt,String mnylPlanInvestId) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
		    	String fundIdStr=masterMap.get("masterMap").get(DPHConstants.MNYL_FUND_LIST).get(fundId)+"";
		    	Integer fundIdInt=MethodUtil.StringToIntConverter(fundIdStr);
		    	//Integer mnylPlanInvestIdInt=MethodUtil.StringToIntConverterWithAddition(mnylPlanInvestId,DPHConstants.FIVE_CRORE);
		        Double mnylAllocatePtdouble=MethodUtil.StringToDoubleConverter(mnylAllocatePt,2);
		        pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_PLAN_FUNDS_INSERT);
		        if(caseIdInt==null) {
		    		pstmt.setNull(counter++,Types.INTEGER);
		    	}else {
		    		pstmt.setInt(counter++, caseIdInt);
		    	}
		        
		        if(caseIdInt==null) {
		    		pstmt.setNull(counter++,Types.INTEGER);
		    	}else {
		    		pstmt.setInt(counter++, caseIdInt);
		    	}
		        
		        if(fundIdInt==null) {
		    		pstmt.setNull(counter++,Types.INTEGER);
		    	}else {
		    		pstmt.setInt(counter++, fundIdInt);
		    	}
		        
		      
		    	
		    	
		    	if(mnylAllocatePtdouble==null) {
		    		pstmt.setNull(counter++, Types.DOUBLE);
		    	}else {
		    		pstmt.setDouble(counter++, mnylAllocatePtdouble);
		    	}
		    	
		    	
		    	pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("INSERTING INTO MNYL_CASE_NEED getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}

		public void update_MnylCasePlanFunds(String caseId,String fundId,String mnylAllocatePt,String mnylPlanInvestId) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_PLAN_FUNDS_UPDATE);
		    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
		    	String fundIdStr=masterMap.get("masterMap").get(DPHConstants.MNYL_FUND_LIST).get(fundId)+"";
		    	Integer fundIdInt=MethodUtil.StringToIntConverter(fundIdStr);
		        Double mnylAllocatePtdouble=MethodUtil.StringToDoubleConverter(mnylAllocatePt,2);
		       // Integer mnylPlanInvestIdInt=MethodUtil.StringToIntConverter(mnylPlanInvestId);
		        
		        
		    	
		      
                    if(fundIdInt==null) {
			    		pstmt.setNull(counter++,Types.INTEGER);
			    	}else {
			    		pstmt.setInt(counter++, fundIdInt);
			    	}
		    
		    	
		    	if(mnylAllocatePtdouble==null) {
		    		pstmt.setNull(counter++, Types.DOUBLE);
		    	}else {
		    		pstmt.setDouble(counter++, mnylAllocatePtdouble);
		    	}
		    	
		    	if(caseIdInt==null) {
		    		pstmt.setNull(counter++,Types.INTEGER);
		    	}else {
		    		pstmt.setInt(counter++, caseIdInt);
		    	}
		    	
		    	
		    	pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("INSERTING INTO MNYL_CASE_NEED getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}

			
}
