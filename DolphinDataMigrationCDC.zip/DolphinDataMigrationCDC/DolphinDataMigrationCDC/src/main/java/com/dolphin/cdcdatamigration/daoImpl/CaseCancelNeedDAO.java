package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class CaseCancelNeedDAO {
private final Logger logger=LoggerFactory.getLogger(CaseCancelNeedDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;
	
	@Autowired
	@Qualifier(value = "masterMap")
	Map<String,Map<String,Map>> masterMap;
	

	public boolean getMnylCaseCancelExistOrNot(String cancelId) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_CANCEL_DETAIL_SELECT);
	    	Integer cancelIdInt=MethodUtil.StringToIntConverter(cancelId);
	    	if(cancelIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,cancelIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting MNYL_CASE_CANCEL",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	public void insert_MnylCaseCancel(String caseId,String reasonCode,String cancelDate,String cancelId) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	String resoncodeStr=masterMap.get("masterMap").get(DPHConstants.MNYL_CASE_CANCEL_REASONS).get(reasonCode)+"";
            Integer reasonCodeInt=MethodUtil.StringToIntConverter(resoncodeStr);
	        Long cancelDateLong=MethodUtil.StringToLongConverter(cancelDate);
	        //Integer cancelIdInt=MethodUtil.StringToIntConverter(cancelId);
	        pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_CANCEL_DETAIL_INSERT);
	    	
	        
	        if(caseIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, caseIdInt);
	    	}
	        
	        
	        if(caseIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, caseIdInt);
	    	}
	    	
	    	if(reasonCodeInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, reasonCodeInt);
	    	}
	    	
	    	
	    	if(cancelDateLong==null) {
	    		pstmt.setNull(counter++, Types.DATE);
	    	}else {
	    		pstmt.setTimestamp(counter++,new Timestamp(cancelDateLong) );
	    	}
	    	
	    	
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO MNYL_CASE_CANCEL getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

public void update_MnylCaseCancel(String caseId,String reasonCode,String cancelDate,String cancelId) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_CANCEL_DETAIL_UPDATE);
	        Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	String resoncodeStr=masterMap.get("masterMap").get(DPHConstants.MNYL_CASE_CANCEL_REASONS).get(reasonCode)+"";
            Integer reasonCodeInt=MethodUtil.StringToIntConverter(resoncodeStr);

	        Long cancelDateLong=MethodUtil.StringToLongConverter(cancelDate);
	        
	    	
	    	
	    	if(reasonCodeInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, reasonCodeInt);
	    	}
	    	
	        pstmt.setNull(counter++, Types.INTEGER);
	    	if(cancelDateLong==null) {
	    		pstmt.setNull(counter++, Types.DATE);
	    	}else {
	    		pstmt.setTimestamp(counter++,new Timestamp(cancelDateLong) );
	    	}
	    	
	    	
	    	if(caseIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, caseIdInt);
	    	}
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO MNYL_CASE_CANCEL getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
	
public boolean getMnylCaseNeedExistOrNot(String wiName) {
	boolean returnOut=false;
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_NEED_LST_SELECT);
    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
    	if(wiNameInt==null) {
    		return false;
	    }else {
	    	pstmt.setInt(counter,wiNameInt);
    	}
    	ResultSet rset=pstmt.executeQuery();
    	if(rset.next()) {
    		returnOut=true;
    	}
    }catch(Exception ec) {
    	logger.error(" Error while getting MNYL_CASE_CANCEL",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnOut;
}

public void insert_MnylCaseNeed(String caseId,String need,String caseNeedId) {
	
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
		int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
    	String  needStr=masterMap.get("masterMap").get(DPHConstants.MNYL_NEED_LIST).get(need)+"";
        Integer needInt=MethodUtil.StringToIntConverter(needStr);
        pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_NEED_LST_INSERT);
        
        if(caseIdInt==null) {
        	pstmt.setNull(counter++,Types.INTEGER);
        }else {
        	pstmt.setInt(counter++,caseIdInt);
        }
        
    	if(caseIdInt==null) {
    		pstmt.setNull(counter++, Types.INTEGER);
    	}else {
    		pstmt.setInt(counter++, caseIdInt);
    	}
    	
        if(needInt==null) {
        
        	pstmt.setNull(counter++,Types.INTEGER);
         }else {
        	pstmt.setInt(counter++,needInt);	
        }
    	
       
    	
    	pstmt.execute();
    }catch(Exception ec) {
    	logger.error("INSERTING INTO MNYL_CASE_NEED getting Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
}

public void update_MnylCaseNeed(String caseId,String need,String caseNeedId) {
	
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
		int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_NEED_LST_UPDATE);
    	
        Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
        String  needStr=masterMap.get("masterMap").get(DPHConstants.MNYL_NEED_LIST).get(need)+"";
        Integer needInt=MethodUtil.StringToIntConverter(needStr);
    	
        if(needInt==null) {
            
        	pstmt.setNull(counter++,Types.INTEGER);
         }else {
        	pstmt.setInt(counter++,needInt);	
        }
        
    	if(caseIdInt==null) {
    		pstmt.setNull(counter++, Types.INTEGER);
    	}else {
    		pstmt.setInt(counter++, caseIdInt);
    	}
    	
    	pstmt.execute();
    }catch(Exception ec) {
    	logger.error("INSERTING INTO MNYL_CASE_NEED getting Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
}




}
