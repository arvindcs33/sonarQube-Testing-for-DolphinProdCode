package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class MasterDAO {

	@Autowired
	DolphinConfiguration dolphinConfiguration;
	
	private final Logger logger = LoggerFactory.getLogger(MasterDAO.class);
	
    public Map  permPayTermPayment() {
		
    	Map returnMap=new HashMap();
    	Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PREM_PAY_TERM_PAYMNT);
	    	ResultSet rset=pstmt.executeQuery();
	    	while(rset.next()) {
	    		Integer value=rset.getInt("CODE");
	    		String  key=rset.getString("DES");
	    		returnMap.put(key,value);
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_PREM_PAY_TERM_PAYMNT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnMap;
	}
	
    
public Map  baseProductsExt() {
		
    	Map returnMap=new HashMap();
    	Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PREM_PAY_TERM_PAYMNT);
	    	ResultSet rset=pstmt.executeQuery();
	    	while(rset.next()) {
	    		Integer value=rset.getInt("CODE");
	    		String  key=rset.getString("DES");
	    		returnMap.put(key,value);
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_PREM_PAY_TERM_PAYMNT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnMap;
	}
	
	public Map  premPayTerm() {
		
		Map returnMap=new HashMap();
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PREM_PAY_TERM);
	    	ResultSet rset=pstmt.executeQuery();
	    	while(rset.next()) {
	    		Integer value=rset.getInt("CODE");
	    		String  key=rset.getString("DES");
	    		returnMap.put(key,value);
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_PREM_PAY_TERM Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnMap;
	}

	
public Map  modeOfRenewal() {
		
		Map returnMap=new HashMap();
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PREM_PAY_TERM);
	    	ResultSet rset=pstmt.executeQuery();
	    	while(rset.next()) {
	    		Integer value=rset.getInt("CODE");
	    		String  key=rset.getString("DES");
	    		returnMap.put(key,value);
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_PREM_PAY_TERM Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnMap;
	}



public Map  accTypeDet() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CC_ACC_TYPE_DET);
    	ResultSet rset=pstmt.executeQuery();
    	while(rset.next()) {
    		Integer value=rset.getInt("CODE");
    		String  key=rset.getString("DES");
    		returnMap.put(key,value);
    	}
    }catch(Exception ec) {
    	logger.error("MNYL_CC_ACC_TYPE_DET Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnMap;
}



	public Map  baseProd() {
		
		Map returnMap=new HashMap();
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_BASE_PROD);
	    	ResultSet rset=pstmt.executeQuery();
	    	while(rset.next()) {
	    		Integer value=rset.getInt("CODE");
	    		String  key=rset.getString("DES");
	    		returnMap.put(key,value);
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_BASE_PROD Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnMap;
	}

	public Map  baseProducts() {
		
		Map returnMap=new HashMap();
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_BASE_PRODUCTS);
	    	ResultSet rset=pstmt.executeQuery();
	    	while(rset.next()) {
	    		String value=rset.getString("CODE");
	    		String  key=rset.getString("DES");
	    		returnMap.put(key,value);
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_BASE_PRODUCTS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnMap;
	}

	
	
public Map  productSolution() {
		
		Map returnMap=new HashMap();
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PRODUCT_SOUTION);
	    	ResultSet rset=pstmt.executeQuery();
	    	while(rset.next()) {
	    		Integer value=rset.getInt("CODE");
	    		String  key=rset.getString("DES");
	    		returnMap.put(key,value);
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_PRODUCT_SOUTION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnMap;
	}

public Map  mnylChannelCode() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CHANNEL_CODE);
    	ResultSet rset=pstmt.executeQuery();
    	while(rset.next()) {
    		String value=rset.getString("CODE");
    		String  key=rset.getString("DES");
    		returnMap.put(key,value);
    	}
    }catch(Exception ec) {
    	logger.error("MNYL_CHANNEL_CODE Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnMap;
}



public Map  mnylObjOfInsurer() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_OBJ_OF_INSUR);
    	ResultSet rset=pstmt.executeQuery();
    	while(rset.next()) {
    		String value=rset.getString("CODE");
    		String  key=rset.getString("DES");
    		returnMap.put(key,value);
    	}
    }catch(Exception ec) {
    	logger.error("MNYL_OBJ_OF_INSUR Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnMap;
}


public Map  mnylSourceOfSale() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_SOURCE_OF_SALE);
    	ResultSet rset=pstmt.executeQuery();
    	while(rset.next()) {
    		String value=rset.getString("CODE");
    		String  key=rset.getString("DES");
    		returnMap.put(key,value);
    	}
    }catch(Exception ec) {
    	logger.error("MNYL_SOURCE_OF_SALE Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnMap;
}

public Map  mnylRural() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_RURAL);
    	ResultSet rset=pstmt.executeQuery();
    	while(rset.next()) {
    		Integer value=rset.getInt("CODE");
    		String  key=rset.getString("DES");
    		returnMap.put(key,value);
    	}
    }catch(Exception ec) {
    	logger.error("MNYL_RURAL Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnMap;
}



//------------------------------------------------------------------ ARVIND Code ---------- Date 7th OCT 2020------------------------------------------------------------------------


/*
public Map  ctryDetails() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
 PreparedStatement pstmt=null;
	try {
 	
 	conn= dolphinConfiguration.getDolphinConnection();
 	pstmt=conn.prepareStatement(DPHConstants.CTRY_DETAILS);
 	ResultSet rset=pstmt.executeQuery();
 	while(rset.next()) {
 		Integer value=rset.getInt("CODE");
 		String  key=rset.getString("DESC");
 		returnMap.put(value,key);
 	}
 }catch(Exception ec) {
 	logger.error("CTRY_DETAILS Error",ec);
 }
 finally {
 	if(conn!=null) {
 		try {
 		conn.close();
 		}catch(Exception ec) {
 			logger.error("error while closing the connection",ec);
 		}
 		
 	}
 	if(pstmt!=null) {
 	    try {
 		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
 	}
 }
	
	return returnMap;
}
*/


public Map  ngNbListQcRequirements() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
 PreparedStatement pstmt=null;
	try {
 	
 	conn= dolphinConfiguration.getDolphinConnection();
 	pstmt=conn.prepareStatement(DPHConstants.NG_NB_LIST_QC_REQUIREMENTS);
 	ResultSet rset=pstmt.executeQuery();
 	while(rset.next()) {
 		Integer value=rset.getInt("CODE");
 		String  key=rset.getString("DES");
 		returnMap.put(key,value);
 	}
 }catch(Exception ec) {
 	logger.error("NG_NB_LIST_QC_REQUIREMENTS Error",ec);
 }
 finally {
 	if(conn!=null) {
 		try {
 		conn.close();
 		}catch(Exception ec) {
 			logger.error("error while closing the connection",ec);
 		}
 		
 	}
 	if(pstmt!=null) {
 	    try {
 		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
 	}
 }
	
	return returnMap;
}


/*
public Map  uwDecision() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
 PreparedStatement pstmt=null;
	try {
 	
 	conn= dolphinConfiguration.getDolphinConnection();
 	pstmt=conn.prepareStatement(DPHConstants.UW_DECISION);
 	ResultSet rset=pstmt.executeQuery();
 	while(rset.next()) {
 		Integer value=rset.getInt("CODE");
 		String  key=rset.getString("DESC");
 		returnMap.put(value,key);
 	}
 }catch(Exception ec) {
 	logger.error("UW_DECISION Error",ec);
 }
 finally {
 	if(conn!=null) {
 		try {
 		conn.close();
 		}catch(Exception ec) {
 			logger.error("error while closing the connection",ec);
 		}
 		
 	}
 	if(pstmt!=null) {
 	    try {
 		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
 	}
 }
	
	return returnMap;
}
*/

public Map  mnylFundList() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
 PreparedStatement pstmt=null;
	try {
 	
 	conn= dolphinConfiguration.getDolphinConnection();
 	pstmt=conn.prepareStatement(DPHConstants.MNYL_FUND_LIST);
 	ResultSet rset=pstmt.executeQuery();
 	while(rset.next()) {
 		Integer value=rset.getInt("CODE");
 		String  key=rset.getString("DES");
 		returnMap.put(key,value);
 	}
 }catch(Exception ec) {
 	logger.error("MNYL_FUND_LIST Error",ec);
 }
 finally {
 	if(conn!=null) {
 		try {
 		conn.close();
 		}catch(Exception ec) {
 			logger.error("error while closing the connection",ec);
 		}
 		
 	}
 	if(pstmt!=null) {
 	    try {
 		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
 	}
 }
	
	return returnMap;
}


/*
public Map  ngNbProposerDetails() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
 PreparedStatement pstmt=null;
	try {
 	
 	conn= dolphinConfiguration.getDolphinConnection();
 	pstmt=conn.prepareStatement(DPHConstants.NG_NB_PROPOSER_DETAILS);
 	ResultSet rset=pstmt.executeQuery();
 	while(rset.next()) {
 		Integer value=rset.getInt("CODE");
 		String  key=rset.getString("DES");
 		returnMap.put(value,key);
 	}
 }catch(Exception ec) {
 	logger.error("NG_NB_PROPOSER_DETAILS Error",ec);
 }
 finally {
 	if(conn!=null) {
 		try {
 		conn.close();
 		}catch(Exception ec) {
 			logger.error("error while closing the connection",ec);
 		}
 		
 	}
 	if(pstmt!=null) {
 	    try {
 		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
 	}
 }
	
	return returnMap;
}
*/

/*
public Map  mnylKickoutMsgs() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
 PreparedStatement pstmt=null;
	try {
 	
 	conn= dolphinConfiguration.getDolphinConnection();
 	pstmt=conn.prepareStatement(DPHConstants.MNYL_KICKOUT_MSGS);
 	ResultSet rset=pstmt.executeQuery();
 	while(rset.next()) {
 		Integer value=rset.getInt("CODE");
 		String  key=rset.getString("DES");
 		returnMap.put(value,key);
 	}
 }catch(Exception ec) {
 	logger.error("MNYL_KICKOUT_MSGS Error",ec);
 }
 finally {
 	if(conn!=null) {
 		try {
 		conn.close();
 		}catch(Exception ec) {
 			logger.error("error while closing the connection",ec);
 		}
 		
 	}
 	if(pstmt!=null) {
 	    try {
 		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
 	}
 }
	
	return returnMap;
}
*/

public Map  caseCancelReasons() {
	
	Map returnMap=new HashMap();
	Connection conn=null;
 PreparedStatement pstmt=null;
	try {
 	
 	conn= dolphinConfiguration.getDolphinConnection();
 	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_CANCEL_REASONS);
 	ResultSet rset=pstmt.executeQuery();
 	while(rset.next()) {
 		Integer value=rset.getInt("CODE");
 		String  key=rset.getString("DES");
 		returnMap.put(key,value);
 	}
 }catch(Exception ec) {
 	logger.error("MNYL_CASE_CANCEL_REASONS Error",ec);
 }
 finally {
 	if(conn!=null) {
 		try {
 		conn.close();
 		}catch(Exception ec) {
 			logger.error("error while closing the connection",ec);
 		}
 		
 	}
 	if(pstmt!=null) {
 	    try {
 		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
 	}
 }
	
	return returnMap;
}



   public Map  needList () {
	
	Map returnMap=new HashMap();
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_NEED_LIST);
    	ResultSet rset=pstmt.executeQuery();
    	while(rset.next()) {
    		Integer value=rset.getInt("CODE");
    		String  key=rset.getString("DES");
    		returnMap.put(key,value);
    	}
    }catch(Exception ec) {
    	logger.error("MNYL_NEED_LIST Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnMap;
}


//------------------------------------------------- End Code --------------------------------Arvind -Code ---------------------------------------------------------

}
