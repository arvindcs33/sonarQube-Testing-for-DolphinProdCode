package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class PClientAddressDAO {

private final Logger logger=LoggerFactory.getLogger(PClientAddressDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;

	public boolean getPClientAddressSelectCRA(String pcliId,Integer addition) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId, addition);
	    	pstmt=conn.prepareStatement(DPHConstants.PCLIENT_ADDRESS_SELECT_CRA);
	    	if(pcliIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,pcliIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting PCLIENT_ADDRESS CRA",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}

	
	public boolean getPClientAddressSelectPRA(String pcliId,Integer addition) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.PCLIENT_ADDRESS_SELECT_PRA);
	    	Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	    	if(pcliIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,pcliIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting PCLIENT_ADDRESS PRA ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}


	
	public void insert_PClientAddress(String pcliId,String adRTCode,String stPrCd,String ctryCd,String pcladrZipCd,String mnylVillage,String mnylLandmark,
		    String mnylSector,String mnylHouseNo,String mnylMobleNo1,String mnylMobleNo2,String mnylLandline1,
		    String mnylStdCode,String cityName,String stateName,Integer addition) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
			Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
			logger.info("PCLIIDInt is=="+pcliIdInt);
	        conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.PCLIENT_ADDRESS_INSERT);
	         
	    	if(pcliIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, pcliIdInt);
	    	}
	    	
	    	if(MethodUtil.isNull(adRTCode)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	    pstmt.setString(counter++, adRTCode);
	    	}
	    	
	    	pstmt.setNull(counter++,Types.VARCHAR);
	    	//pstmt.setString(counter++, stPrCd);  DISCUSS WITH MANGLESH
	    	if(MethodUtil.isNull(ctryCd)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, ctryCd);
	    	}
	    	
	    	if(MethodUtil.isNull(pcladrZipCd)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, pcladrZipCd);
	    	}
	    	

	    	if(MethodUtil.isNull(mnylVillage)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylVillage);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylLandmark)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylLandmark);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylSector)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylSector);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylHouseNo)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylHouseNo);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylMobleNo1)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylMobleNo1);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylMobleNo2)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylMobleNo2);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylLandline1)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	    pstmt.setString(counter++,mnylLandline1);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylStdCode)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylStdCode);
	    	}
	    	
	    	if(MethodUtil.isNull(cityName)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,cityName);
	    	}
	    	
	    	if(MethodUtil.isNull(stateName)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,stateName);
	    	}
	    	
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO PCLIENT_ADDRESS getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_PClientAddress(String pcliId,String adRTCode,String stPrCd,String ctryCd,String pcladrZipCd,String mnylVillage,String mnylLandmark,
		    String mnylSector,String mnylHouseNo,String mnylMobleNo1,String mnylMobleNo2,String mnylLandline1,
		    String mnylStdCode,String cityName,String stateName,Integer addition) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer pcliIdInt=MethodUtil.StringToIntConverterWithAddition(pcliId,addition);
	    	pstmt=conn.prepareStatement(DPHConstants.PCLIENT_ADDRESS_UPDATE);
	    	
	    	
	    	pstmt.setNull(counter++,Types.VARCHAR);
	    	//pstmt.setString(counter++, stPrCd);  DISCUSS WITH MANGLESH
	    	if(MethodUtil.isNull(ctryCd)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, ctryCd);
	    	}
	    	
	    	if(MethodUtil.isNull(pcladrZipCd)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, pcladrZipCd);
	    	}
	    	

	    	if(MethodUtil.isNull(mnylVillage)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylVillage);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylLandmark)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylLandmark);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylSector)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylSector);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylHouseNo)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylHouseNo);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylMobleNo1)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylMobleNo1);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylMobleNo2)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylMobleNo2);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylLandline1)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	    pstmt.setString(counter++,mnylLandline1);
	    	}
	    	
	    	if(MethodUtil.isNull(mnylStdCode)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,mnylStdCode);
	    	}
	    	
	    	if(MethodUtil.isNull(cityName)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,cityName);
	    	}
	    	
	    	if(MethodUtil.isNull(stateName)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++,stateName);
	    	}
	    	 
	    	
	    	 
	    	if(pcliIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, pcliIdInt);
	    	}
		    	
	    	if(MethodUtil.isNull(adRTCode)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    	    pstmt.setString(counter++, adRTCode);
	    	}
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE INTO PCLIENT_ADDRESS getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
	
	
public void insert_PClientAssocFemaleInformation(String wiName,String isPregnentActivities,String insertionOrderId) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_FEMALE_INFO_INSERT);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	Integer insertionOrderIdint=MethodUtil.StringToIntConverterWithAddition(wiName,DPHConstants.FIVE_CRORE);
	        if(insertionOrderIdint==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, insertionOrderIdint);
	        }
	    	
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	    	
	    	if(insertionOrderIdint==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, insertionOrderIdint);
	        }
	    	
	    	pstmt.setString(counter++,isPregnentActivities);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO PCLIENT_ADDRESS getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_PClientAssocFemaleInformation(String wiName,String isPregnentActivities) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_FEMALE_INFO_UPDATE);
	        if(MethodUtil.isNull(isPregnentActivities))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, isPregnentActivities);
	        }
	        
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
		    
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE INTO PCLIENT_ADDRESS getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
	
	
	public boolean getPClientAssocSelect(String wiName) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_SELECT);
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	if(wiNameInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,wiNameInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting PCLIENT_ASSOC ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	public void insert_PClientAssocNominees(String caseId,String cpCliSameOwnerInd,String cpcli_id) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NOMINEE_DETAILS_INSERT);
	        Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	        Integer cpcli_idInt=MethodUtil.StringToIntConverter(cpcli_id);
	        
	        if(cpcli_idInt==null) {
	           pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	           pstmt.setInt(counter++, cpcli_idInt);	
	        }
	        
	        if(caseIdInt==null) {
	           pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	           pstmt.setInt(counter++, caseIdInt);	
	        }
	        
	        if(cpcli_idInt==null) {
	           pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	           pstmt.setInt(counter++, cpcli_idInt);	
	        }
	        
	        if(MethodUtil.isNull(cpCliSameOwnerInd)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, cpCliSameOwnerInd);
	        }
	        
	    	
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO PCLIENT_ASSOC  NOMINEE For Nominee getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
	
	
public void update_PClientAssocNominees(String caseId,String cpCliSameOwnerInd) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NOMINEE_DETAILS_UPDATE);
	    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	if(MethodUtil.isNull(cpCliSameOwnerInd)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);	
	    	}else {
	    	    pstmt.setString(counter++, cpCliSameOwnerInd);
	    	}
	    	
	        if(caseIdInt==null) {
	           pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	           pstmt.setInt(counter++, caseIdInt);	
	        }
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATING INTO PCLIENT_ASSOC NOMINEE for Nominee getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

    ////////////////////////////////////////////////////PCLIENT_ADDRESS_CI STARTS////////////////////////////////////////////////////////////////

public boolean getPClientAddressCISelectCRA(String pcliIdCI) {
	boolean returnOut=false;
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PCLIENT_ADDRESS_CI_SELECT_CRA);
    	Integer pcliIdCIInt=MethodUtil.StringToIntConverter(pcliIdCI);
    	if(pcliIdCIInt==null) {
    		return false;
	    }else {
	    	pstmt.setInt(counter,pcliIdCIInt);
    	}
    	ResultSet rset=pstmt.executeQuery();
    	if(rset.next()) {
    		returnOut=true;
    	}
    }catch(Exception ec) {
    	logger.error(" Error while getting PCLIENT_ADDRESS_CI CRA",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnOut;
}


public boolean getPClientAddressCISelectPRA(String pcliIdCI) {
	boolean returnOut=false;
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
    	int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PCLIENT_ADDRESS_CI_SELECT_PRA);
    	Integer pcliIdCIInt=MethodUtil.StringToIntConverter(pcliIdCI);
    	if(pcliIdCIInt==null) {
    		return false;
	    }else {
	    	pstmt.setInt(counter,pcliIdCIInt);
    	}
    	ResultSet rset=pstmt.executeQuery();
    	if(rset.next()) {
    		returnOut=true;
    	}
    }catch(Exception ec) {
    	logger.error(" Error while getting PCLIENT_ADDRESS_CI PRA ",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
	return returnOut;
}



public void insert_PClientAddressCI(String pcliId,String mnylVillage,
		String mnylLandmark,
	    String mnylSector,String mnylHouseNo,String mnylMobleNo1,
	    String mnylMobleNo2,
	    String mnylLandline1,
	    String mnylStdCode,String pcladrZipCd,String adRTCode,String stPrCd,
	    String ctryCd,String cityName,String stateName) {
	
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
		int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PCLIENT_ADDRESS_INSERT_CI);
        Integer pcliIdInt=MethodUtil.StringToIntConverter(pcliId);
    	if(pcliIdInt==null) {
    		pstmt.setNull(counter++, Types.INTEGER);
    	}else {
    		pstmt.setInt(counter++, pcliIdInt);
    	}
    	
    	if(MethodUtil.isNull(mnylVillage)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    		pstmt.setString(counter++, mnylVillage);
    	}
    	
    	if(MethodUtil.isNull(mnylLandmark)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++, mnylLandmark);
    	}
    	

    	if(MethodUtil.isNull(mnylSector)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++, mnylSector);
    	}
    	
    	if(MethodUtil.isNull(mnylHouseNo)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylHouseNo);
    	}
    	
    	if(MethodUtil.isNull(mnylMobleNo1)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylMobleNo1);
    	}
    	
    	if(MethodUtil.isNull(mnylMobleNo2)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylMobleNo2);
    	}
    	
    	if(MethodUtil.isNull(mnylLandline1)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylLandline1);
    	}
    	
    	if(MethodUtil.isNull(mnylStdCode)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylStdCode);
    	}
    	
    	if(MethodUtil.isNull(pcladrZipCd)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,pcladrZipCd);
    	}
    	
    	if(MethodUtil.isNull(adRTCode)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,adRTCode);
    	}
    	
    	pstmt.setNull(counter++, Types.VARCHAR);
    	//pstmt.setString(counter++,stPrCd); Discuss With Mangaleshwar
    	if(MethodUtil.isNull(ctryCd)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,ctryCd);
    	}
    	
    	if(MethodUtil.isNull(cityName)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,cityName);
    	}
    	
    	if(MethodUtil.isNull(stateName)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,stateName);
    	}
    	pstmt.execute();
    }catch(Exception ec) {
    	logger.error("INSERTING INTO PCLIENT_ADDRESS_CI getting Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
}

public void update_PClientAddressCI(String pcliId,String adRTCode,String stPrCd,String ctryCd,String pcladrZipCd,String mnylVillage,String mnylLandmark,
	    String mnylSector,String mnylHouseNo,String mnylMobleNo1,String mnylMobleNo2,String mnylLandline1,
	    String mnylStdCode,String cityName,String stateName) {
	
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
		int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.MNYL_PCLIENT_ADDRESS_UPDATE_CI);
    	Integer pcliIdInt=MethodUtil.StringToIntConverter(pcliId);
    	
    	if(MethodUtil.isNull(mnylVillage)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    		pstmt.setString(counter++, mnylVillage);
    	}
    	
    	if(MethodUtil.isNull(mnylLandmark)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++, mnylLandmark);
    	}
    	

    	if(MethodUtil.isNull(mnylSector)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++, mnylSector);
    	}
    	
    	if(MethodUtil.isNull(mnylHouseNo)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylHouseNo);
    	}
    	
    	if(MethodUtil.isNull(mnylMobleNo1)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylMobleNo1);
    	}
    	
    	if(MethodUtil.isNull(mnylMobleNo2)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylMobleNo2);
    	}
    	
    	if(MethodUtil.isNull(mnylLandline1)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylLandline1);
    	}
    	
    	if(MethodUtil.isNull(mnylStdCode)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,mnylStdCode);
    	}
    	
    	if(MethodUtil.isNull(pcladrZipCd)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,pcladrZipCd);
    	}
    	
    	
    	
    	pstmt.setNull(counter++, Types.VARCHAR);
    	//pstmt.setString(counter++,stPrCd); Discuss With Mangaleshwar
    	if(MethodUtil.isNull(ctryCd)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,ctryCd);
    	}
    	
    	if(MethodUtil.isNull(cityName)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,cityName);
    	}
    	
    	if(MethodUtil.isNull(stateName)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,stateName);
    	}
    	
    	if(MethodUtil.isNull(adRTCode)) {
    		pstmt.setNull(counter++,Types.VARCHAR);
    	}else {
    	pstmt.setString(counter++,adRTCode);
    	}
    	
    	if(pcliIdInt==null) {
    		pstmt.setNull(counter++, Types.INTEGER);
    	}else {
    		pstmt.setInt(counter++, pcliIdInt);
    	}
    	pstmt.execute();
    }catch(Exception ec) {
    	logger.error("UPDATE INTO PCLIENT_ADDRESS_CI getting Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
}


	
   ////////////////////////////////////////////////////PCLIENT_ADDRESS_CI ENDS////////////////////////////////////////////////////////////////


   
		public void insert_PClientAssocNgNBExtTables(String cpCliID,String caseId,String cpCliAgeNum
				,String cpcliSamePayrInd) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
				//INSERT INTO CASE_PCLIENT_ASSOC_CI(CPCLI_ID,CASE_ID,CPCLI_AGE_NUM,CPCLI_SAME_PAYR_IND) VALUES(?,?,?,?)"
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NG_NB_EXT_TABLE_CI_INSERT);
		        
		    	Integer cpCliIDInt=MethodUtil.StringToIntConverter(cpCliID);
		    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
		    	Integer cpCliAgeNumInt=MethodUtil.StringToIntConverter(cpCliAgeNum);
		        if(cpCliIDInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, cpCliIDInt);
		        }
		        
		        if(caseIdInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, caseIdInt);
		        }
		        
		        if(cpCliAgeNumInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        	
		        }else {
		        	pstmt.setInt(counter++, cpCliAgeNumInt);
		        }
		        
		        if(MethodUtil.isNull(cpcliSamePayrInd)) {
		        	   pstmt.setNull(counter++, Types.VARCHAR);	
		        }else {
		            pstmt.setString(counter++, cpcliSamePayrInd);
		        }
		        
		        pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("INSERTING INTO PCLIENT_ASSOC  NOMINEE For Nominee getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}
		
		
		public void update_PClientAssocNgNBExtTables(String cpCliID,String caseId,String cpCliAgeNum
				,String cpcliSamePayrInd) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NG_NB_EXT_TABLE_CI_UPDATE);
		    	Integer cpCliIDInt=MethodUtil.StringToIntConverter(cpCliID);
		    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
		    	Integer cpCliAgeNumInt=MethodUtil.StringToIntConverter(cpCliAgeNum);
		        if(caseIdInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, caseIdInt);
		        }
		        
		        if(cpCliAgeNumInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        	
		        }else {
		        	pstmt.setInt(counter++, cpCliAgeNumInt);
		        }
		        if(MethodUtil.isNull(cpcliSamePayrInd)) {
		        	   pstmt.setNull(counter++, Types.VARCHAR);	
		        }else {
		            pstmt.setString(counter++, cpcliSamePayrInd);
		        }
		    	
		        if(cpCliIDInt==null) {
		        	pstmt.setNull(counter++, Types.INTEGER);
		        }else {
		        	pstmt.setInt(counter++, cpCliIDInt);
		        }
		        pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("UPDATING INTO PCLIENT_ASSOC NOMINEE for Nominee getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}

		public void insert_PClientAssocCiNominees(String cpCliID,String cpCliSameOwnerInd) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NG_NB_LIST_NOMINEE_DETAILS_CI_INSERT);
		        Integer cpCliIDInt=MethodUtil.StringToIntConverter(cpCliID);
		        if(cpCliIDInt==null) {
		           pstmt.setNull(counter++, Types.INTEGER);	
		        }else {
		           pstmt.setInt(counter++, cpCliIDInt);	
		        }
		        pstmt.setString(counter++, cpCliSameOwnerInd);
		    	pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("INSERTING INTO PCLIENT_ASSOC  NOMINEE For Nominee getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}
		
		
	public void update_PClientAssocCiNominees(String cpCliID,String cpCliSameOwnerInd) {
			
			Connection conn=null;
		    PreparedStatement pstmt=null;
			try {
				int counter=1;
		    	conn= dolphinConfiguration.getDolphinConnection();
		    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NG_NB_LIST_NOMINEE_DETAILS_CI_UPDATE);
		    	Integer cpCliIDInt=MethodUtil.StringToIntConverter(cpCliID);
		    	pstmt.setString(counter++, cpCliSameOwnerInd);
		        if(cpCliIDInt==null) {
		           pstmt.setNull(counter++, Types.INTEGER);	
		        }else {
		           pstmt.setInt(counter++, cpCliIDInt);	
		        }
		        pstmt.execute();
		    }catch(Exception ec) {
		    	logger.error("UPDATING INTO PCLIENT_ASSOC NOMINEE for Nominee getting Error",ec);
		    }
		    finally {
		    	if(conn!=null) {
		    		try {
		    		conn.close();
		    		}catch(Exception ec) {
		    			logger.error("error while closing the connection",ec);
		    		}
		    		
		    	}
		    	if(pstmt!=null) {
		    	    try {
		    		   pstmt.close();
			    	}catch(Exception ec) {
			    		logger.error("error while closing the connection",ec);
			    	}
		    	}
		    }
			
		}	
	
	
public void insert_PClientAssocFemaleCIInformation(String cpCliID,String isPregnentActivities) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_NG_NB_FEMALE_INFORMATION_ASSOC_CI_INSERT);
	        Integer cpCliIDInt=MethodUtil.StringToIntConverter(cpCliID);
	    	if(cpCliIDInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, cpCliIDInt);
	    	}
	    	pstmt.setString(counter++,isPregnentActivities);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO PCLIENT_ADDRESS getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

public void update_PClientAssocFemaleCIInformation(String cpCliID,String isPregnentActivities) {
	
	Connection conn=null;
    PreparedStatement pstmt=null;
	try {
		int counter=1;
    	conn= dolphinConfiguration.getDolphinConnection();
    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_NG_NB_FEMALE_INFORMATION_ASSOC_CI_UPDATE);
        pstmt.setString(counter++, isPregnentActivities);
    	Integer cpCliIDInt=MethodUtil.StringToIntConverter(cpCliID);
	    	if(cpCliIDInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, cpCliIDInt);
	    	}
	    
    	pstmt.execute();
    }catch(Exception ec) {
    	logger.error("UPDATE INTO PCLIENT_ADDRESS getting Error",ec);
    }
    finally {
    	if(conn!=null) {
    		try {
    		conn.close();
    		}catch(Exception ec) {
    			logger.error("error while closing the connection",ec);
    		}
    		
    	}
    	if(pstmt!=null) {
    	    try {
    		   pstmt.close();
	    	}catch(Exception ec) {
	    		logger.error("error while closing the connection",ec);
	    	}
    	}
    }
	
}

	public void insert_PClientAssocLifeStyleInfo(String cpCliID,String hazardeous) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NG_NB_LIFE_STYLE_INFO_INSERT);
	        pstmt.setString(counter++, hazardeous);
	    	Integer cpCliIDInt=MethodUtil.StringToIntConverter(cpCliID);
		    	if(cpCliIDInt==null) {
		    		pstmt.setNull(counter++, Types.INTEGER);
		    	}else {
		    		pstmt.setInt(counter++, cpCliIDInt);
		    	}
		    
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE INTO PCLIENT_ADDRESS getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}
	
public void update_PClientAssocLifeStyleInfo(String wiName,String hazardeous) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.CASE_PCLIENT_ASSOC_NG_NB_LIFE_STYLE_INFO_UPDATE);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	if(MethodUtil.isNull(hazardeous))
	    	{
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++,hazardeous);	
	    	}
	    	
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO PCLIENT_ADDRESS getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	
		
   ////////////////////////////////////////////////////CASE_PCLIENT_ASSOC_CI ENDS//////////////////////////////////////////////////////////

}
