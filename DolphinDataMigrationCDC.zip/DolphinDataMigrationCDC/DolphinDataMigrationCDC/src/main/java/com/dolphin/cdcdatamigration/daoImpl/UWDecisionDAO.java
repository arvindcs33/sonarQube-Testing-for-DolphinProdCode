package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class UWDecisionDAO {
private final Logger logger=LoggerFactory.getLogger(UWDecisionDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;
    
	//@Autowired
	//@Qualifier(value = "masterMap")
	//Map<String,Map<String,Map>> masterMap;
	
	public boolean getUWDecisionExistOrNot(String caseId) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_UW_DECN_SELECT);
	    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	if(caseIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,caseIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting MNYL_CASE_UW_DECN ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}


	
	public void insert_NG_NB_LIST_RIDER_DETAILS(String wiName, 
			String smokerClassRevised, String uWDecisionedDate, String toalPremium, String assessedIncome,String caseUWDecnId) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_UW_DECN_INSERT);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	       // Long uWDecisionedDateLong=MethodUtil.StringToLongConverter(uWDecisionedDate);
	        Double totalPremiumDouble=MethodUtil.StringToDoubleConverter(toalPremium,2);
	        //Integer caseUWDecnIdInt=MethodUtil.StringToIntConverterWithAddition(caseUWDecnId,DPHConstants.FIVE_CRORE);	        
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        if(MethodUtil.isNull(smokerClassRevised) || smokerClassRevised.length()>6){
	        	pstmt.setNull(counter++, Types.NULL);
	        
		    }else {
	            pstmt.setString(counter++, smokerClassRevised);
	        } 
	        
	        if(totalPremiumDouble==null) {
	        	pstmt.setNull(counter++, Types.DOUBLE);
	        }else {
	           pstmt.setDouble(counter++, totalPremiumDouble);	
	        }
	        
	        if(MethodUtil.isNull(assessedIncome)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++, assessedIncome);
	        }
	        
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO MNYL_CASE_UW_DECN getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_NG_NB_LIST_RIDER_DETAILS(String wiName, 
			String smokerClassRevised, String uWDecisionedDate, String toalPremium, String assessedIncome,String caseUWDecnId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_UW_DECN_UPDATE);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	       //Long uWDecisionedDateLong=MethodUtil.StringToLongConverter(uWDecisionedDate);
	        Double totalPremiumDouble=MethodUtil.StringToDoubleConverter(toalPremium,2);
	        Integer caseUWDecnIdInt=MethodUtil.StringToIntConverter(caseUWDecnId);
	        
	        
	        
	        if(MethodUtil.isNull(smokerClassRevised) || smokerClassRevised.length()>6) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        
		    }else {
	            pstmt.setString(counter++, smokerClassRevised);
	        } 
	        
	        if(totalPremiumDouble==null) {
	        	pstmt.setNull(counter++, Types.DOUBLE);
	        }else {
	           pstmt.setDouble(counter++, totalPremiumDouble);	
	        }
	        
	        if(MethodUtil.isNull(assessedIncome)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	            pstmt.setString(counter++, assessedIncome);
	        }
	        
	        if(wiNameInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			}else {
			      pstmt.setInt(counter++, wiNameInt);
			}
	       
	        pstmt.execute();
	   }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_LIST_RIDER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_EXT_TABLE(String wiName,String finalUWDecision,String uWDecisionedDate,String caseUWDecnId) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	Integer winameInt=MethodUtil.StringToIntConverter(wiName);
            //Integer finalUWDecision1=masterMap.get(DPHConstants.UW_DECISION).get(finalUWDecision);
	    	Long uwDecisionedDateLong=MethodUtil.StringToLongConverter(uWDecisionedDate);
	    	//Integer caseUWDecnIdInt=MethodUtil.StringToIntConverterWithAddition(caseUWDecnId, DPHConstants.FIVE_CRORE);
			conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_UW_DECN_NG_NB_EXT_TABLE_INSERT);
	    	if(winameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++, winameInt);
	    	}
	    	
	    	
	    	if(winameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, winameInt);
	    	}
	    	
	    	//if(finalUWDecision1==null) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	/*}else {
	    		pstmt.setInt(counter++, finalUWDecision1);
	    	}*/
	    	
	    	
            if(uwDecisionedDateLong==null) {
            	pstmt.setNull(counter++, Types.DATE);
            }else {
            	pstmt.setTimestamp(counter++,new Timestamp(uwDecisionedDateLong) );
            }
            if(uwDecisionedDateLong==null) {
            	pstmt.setNull(counter++, Types.DATE);
            }else {
            	pstmt.setTimestamp(counter++,new Timestamp(uwDecisionedDateLong) );
            }
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO MNYL_CASE_UW_DECN  FOR NG_NB_EXT_TABLE getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_NG_NB_EXT_TABLE(String wiName,String finalUWDecision,String uWDecisionedDate,String caseUWDecnId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
			Integer winameInt=MethodUtil.StringToIntConverter(wiName);
            //Integer finalUWDecision1=masterMap.get(DPHConstants.UW_DECISION).get(finalUWDecision);
	    	Long uwDecisionedDateLong=MethodUtil.StringToLongConverter(uWDecisionedDate);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_UW_DECN_NG_NB_EXT_TABLE_UPDATE);
	    	// if(finalUWDecision1==null) {
		    		pstmt.setNull(counter++, Types.VARCHAR);
		    /*	}else {
		    		pstmt.setInt(counter++, finalUWDecision1);
		     } */
            if(uwDecisionedDateLong==null) {
            	pstmt.setNull(counter++, Types.DATE);
            }else {
            	pstmt.setTimestamp(counter++,new Timestamp(uwDecisionedDateLong) );
            }
            
            
            if(uwDecisionedDateLong==null) {
            	pstmt.setNull(counter++, Types.DATE);
            }else {
            	pstmt.setTimestamp(counter++,new Timestamp(uwDecisionedDateLong) );
            }
           
            
            if(winameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, winameInt);
	    	}
           
	        pstmt.execute();
	   }catch(Exception ec) {
	    	logger.error("UPDATE MNYL_CASE_UW_DECN  FOR NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
}