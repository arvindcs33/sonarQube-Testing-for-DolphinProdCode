package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class AgentDAO {

	private final Logger logger = LoggerFactory.getLogger(AgentDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean getAgentExistOrNot(String strAgentCode) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_AGENT);
	    	pstmt.setString(counter, strAgentCode);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_AGENT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	public void insert_NG_NB_LIST_AGENT_DETAILS_GRID(String strAgentCd,String strAgentName,String strAgentStatus,String goCode,String afterJoiningDate,
			String reportingManagerCode,String reportingManagerName,String agentContactNumber,String agentEmail,String currentUlipStartDate,
			String currentUlipEndDate,String previousUlipStartDate,String previousUlipEndDate,String currentAmlStartDate,String currentAmlEndDate
			,String previousAmlStartDate,String previousAmlEndDate) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
			Long afterJoiningDateLong=MethodUtil.StringToLongConverter(afterJoiningDate);
			Long currentUlipStartDateLong=MethodUtil.StringToLongConverter(currentUlipStartDate);
			Long currentUlipEndDateLong=MethodUtil.StringToLongConverter(currentUlipEndDate);
			Long previousUlipStartDateLong=MethodUtil.StringToLongConverter(previousUlipStartDate);
			Long previousUlipEndDateLong=MethodUtil.StringToLongConverter(previousUlipEndDate);
			Long currentAmlStartDateLong=MethodUtil.StringToLongConverter(currentAmlStartDate);
			Long currentAmlEndDateLong=MethodUtil.StringToLongConverter(currentAmlEndDate);
			Long previousAmlStartDateLong=MethodUtil.StringToLongConverter(previousAmlStartDate);
			Long previousAmlEndDateLong=MethodUtil.StringToLongConverter(previousAmlEndDate);
			
			conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_AGENT_DETAILS_GRID);
	        if(MethodUtil.isNull(strAgentCd))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,strAgentCd);
	        }
	        
	        if(MethodUtil.isNull(strAgentName))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,strAgentName);	
	        }
	        
	        
	        pstmt.setString(counter++,"");
	        //pstmt.setNull(counter++, Types.INTEGER);	//Mangleshwar
	        if(MethodUtil.isNull(goCode))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
		    pstmt.setString(counter++,goCode);
	        }
		    if(afterJoiningDateLong==null) {
		    	pstmt.setNull(counter++,Types.DATE);
		    }else {
	            pstmt.setTimestamp(counter++,new Timestamp(afterJoiningDateLong));
		    }
		    
		    if(MethodUtil.isNull(reportingManagerCode))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,reportingManagerCode);
	        }
		    
		    if(MethodUtil.isNull(reportingManagerName))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,reportingManagerName);
	        }
		    
		    if(MethodUtil.isNull(agentContactNumber))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        
	        pstmt.setString(counter++,agentContactNumber);
	        }
		    
		    if(MethodUtil.isNull(agentEmail))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,agentEmail);
	        }
		    
	        if(currentUlipStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentUlipStartDateLong));
	        }
	        	
	        if(currentUlipEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentUlipEndDateLong));
	        }
	        
	        if(previousUlipStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousUlipStartDateLong));
	        }
	        
	        if(previousUlipEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousUlipEndDateLong));
	        }
	        
	        if(currentAmlStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentAmlStartDateLong));
	        }
	        
	        if(currentAmlEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentAmlEndDateLong));
	        }
	        
	        if(previousAmlStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousAmlStartDateLong));
	        }
	        
	        if(previousAmlEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousAmlEndDateLong));
	        }
	        
	        pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_LIST_AGENT_DETAILS_GRID(String strAgentCd,String strAgentName,String strAgentStatus,String goCode,String afterJoiningDate,
			String reportingManagerCode,String reportingManagerName,String agentContactNumber,String agentEmail,String currentUlipStartDate,
			String currentUlipEndDate,String previousUlipStartDate,String previousUlipEndDate,String currentAmlStartDate,String currentAmlEndDate
			,String previousAmlStartDate,String previousAmlEndDate) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Long afterJoiningDateLong=MethodUtil.StringToLongConverter(afterJoiningDate);
			Long currentUlipStartDateLong=MethodUtil.StringToLongConverter(currentUlipStartDate);
			Long currentUlipEndDateLong=MethodUtil.StringToLongConverter(currentUlipEndDate);
			Long previousUlipStartDateLong=MethodUtil.StringToLongConverter(previousUlipStartDate);
			Long previousUlipEndDateLong=MethodUtil.StringToLongConverter(previousUlipEndDate);
			Long currentAmlStartDateLong=MethodUtil.StringToLongConverter(currentAmlStartDate);
			Long currentAmlEndDateLong=MethodUtil.StringToLongConverter(currentAmlEndDate);
			Long previousAmlStartDateLong=MethodUtil.StringToLongConverter(previousAmlStartDate);
			Long previousAmlEndDateLong=MethodUtil.StringToLongConverter(previousAmlEndDate);
			
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_AGENT_DETAILS_GRID);
	        
	        if(MethodUtil.isNull(strAgentName))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,strAgentName);
	        }
	        
	        pstmt.setString(counter++,"");
	        //pstmt.setNull(counter++, Types.INTEGER);	
	        if(MethodUtil.isNull(goCode))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
		    pstmt.setString(counter++,goCode);
	        }
	        
		    if(afterJoiningDateLong==null) {
		    	pstmt.setNull(counter++,Types.DATE);
		    }else {
	            pstmt.setTimestamp(counter++,new Timestamp(afterJoiningDateLong));
		    }
		    
		    if(MethodUtil.isNull(reportingManagerCode))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,reportingManagerCode);
	        }
		    
		    if(MethodUtil.isNull(reportingManagerName))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,reportingManagerName);
	        }
		    
		    if(MethodUtil.isNull(agentContactNumber))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        
	        pstmt.setString(counter++,agentContactNumber);
	        }
		    
		    if(MethodUtil.isNull(agentEmail))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,agentEmail);
	        }
		    
	        if(currentUlipStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentUlipStartDateLong));
	        }
	        	
	        if(currentUlipEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentUlipEndDateLong));
	        }
	        
	        if(previousUlipStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousUlipStartDateLong));
	        }
	        
	        if(previousUlipEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousUlipEndDateLong));
	        }
	        
	        if(currentAmlStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentAmlStartDateLong));
	        }
	        
	        if(currentAmlEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(currentAmlEndDateLong));
	        }
	        
	        if(previousAmlStartDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousAmlStartDateLong));
	        }
	        
	        if(previousAmlEndDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(previousAmlEndDateLong));
	        }
	        
	        if(MethodUtil.isNull(strAgentCd))
	        {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,strAgentCd);
	        }
	        
	        pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String agentcCde,String spCrtFktNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_MA_NG_NB_AGENT_INFORMATION);
	        pstmt.setString(counter++, agentcCde);
	        if(MethodUtil.isNull(spCrtFktNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	    pstmt.setString(counter++, spCrtFktNumber);
	        }
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String agentCode,String spCrtFktNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_MA_NG_NB_AGENT_INFORMATION);
	        if(MethodUtil.isNull(spCrtFktNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	    pstmt.setString(counter++, spCrtFktNumber);
	        }
	    	pstmt.setString(counter++, agentCode);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	///////////////////////////////////////////////////////////////////CASE_AGENT_CI STARTS////////////////////////////////////////////////////////
	
	
	public boolean getAgentCIExistOrNot(String caseAgentId) {
		
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	Integer caseAgentIdInt=MethodUtil.StringToIntConverter(caseAgentId);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_AGENT_CI_SELECT);
	    	if(caseAgentIdInt==null) {
	    		pstmt.setNull(counter, Types.INTEGER);	
	    	}else {
	    	    pstmt.setInt(counter, caseAgentIdInt);
	    	}
	    	
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_AGENT_CI Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	public void insert_MNYL_CASE_AGENT_CI(String mnylAgentCd,String caseId,String mnylAgentName,String mnylCommisionShare,String caseAgentId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_AGENT_CI_INSERT);
	        Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	        Integer caseAgentIdInt=MethodUtil.StringToIntConverter(caseAgentId);
	        Integer commissionShareInt=MethodUtil.StringToIntConverter(mnylCommisionShare);
	        
	        if(caseAgentIdInt==null) {
	            pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,caseAgentIdInt);	
	        }
	        
	        if(MethodUtil.isNull(mnylAgentCd)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, mnylAgentCd);	
	        }
	        
	        if(caseIdInt==null) {
	            pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,caseIdInt);	
	        }
	        
	        if(MethodUtil.isNull(mnylAgentName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++, mnylAgentName);
	        }
	        
	        if(commissionShareInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,commissionShareInt);
	        }
	        pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("MNY_CASE_AGENT_CI  INSERT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_MNYL_CASE_AGENT_CI(String mnylAgentCd,String caseId,String mnylAgentName,String mnylCommisionShare,String caseAgentId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.MNYL_CASE_AGENT_CI_UPDATE);
	        Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	        Integer caseAgentIdInt=MethodUtil.StringToIntConverter(caseAgentId);
	        
	        Integer commissionShareInt=MethodUtil.StringToIntConverter(mnylCommisionShare);
	        if(MethodUtil.isNull(mnylAgentCd)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, mnylAgentCd);	
	        }
	        
	        if(caseIdInt==null) {
	            pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,caseIdInt);	
	        }
	        
	        if(MethodUtil.isNull(mnylAgentName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++, mnylAgentName);
	        }
	        
	        if(commissionShareInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,commissionShareInt);
	        }
	        
	        if(caseAgentIdInt==null) {
	            pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,caseAgentIdInt);	
	        }
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("MNY_CASE_AGENT_CI  UPDATE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
    ///////////////////////////////////////////////////////////////////CASE_AGENT_CI ENDS////////////////////////////////////////////////////////
}
