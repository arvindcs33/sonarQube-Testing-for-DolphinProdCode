package com.dolphin.cdcdatamigration;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.dolphin.cdcdatamigration.daoImpl.MasterDAO;
import com.dolphin.cdcdatamigration.serviceImpl.DolphinTablesTopicListener;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@SpringBootApplication
public class DolphinDataMigrationCdcApplication {

	private final Logger logger = LoggerFactory.getLogger(DolphinDataMigrationCdcApplication.class);
	
	@Autowired
	MasterDAO  masterDao;
	
	public static void main(String[] args) {
		SpringApplication.run(DolphinDataMigrationCdcApplication.class, args);
	}
	

	
	@PostConstruct
	@Bean(name="masterMap")
	public Map  masterMap() {
	    Map  mainReturnMap=new HashMap();
		/*
	    Map premPayTerm=masterDao.premPayTerm();
		mainReturnMap.put(DPHConstants.MNYL_PREM_PAY_TERM,premPayTerm);
	    
	    Map premPayTermPaymentMap=masterDao.permPayTermPayment();
		mainReturnMap.put(DPHConstants.MNYL_PREM_PAY_TERM_PAYMNT,premPayTermPaymentMap);
		
		Map baseProductsExtMap=masterDao.baseProductsExt();
		mainReturnMap.put(DPHConstants.MNYL_BASE_PRODUCTS_EXT,baseProductsExtMap);
		
		Map modeOfRenewalMap=masterDao.modeOfRenewal();
		mainReturnMap.put(DPHConstants.MNYL_MODE_OF_RENEWAL,modeOfRenewalMap);
		
		Map accTypeDetMap=masterDao.accTypeDet();
		mainReturnMap.put(DPHConstants.MNYL_CC_ACC_TYPE_DET,modeOfRenewalMap);
		*/
		
	    Map baseProdMap=masterDao.baseProd();
		mainReturnMap.put("baseProdMap",baseProdMap);
		
		Map baseProductMap=masterDao.baseProducts();
		mainReturnMap.put("baseProduct",baseProductMap);
		
		Map productSolution=masterDao.productSolution();
		mainReturnMap.put("productSolution",productSolution);
		
		Map channelcodeMap=masterDao.mnylChannelCode();
		mainReturnMap.put("channelcodeMap", channelcodeMap);
		
		
		Map objOfInsurerMap=masterDao.mnylObjOfInsurer();
		mainReturnMap.put("objOfInsurerMap", objOfInsurerMap);
		
		Map sourceOfSaleMap=masterDao.mnylSourceOfSale();
		mainReturnMap.put("sourceOfSaleMap", sourceOfSaleMap);
		
		Map mnylRuralMap=masterDao.mnylRural();
		mainReturnMap.put("mnylRuralMap", mnylRuralMap);
		
		
	
	
	   		//---------------------------Start---------------------- Arvind code date 7th OCt 2020 ---------------------------
		
		/*  
		 Map ctryDetailsMap=masterDao.ctryDetails();
		 
		mainReturnMap.put(DPHConstants.CTRY_DETAILS,ctryDetailsMap);
		*/
		Map ngNbListQcRequirementsMap=masterDao.ngNbListQcRequirements();
		mainReturnMap.put(DPHConstants.NG_NB_LIST_QC_REQUIREMENTS,ngNbListQcRequirementsMap);
		
		/*
		Map uwDecisionMap=masterDao.uwDecision();
		mainReturnMap.put(DPHConstants.UW_DECISION,uwDecisionMap);
	    */
		Map mnylFundListMap=masterDao.mnylFundList();
		mainReturnMap.put(DPHConstants.MNYL_FUND_LIST,mnylFundListMap);
	
		/*
		Map ngNbProposerDetailsMap=masterDao.ngNbProposerDetails();
		mainReturnMap.put(DPHConstants.NG_NB_PROPOSER_DETAILS,ngNbProposerDetailsMap);
		
		Map mnylKickoutMsgsMap=masterDao.mnylKickoutMsgs();
		mainReturnMap.put(DPHConstants.MNYL_KICKOUT_MSGS,mnylKickoutMsgsMap);
		*/
		
		
		
		Map caseCancelReasonsMap=masterDao.caseCancelReasons();
		mainReturnMap.put(DPHConstants.MNYL_CASE_CANCEL_REASONS,caseCancelReasonsMap);
		
		Map needListMap=masterDao.needList();
		mainReturnMap.put(DPHConstants.MNYL_NEED_LIST, needListMap);
		
		
		//---------------------------Start---------------------- Arvind code date 7th OCt 2020 ---------------------------
		
        logger.info("==================================================MAin Return Map is========================================");
		
		logger.info("Return Map is"+mainReturnMap);
		
		logger.info("==================================================MAin Return Map is========================================");
	
	
		return mainReturnMap;
	}
	
}
