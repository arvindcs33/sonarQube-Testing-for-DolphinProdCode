package com.dolphin.cdcdatamigration.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dolphin.cdcdatamigration.serviceImpl.DolphinTablesTopicListener;

public class MethodUtil {

	private static final Logger logger = LoggerFactory.getLogger(MethodUtil.class);
	
	public static String removeUnRequiredCharacterCaseId(String caseId) {
	     if(caseId==null || "".equals(caseId) || "null".equals(caseId)) {
	    	 return caseId;
	     }
		
		String tempCaseId=caseId;
		tempCaseId=tempCaseId.replaceAll("-", "");
		tempCaseId=tempCaseId.replaceAll("NB", "");
		tempCaseId=tempCaseId.replaceAll("Dolphin", "");
		return tempCaseId;
	}
	
   public static Integer StringToIntConverter(String input) {
	   Integer returnVal=null;
	   if(input==null || "".equals(input.trim()) || "null".equals(input.trim())) {
		   return null;
	   }
	   try {
		   returnVal=Integer.parseInt(input);
	   }catch(Exception ec) {
		   logger.error("Exception while converting String to Number",ec);
		   returnVal=null;
	   }
	   return returnVal;
   }
   
	public static Double StringToDoubleConverter(String input,Integer decimalValue) {
		   
		   Double returnVal=null;
		   if(input==null || "".equals(input.trim()) || "null".equals(input)) {
			   return null;
		   }
		   try 
		   {
			   if(!input.contains("==")){
			   try {
				   returnVal=Double.parseDouble(input);
				    return returnVal;
			   }catch(Exception ec) {
				   logger.info("alphaneumeric value");
			   }
			   }
			   BigDecimal decimalInput=new BigDecimal(new BigInteger(input.getBytes()),decimalValue);
			   returnVal=Double.parseDouble(decimalInput.toPlainString());
		   }catch(Exception ec) {
			   logger.error("Exception while converting String to Double",ec);
			   returnVal=null;
		   }
		   return returnVal;
	   }

   
   public static Long StringToLongConverter(String input) {
	   
	   Long returnVal=null;
	   if(input==null || "".equals(input.trim())|| "null".equals(input.trim())) {
		   return null;
	   }
	   try {
		   returnVal=Long.parseLong(input);
	   }catch(Exception ec) {
		   logger.error("Exception while converting String to Long",ec);
		   returnVal=null;
	   }
	   return returnVal;
   }
   
   public static Integer StringToIntConverterWithAddition(String input,Integer addition) {
	   
	   Integer returnVal=null;
	   if(input==null || "".equals(input.trim())|| "null".equals(input.trim())) {
		   return null;
	   }
	   try {
		   returnVal=Integer.parseInt(input)+addition;
	   }catch(Exception ec) {
		   logger.error("Exception while converting String to Long",ec);
		   returnVal=null;
	   }
	   return returnVal;
   }
   
   
   public static String insertScript(String tableName,String columns[],String values[],String existingQuery) {
	   StringBuilder query=new StringBuilder(existingQuery);
	   
		   query.append("INSERT INTO "+tableName+" (");
		   for(int i=0;i<columns.length;i++)
		   {
				if(i==(columns.length-1)) {
					query.append(columns[i]);	
				}else {
				    query.append(columns[i]+",");
				}
		   }
		   query.append(") VALUES ");   
		   query.append("(");   
	   
	   
	   
	   for(int i=0;i<values.length;i++) {
		   if(i==(values.length-1)) {
			   query.append(values[i]);
		   }else {
			   query.append(values[i]+",");
		   }
	   }
	   query.append(")");
	   return query.toString();
   }
   
   
   public static boolean isNull(String input) {
	   if(input==null || input.trim().equals("") || input.trim().equalsIgnoreCase("null"))
		   return true;
	   else
		   return false;
   }
   
   
   
   
}
