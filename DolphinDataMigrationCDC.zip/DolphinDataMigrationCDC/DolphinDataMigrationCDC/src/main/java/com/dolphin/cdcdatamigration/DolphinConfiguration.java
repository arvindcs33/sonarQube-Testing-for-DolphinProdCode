package com.dolphin.cdcdatamigration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



@Configuration
public class DolphinConfiguration {

private static final Logger LOGGER=LoggerFactory.getLogger(DolphinConfiguration.class);
	
	@Value("${com.cdc.database.host}")
	private String host;
	
	@Value("${com.cdc.database.port}")
	private String port;
	
	@Value("${com.cdc.database.username}")
	private String userName;
	
	@Value("${com.cdc.database.name}")
	private String dbname;
	
	@Value("${com.cdc.database.password}")
	private String password;
	
	@Value("${com.cdc.database.timeout}")
	private String timeout;
	
	
	
	
	
	public  Connection getDolphinConnection() {
	    Connection returnConnection=null;
		        try  {
		        	Class.forName("oracle.jdbc.driver.OracleDriver");
        	Connection connection =DriverManager.getConnection(  
        			"jdbc:oracle:thin:@"+host+":"+port+":"+dbname,userName,password);  
        	returnConnection=connection;
        }
        catch (Exception e) {
            LOGGER.error(e.getMessage(),e);
        }
        
        return returnConnection;
	}
	
	
	
}
