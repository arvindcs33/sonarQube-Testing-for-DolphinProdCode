package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class CoverageDAO {


	private final Logger logger = LoggerFactory.getLogger(CoverageDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	@Autowired
	@Qualifier(value = "masterMap")
	Map<String,Map<String,Integer>> masterMap;
	
	public boolean getCaseIdExistOrNot(String wiName) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_CASE_ID);
	    	
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter, Types.INTEGER);	
	    	}else {
	    	    pstmt.setInt(counter, wiNameInt);
	    	}
	    	
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_ID Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	
	public void insert_NG_NB_COVERAGE_DETAILS(String wiName,String premiumPayTerm,String reqModalPremium,
			String coverageTerm,String sumAssured,String atp,String totalReqPremium,String nonForfeiture,
			String bonusOption,String modeOfPay,String productName,String modalPremium,String afyp,
			String vestingAge,String effectiveDate,String deathBenefit,String gipPayoutDay,String gipPayoutMethod,
			String smokerClass,String empDiscount, String guaranteeDeathBenefit,String saveMoreTomorrow,
			String coverageString,String maturityAge, String lifeEvent,String mnylCaseMnylDetailId,String gst) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_COVERAGE_DETAILS);
	    	 Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
		       // Integer premiumPayTermInt=masterMap.get(DPHConstants.MNYL_PREM_PAY_TERM).get(premiumPayTerm);;
	    	  Integer premiumPayTermInt=MethodUtil.StringToIntConverter(premiumPayTerm);
	    	    Double sumAssuredDouble=MethodUtil.StringToDoubleConverter(sumAssured,2);
		        Double totalReqPremiumDouble=MethodUtil.StringToDoubleConverter(totalReqPremium,2);
		        Double reqModalPremiumDouble=MethodUtil.StringToDoubleConverter(reqModalPremium,2);
		        Integer modeOfPayInt=MethodUtil.StringToIntConverter(modeOfPay);
		      //  Integer productNameInt=masterMap.get(DPHConstants.MNYL_BASE_PRODUCTS_EXT).get(productName);
		          Double modalPremiumDouble=MethodUtil.StringToDoubleConverter(modalPremium,2);
		        //Integer mnylCaseMnylDetailIdInt=MethodUtil.StringToIntConverterWithAddition(mnylCaseMnylDetailId, DPHConstants.FIVE_CRORE);
		        Integer afypInt=MethodUtil.StringToIntConverter(afyp);
		        Integer vestingAgeInt=MethodUtil.StringToIntConverter(vestingAge);
		        Long effectiveDateLong=MethodUtil.StringToLongConverter(effectiveDate);
		        Double guaranteeDeathBenefitDouble=MethodUtil.StringToDoubleConverter(guaranteeDeathBenefit,2);
		        Double gstdouble=MethodUtil.StringToDoubleConverter(gst,2);
		        
		        logger.info("sumAssuredDouble ==   MNYL_SUM_ASSURED "+sumAssuredDouble);
		        logger.info("totalReqPremiumDouble ==   MNYL_TOTAL "+totalReqPremiumDouble);
		        logger.info("totalReqPremiumDouble ==  MNYL_PREMIUM_AMT "+reqModalPremiumDouble);
		        logger.info("totalReqPremiumDouble ==   GDB_AMOUNT  "+guaranteeDeathBenefitDouble);
		        logger.info("totalReqPremiumDouble ==   GST  "+gstdouble);
		        
		        if(wiNameInt==null) {
		        	pstmt.setNull(counter++,Types.INTEGER);	
		        }else {
		        	pstmt.setInt(counter++,wiNameInt);
		        }
		        
		        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
		        }else {
	        	pstmt.setInt(counter++,wiNameInt);
		        }
	        
	        
		        
		        if(premiumPayTermInt==null) {
		       
		        	pstmt.setNull(counter++,Types.INTEGER);	
		        }else {
		        	pstmt.setInt(counter++,premiumPayTermInt);
		        }
		        
		        
	        
        	if(reqModalPremiumDouble==null) {
        		pstmt.setNull(counter++,Types.DOUBLE);
        	}else {
             pstmt.setInt(counter++,reqModalPremiumDouble.intValue());
        	}
        
	        if(MethodUtil.isNull(coverageTerm))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,coverageTerm);
	        }
	        
	       // if(sumAssuredDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	       /* }else {
	        	pstmt.setDouble(counter++,sumAssuredDouble);	
	        }*/
	        
	        
	        
	       // pstmt.setString(counter++,atp);
	        
	        if(totalReqPremiumDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setInt(counter++,totalReqPremiumDouble.intValue());	
	        } 
	        
	        

       		
	        
	        if(MethodUtil.isNull(nonForfeiture))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,nonForfeiture);
	        }
	        
	        if(MethodUtil.isNull(bonusOption))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,bonusOption);
	        }
	        
	        
	        if(modeOfPayInt==null) {
	        
	        	pstmt.setNull(counter++,Types.INTEGER);
	         }else {
	        	pstmt.setInt(counter++,modeOfPayInt);	
	        }
	        
	        
	        
	        
	        //if(productNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        /*}else {
	        	pstmt.setInt(counter++,productNameInt);	
	        }*/
	        
	        
	        
	         if(modalPremiumDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setInt(counter++,modalPremiumDouble.intValue());	
	        }
	        
	        if(afypInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,afypInt);	
	        }
	        
	   		
	        
	        if(vestingAgeInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,vestingAgeInt);	
	        }
	        
	        
	        if(effectiveDateLong==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(effectiveDateLong));
	        }
	        
	        if(MethodUtil.isNull(deathBenefit)) {
	           pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	          pstmt.setString(counter++,deathBenefit);
	        }
	        if(MethodUtil.isNull(gipPayoutDay))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,gipPayoutDay);
	        }
	        
	        
	          
	        
	        if(MethodUtil.isNull(gipPayoutMethod))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,gipPayoutMethod);
	        }
	        
	        if(MethodUtil.isNull(smokerClass))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,smokerClass);
	        }
	        
	       
	        if(MethodUtil.isNull(empDiscount)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	            pstmt.setString(counter++,empDiscount);
	        }
	        
	        if(guaranteeDeathBenefitDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);	
	        }else {
	        	pstmt.setInt(counter++,guaranteeDeathBenefitDouble.intValue());
	        }
	        
	        pstmt.setNull(counter++,Types.VARCHAR);
	        //pstmt.setString(counter++,saveMoreTomorrow); //Discuss
	        
	        
	        if(MethodUtil.isNull(coverageString))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,coverageString);
	        }
	        
	        if(MethodUtil.isNull(lifeEvent))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,lifeEvent);
	        }
	        
	        pstmt.setTimestamp(counter++, new Timestamp(System.currentTimeMillis()));
	        pstmt.setString(counter++,"Y");
	        pstmt.setString(counter++,"0");
	        
	        if(gstdouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setInt(counter++, gstdouble.intValue());	
	        }
	        pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_COVERAGE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_COVERAGE_DETAILS(String wiName,String premiumPayTerm,String reqModalPremium,
			String coverageTerm,String sumAssured,String atp,String totalReqPremium,String nonForfeiture,
			String bonusOption,String modeOfPay,String productName,String modalPremium,String afyp,
			String vestingAge,String effectiveDate,String deathBenefit,String gipPayoutDay,String gipPayoutMethod,
			String smokerClass,String empDiscount, String guaranteeDeathBenefit,String saveMoreTomorrow,
			String coverageString,String maturityAge, String lifeEvent,String mnylCaseMnylDetailId,String gst) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_COVERAGE_DETAILS);
	        Integer mnylCaseMnylDetailIdInt=MethodUtil.StringToIntConverter(mnylCaseMnylDetailId);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer premiumPayTermInt=MethodUtil.StringToIntConverter(premiumPayTerm);
	        Double sumAssuredDouble=MethodUtil.StringToDoubleConverter(sumAssured,2);
	        Double totalReqPremiumDouble=MethodUtil.StringToDoubleConverter(totalReqPremium,2);
	        Double reqModalPremiumDouble=MethodUtil.StringToDoubleConverter(reqModalPremium,2);
	        Integer modeOfPayInt=MethodUtil.StringToIntConverter(modeOfPay);
           // Integer productNameInt=masterMap.get(DPHConstants.MNYL_BASE_PRODUCTS_EXT).get(productName);
	        Double modalPremiumDouble=MethodUtil.StringToDoubleConverter(modalPremium,2);
	        Integer afypInt=MethodUtil.StringToIntConverter(afyp);
	        Integer vestingAgeInt=MethodUtil.StringToIntConverter(vestingAge);
	        Long effectiveDateLong=MethodUtil.StringToLongConverter(effectiveDate);
	        Double guaranteeDeathBenefitDouble=MethodUtil.StringToDoubleConverter(guaranteeDeathBenefit,2);
	        Double gstdouble=MethodUtil.StringToDoubleConverter(gst,2);
	        
	        
	        logger.info("sumAssuredDouble =="+sumAssuredDouble);
	        logger.info("totalReqPremiumDouble =="+totalReqPremiumDouble);
	        logger.info("totalReqPremiumDouble =="+reqModalPremiumDouble);
	        logger.info("totalReqPremiumDouble =="+guaranteeDeathBenefitDouble);
	        
	        
	        if(premiumPayTermInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,premiumPayTermInt);
	        }
	        
        
        	if(reqModalPremiumDouble==null) {
        		pstmt.setNull(counter++,Types.DOUBLE);
        	}else {
             pstmt.setInt(counter++,reqModalPremiumDouble.intValue());
        	}
        
	        if(MethodUtil.isNull(coverageTerm))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,coverageTerm);
	        }
	        
	      // if(sumAssuredDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        /*}else {
	        	pstmt.setDouble(counter++,sumAssuredDouble);	
	        }*/
        
           
	        if(totalReqPremiumDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setInt(counter++,totalReqPremiumDouble.intValue());	
	        }
	        
	        if(MethodUtil.isNull(nonForfeiture))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,nonForfeiture);
	        }
	        
	        if(MethodUtil.isNull(bonusOption))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,bonusOption);
	        }
	        
	        
	        if(modeOfPayInt==null) {
	        
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,modeOfPayInt);	
	        }
	       
	        
	        //if(productNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	       /* }else {
	        	pstmt.setInt(counter++,productNameInt);	
	        }*/
	        
	        //Will Discuss with Team
	        
	        
	         if(modalPremiumDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setInt(counter++,modalPremiumDouble.intValue());	
	        }
	        
	        if(afypInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,afypInt);	
	        }
	        
	        if(vestingAgeInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,vestingAgeInt);	
	        }
	        
	        
	        if(effectiveDateLong==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(effectiveDateLong));
	        }
	        
	        if(MethodUtil.isNull(deathBenefit)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,deathBenefit);	
	        }
	        
	       
	        if(MethodUtil.isNull(gipPayoutDay))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,gipPayoutDay);
	        }
	        
	        if(MethodUtil.isNull(gipPayoutMethod))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,gipPayoutMethod);
	        }
	        
	        if(MethodUtil.isNull(smokerClass))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,smokerClass);
	        }
	        
	        if(MethodUtil.isNull(empDiscount)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,empDiscount);
	        }
	        
	        if(guaranteeDeathBenefitDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);	
	        }else {
	        	pstmt.setInt(counter++,guaranteeDeathBenefitDouble.intValue());
	        }
	        
	        pstmt.setNull(counter++,Types.VARCHAR);
	        //pstmt.setString(counter++,saveMoreTomorrow); //Discuss
	        
	        if(MethodUtil.isNull(coverageString))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,coverageString);
	        }
	        
	        if(MethodUtil.isNull(lifeEvent))	{
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,lifeEvent);
	        }
		    
	        pstmt.setTimestamp(counter++, new Timestamp(System.currentTimeMillis()));
	        
	        if(gstdouble==null) {
	            pstmt.setNull(counter++, Types.DOUBLE);	
	        }else {
	        	pstmt.setInt(counter++, gstdouble.intValue());	
	        }
	        
	       
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);
	        }   
	        
	        pstmt.execute();
	       
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_COVERAGE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	

	public void insert_NG_NB_FUND_SELECTED(String wiName,String stp,String mnylCaseMnylDetailId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			//Integer mnylCaseMnylDetailIdInt=MethodUtil.StringToIntConverterWithAddition(mnylCaseMnylDetailId,DPHConstants.FIVE_CRORE);
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_FUND_SELECTED);
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);;	
	        }
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);;	
	        }
	        
	        if(MethodUtil.isNull(stp)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,stp);
	        }
	        
	        pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_FUND_SELECTED Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_FUND_SELECTED(String stp,String wiName,String mnylCaseMnylDetailId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			Integer mnylCaseMnylDetailIdInt=MethodUtil.StringToIntConverter(mnylCaseMnylDetailId);
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_FUND_SELECTED);
	        
	        if(MethodUtil.isNull(stp)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++,stp);
	        }
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);
	        }
	        
	        
	        
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_FUND_SELECTED Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void insert_NG_NB_EXT_TABLE1(String wiName,String adjustedAfyp,String adjustedMfyp,String mnylCaseMnylDetailId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			Double adjustedAFypdouble=MethodUtil.StringToDoubleConverter(adjustedAfyp, 2);
			Double adjustedMfypdouble=MethodUtil.StringToDoubleConverter(adjustedMfyp, 2);
	    	//Integer mnylCaseMnylDetailIdInt=MethodUtil.StringToIntConverterWithAddition(mnylCaseMnylDetailId,DPHConstants.FIVE_CRORE);
			conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_TABLE1);
	        
	        if(wiNameInt==null) {
	            pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	        if(adjustedAFypdouble==null) {
	        	pstmt.setNull(counter++, Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++,adjustedAFypdouble);	
	        }
	        
	        if(adjustedMfypdouble==null) {
	        	pstmt.setNull(counter++, Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++, adjustedMfypdouble);	
	        }
	        
	        
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_EXT_TABLE1 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_EXT_TABLE1(String adjustedAfyp,String adjustedMfyp,String wiName,String mnylCaseMnylDetailId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			Double adjustedAFypdouble=MethodUtil.StringToDoubleConverter(adjustedAfyp, 2);
			Double adjustedMfypdouble=MethodUtil.StringToDoubleConverter(adjustedMfyp, 2);
			
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_TABLE1);
	        if(adjustedAFypdouble==null) {
	        	pstmt.setNull(counter++, Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++,adjustedAFypdouble);	
	        }
	        
	        if(adjustedMfypdouble==null) {
	        	pstmt.setNull(counter++, Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++, adjustedMfypdouble);	
	        }
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_EXT_TABLE1 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	
	
	public void insert_NG_NB_SUC_PARAMETERS(String fsa,String msa) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_SUC_PARAMETERS);
	        pstmt.setString(counter++, fsa);
	        pstmt.setString(counter++, msa);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_SUC_PARAMETERS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_SUC_PARAMETERS(String fsa,String msa) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_SUC_PARAMETERS);
	        pstmt.setString(counter++, fsa);
	        pstmt.setString(counter++, msa);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_SUC_PARAMETERS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	


}
