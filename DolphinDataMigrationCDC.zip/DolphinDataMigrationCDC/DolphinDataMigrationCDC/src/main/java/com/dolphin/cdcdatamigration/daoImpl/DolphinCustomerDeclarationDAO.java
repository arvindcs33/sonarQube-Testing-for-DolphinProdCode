package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class DolphinCustomerDeclarationDAO {

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	private final Logger logger = LoggerFactory.getLogger(DolphinCustomerDeclarationDAO.class);
	
	public boolean getAppCaseExistOrNot(String caseId) {
		
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_CUSTOMER_DECLARATION);
	    	if(caseIdInt==null) {
	    		pstmt.setNull(counter,Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter, caseIdInt);	
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("verify customer declaration Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		return returnOut;
	}
	
	public void insert_NG_NB_CUSTOMER_INFORMATION(String insertionOrderId,String caseId,String customerSignDate,String custId,String replacePolicySale,String custClassification) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	//Integer insertionOrderIdInt=MethodUtil.StringToIntConverterWithAddition(insertionOrderId, DPHConstants.FIVE_CRORE);
	    	Integer customerSignDateLong=MethodUtil.StringToIntConverter(customerSignDate);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_CUSTOMER_INFORMATION);
	    	
	    	if(caseIdInt==null) {
	    	pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    	pstmt.setInt(counter++, caseIdInt);
	    	}
	    	
	    	if(caseIdInt==null) {
	    	pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    	pstmt.setInt(counter++, caseIdInt);
	    	}
	    	
	    	if(customerSignDateLong==null) {
	    		pstmt.setNull(counter++,Types.DATE);	
	    	}else {
	    	    pstmt.setTimestamp(counter++, new Timestamp(customerSignDateLong));
	    	}
	    	
	    	if(MethodUtil.isNull(custId)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    	pstmt.setString(counter++, custId);
	    	}
	    	
            if(MethodUtil.isNull(replacePolicySale)) {
            	pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    	    pstmt.setString(counter++, replacePolicySale);
	    	}
            
            if(MethodUtil.isNull(custClassification)) {
            	pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    		pstmt.setString(counter++, custClassification);
	    	}
	    	
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CUSTOMER_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_CUSTOMER_INFORMATION(String customerId,String caseId,String customerSignDate,String custId,String replacePolicySale,String custClassification) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
	    	Integer cutomerIdInt=MethodUtil.StringToIntConverter(customerId);
	    	Integer customerSignDateLong=MethodUtil.StringToIntConverter(customerSignDate);
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_CUSTOMER_INFORMATION);
			
			if(customerSignDateLong==null) {
	    		pstmt.setNull(counter++,Types.DATE);	
	    	}else {
	    	    pstmt.setTimestamp(counter++, new Timestamp(customerSignDateLong));
	    	}
			
			if(MethodUtil.isNull(custId)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    	pstmt.setString(counter++, custId);
	    	}
	    	
            if(MethodUtil.isNull(replacePolicySale)) {
            	pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    	    pstmt.setString(counter++, replacePolicySale);
	    	}
            
            if(MethodUtil.isNull(custClassification)) {
            	pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    		pstmt.setString(counter++, custClassification);
	    	}
	        
            if(caseIdInt==null) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		    	pstmt.setInt(counter++, caseIdInt);
		    }
			
		    	
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CUSTOMER_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String wiName,String mnylSSNCode,String mnylApplicationID,String solId,String agentSignDate,String wmsSerialNumber,String insertionOrderId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	//Integer insertionOrderIdInt=MethodUtil.StringToIntConverterWithAddition(insertionOrderId, DPHConstants.FIVE_CRORE);
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	Long agentSignDateLong=MethodUtil.StringToLongConverter(agentSignDate);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_CD_NG_NB_AGENT_INFORMATION);
	    	if(wiNameInt==null)
	    	{
	    		pstmt.setNull(counter++,Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	    	
	    	if(wiNameInt==null) {
		    	pstmt.setNull(counter++,Types.INTEGER);	
		    }else {
		        pstmt.setInt(counter++, wiNameInt);
		    }
	    	
	    	if(MethodUtil.isNull( mnylSSNCode)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, mnylSSNCode);
	    	}
	    	
	    	if(MethodUtil.isNull( mnylApplicationID)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, mnylApplicationID);
	    	}
	    	
            if(MethodUtil.isNull( solId)) {
            	pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, solId);
	    	}
            
	    	if(agentSignDateLong==null) {
	    		pstmt.setNull(counter++,Types.DATE);
	    	}else {
	    	    pstmt.setTimestamp(counter++, new Timestamp(agentSignDateLong));
	    	}
	    	if(MethodUtil.isNull( wmsSerialNumber)) {
            	pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, wmsSerialNumber);
	    	}
	    	
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String wiName,String mnylSSNCode,String mnylApplicationID,String solId,String agentSignDate,String wmsSerialNumber,String custId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			Integer custIdInt=MethodUtil.StringToIntConverter(custId);
	    	Long agentSignDateLong=MethodUtil.StringToLongConverter(agentSignDate);
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.UPDATE_CD_NG_NB_AGENT_INFORMATION);
			
			if(MethodUtil.isNull( mnylSSNCode)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, mnylSSNCode);
	    	}
	    	
	    	if(MethodUtil.isNull( mnylApplicationID)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, mnylApplicationID);
	    	}
	    	
            if(MethodUtil.isNull( solId)) {
            	pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, solId);
	    	}
            
	    	if(agentSignDateLong==null) {
	    		pstmt.setNull(counter++,Types.DATE);
	    	}else {
	    	    pstmt.setTimestamp(counter++, new Timestamp(agentSignDateLong));
	    	}
	    	if(MethodUtil.isNull( wmsSerialNumber)) {
            	pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, wmsSerialNumber);
	    	}
	    	
	    	if(wiNameInt==null) {
		    	pstmt.setNull(counter++,Types.INTEGER);	
		    }else {
		        pstmt.setInt(counter++, wiNameInt);
		    }
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
}
