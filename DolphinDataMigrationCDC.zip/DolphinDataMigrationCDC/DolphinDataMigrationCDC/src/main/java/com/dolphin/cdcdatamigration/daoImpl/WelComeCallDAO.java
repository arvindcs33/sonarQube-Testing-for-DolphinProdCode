package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class WelComeCallDAO {

	private final Logger logger = LoggerFactory.getLogger(WelComeCallDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean ExistOrNot(String wiName) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_WELCOMECALL);
	    	
	    	if(MethodUtil.isNull(wiName)) {
	    		return false;
		    }else {
		    	pstmt.setString(counter,wiName);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("WELCOME CALL Exist or Not Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}


	public void insert_NG_NB_EXT(String seqNum,String policyNumber,String wiName) {
		
	
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_WELCOMECALL);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	       // Integer seqNumInt=MethodUtil.StringToIntConverterWithAddition(seqNum, DPHConstants.FIVE_CRORE);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	        if(MethodUtil.isNull(policyNumber)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,policyNumber);
	        }
	        
	        if(MethodUtil.isNull(wiName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,wiName);
	        }
	        
	        pstmt.execute();
		}catch(Exception ec) {
	    	logger.error("INSERTING NG_NB_EXT VALUE  IN TABLE Welcome call Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }  
	        
	}
	
	public void update_NG_NB_EXT(String policyNumber,String wiName) {
		
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_WELCOMECALL);
	        if(MethodUtil.isNull(policyNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, policyNumber);
	        }
	        
	        if(MethodUtil.isNull(wiName)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, wiName);
	        }
	        pstmt.execute();
		}catch(Exception ec) {
	    	logger.error("UPDATE NG_NB_EXT for Welcome call Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }  
	        
	}
	
	public void insert_NG_NB_WELCOME_CALL(String seqNum,String wiName,String finalPosition,String notes) {
		
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_WELCOME_CALL);
	       // Integer seqNumInt=MethodUtil.StringToIntConverterWithAddition(seqNum, DPHConstants.FIVE_CRORE);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	        
	        if(MethodUtil.isNull(wiName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,wiName);
	        }
	        
	        
	        if(MethodUtil.isNull(finalPosition)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,finalPosition);
	        }
	        
	        if(MethodUtil.isNull(notes)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,notes);
	        }
	        
	        pstmt.execute();
		}catch(Exception ec) {
	    	logger.error("INSERTING NG_NB_WELCOME_CALL  Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }  
	        
	}
	
	public void update_NG_NB_WELCOME_CALL(String wiName,String finalPosition,String notes) {
		
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_WELCOME_CALL);
	        if(MethodUtil.isNull(finalPosition)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,finalPosition);
	        }
	        
	        if(MethodUtil.isNull(notes)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,notes);
	        }
	        
	        
	        if(MethodUtil.isNull(wiName)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++,wiName);
	        }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE NG_NB_WELCOME_CALL Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }  
	        
	}
	
	
	
}
