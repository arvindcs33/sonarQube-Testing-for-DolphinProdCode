package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;

@Service
public class QuestionArreDAO {

	private final Logger logger = LoggerFactory.getLogger(QuestionArreDAO.class);
	
	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public void consume_NG_NB_MEDICAL_INFORMATION(String caseId,List<String> insertBatch) {
		Connection conn= dolphinConfiguration.getDolphinConnection();
		PreparedStatement preparestatement=null;
		Statement  stmt=null;
		try 
        {
        	 /////////////////////////////Delete Previous Record///////////////////////////////
        	 int counter=1;
        	 preparestatement=conn.prepareStatement(DPHConstants.DELETE_EXISTING_QUESTIONARRIE);
        	 preparestatement.setString(counter, caseId);
        	 preparestatement.executeUpdate();
             /////////////////////////////Delete Previous Record///////////////////////////////
		     stmt=conn.createStatement();
			 for(int i=0;i<insertBatch.size();i++) {
			  stmt.addBatch(insertBatch.get(i));
			 }
			 stmt.executeBatch();
        }catch(Exception ec) {
        	logger.error(ec.getLocalizedMessage(),ec);
        }
        finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(preparestatement!=null) {
	    	    try {
	    	    	preparestatement.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
}
