package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class CaseReqtDAO {
	
   private final Logger logger=LoggerFactory.getLogger(CaseReqtDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;
   
	@Autowired
	@Qualifier(value = "masterMap")
	Map<String,Map<String,Map>> masterMap;

	public boolean getCaseIdExistOrNot(String wiName) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_CASE_REQT);
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	if(wiNameInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,wiNameInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("Error while checking Record exist or Not CASE_REQT",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}

	public void insert_CASE_REQT(String requirementName, String wiName, String reqStatus, String orderedDate,
			String receivedDate,String caseReqId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_CASE_REQT);
	        String RequirementStr=masterMap.get("masterMap").get(DPHConstants.NG_NB_LIST_QC_REQUIREMENTS).get(requirementName)+"";
	        Integer requirementNameInt=MethodUtil.StringToIntConverter(RequirementStr);
		    Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Long orderedDateInt=MethodUtil.StringToLongConverter(orderedDate);
	        Long receivedDateInt=MethodUtil.StringToLongConverter(receivedDate);
	       // Integer caseReqIdInt=MethodUtil.StringToIntConverterWithAddition(caseReqId, DPHConstants.FIVE_CRORE);
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);	
	        }
	        
	       if(requirementNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,requirementNameInt);	
	        }
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        if(MethodUtil.isNull(reqStatus)) {
	        	pstmt.setNull(counter++, Types.VARCHAR); 	
	        }else {
	            pstmt.setString(counter++,reqStatus);
	        }
	        
	        if(orderedDateInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(orderedDateInt));
	        }
	        if(receivedDateInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(receivedDateInt));
	        }
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_CASE_REQT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	
	}

	public void update_CASE_REQT(String requirementName, String wiName, String reqStatus, String orderedDate,
			String receivedDate,String caseReqId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_CASE_REQT);
	    	String RequirementStr=masterMap.get("masterMap").get(DPHConstants.NG_NB_LIST_QC_REQUIREMENTS).get(requirementName)+"";
	        Integer requirementNameInt=MethodUtil.StringToIntConverter(RequirementStr);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Long orderedDateInt=MethodUtil.StringToLongConverter(orderedDate);
	        Long receivedDateInt=MethodUtil.StringToLongConverter(receivedDate);
	        if(requirementNameInt==null) {
	           pstmt.setNull(counter++,Types.INTEGER);
	         
	        }else {
	        	pstmt.setInt(counter++,requirementNameInt);	
	        } 
	        
	        if(MethodUtil.isNull(reqStatus)) {
	        	pstmt.setNull(counter++, Types.VARCHAR); 	
	        }else {
	            pstmt.setString(counter++,reqStatus);
	        }
	        
	        if(orderedDateInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(orderedDateInt));
	        }
	        
	        if(receivedDateInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(receivedDateInt));
	        }
	        
	        if(wiNameInt==null) {
			      pstmt.setNull(counter++, Types.INTEGER);	
			}else {
			      pstmt.setInt(counter++, wiNameInt);
			}
	        
		    pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_CASE_REQT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

}
