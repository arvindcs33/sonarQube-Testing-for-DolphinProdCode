package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class WorkBasketDAO {
private final Logger logger=LoggerFactory.getLogger(WorkBasketDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;

	public boolean getWorkBasketExistOrNot(String processInstanceId) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.WORKBASKET_SELECT);
	    	Integer processInstanceIdInt=MethodUtil.StringToIntConverter(processInstanceId);
	    	if(processInstanceIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,processInstanceIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting WORKBASKET_SELECT ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}


	
	public void insert_WORKBASKET(String processInstanceId,String userId,String actionDateTime,String workItemId,String activityId,String workBasketId) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.WORKBASKET_INSERT);
	        Integer processInstanceIdInt=MethodUtil.StringToIntConverter(processInstanceId);
	    	Integer userIdInt=MethodUtil.StringToIntConverter(userId);
	        Long actionDatetimeLong=MethodUtil.StringToLongConverter(actionDateTime);
	        Integer workIndInt=MethodUtil.StringToIntConverter(workItemId);
	        Integer workBasketIdInt=MethodUtil.StringToIntConverter(workBasketId);
	        
	        if(workBasketIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, workBasketIdInt);
	        }
	        
	        if(processInstanceId==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, processInstanceIdInt);
	        }
	        
	        if(userIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, userIdInt);
	        }
	        
	        if(actionDatetimeLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(actionDatetimeLong));
	        }
	        
	        if(actionDatetimeLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(actionDatetimeLong));
	        }
	        
	        if(workIndInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, workIndInt);
	        }
	    	
	       // if(MethodUtil.isNull(activityId)) { DISCUSS WITH MANGALESHWAR
	        	pstmt.setNull(counter++, Types.VARCHAR);
	       /* }else {
	        	pstmt.setString(counter++, activityId);	
	        }*/
	        
	        
	        
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERTING INTO WORKBASKET getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_WORKBASKET(String processInstanceId,String userId,String actionDateTime,String workItemId,String activityId,String workBasketId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.WORKBASKET_INSERT);
	        Integer processInstanceIdInt=MethodUtil.StringToIntConverter(processInstanceId);
	    	Integer userIdInt=MethodUtil.StringToIntConverter(userId);
	        Long actionDatetimeLong=MethodUtil.StringToLongConverter(actionDateTime);
	        Integer workIndInt=MethodUtil.StringToIntConverter(workItemId);
	        Integer workBasketIdInt=MethodUtil.StringToIntConverter(workBasketId);
	        
	        if(processInstanceIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, processInstanceIdInt);
	        }
	        
	        if(userIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, userIdInt);
	        }
	        
	        if(actionDatetimeLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(actionDatetimeLong));
	        }
	        
	        if(actionDatetimeLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(actionDatetimeLong));
	        }
	        
	        if(workIndInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, workIndInt);
	        }
	        
	        //if(MethodUtil.isNull(activityId)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        /*
	        }else {
	           pstmt.setString(counter++, activityId);
	        } 
	        */
	        
	       if(workBasketIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	       
		    }else {
	        	pstmt.setInt(counter++, workBasketIdInt);
	        }
	        
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("update  WORKBASKET getting Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
}
