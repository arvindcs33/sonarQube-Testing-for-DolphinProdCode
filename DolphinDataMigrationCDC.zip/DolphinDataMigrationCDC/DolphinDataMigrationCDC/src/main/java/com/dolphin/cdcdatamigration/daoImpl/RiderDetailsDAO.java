package com.dolphin.cdcdatamigration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class RiderDetailsDAO {
	
	private final Logger logger=LoggerFactory.getLogger(RiderDetailsDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;
	
	
	public Integer coverageDetailsPrimaryKey(String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
	    Integer prKey=null;
	    ResultSet  rset=null;
	    try 
		{
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_COVERAGE_DETAIL_PRIMARY_KEY);
	    	if(wiNameInt==null) {
	    		return null;
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	    	rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		prKey=rset.getInt("MNYL_CASE_MNYL_DETAIL_ID");
	    	}
	    	return prKey;
		}catch(Exception ec) {
			logger.error("Exception while getting Primay key from Coverage Detail",ec);
		}finally {
			try {
				if(rset!=null) {
				   rset.close();
				}
				
				if(pstmt!=null) {
					pstmt.close();
				}
				
				if(conn!=null) {
					conn.close();
				}
			}
			catch(Exception ec) {
				logger.error("Error while closing the connection",ec);
			}
		}
		return prKey;
	}

	public boolean getRiderDetailIdExistOrNot(String riderDetailsRiderId) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_RIDER_DETAILS);
	    	Integer riderDetailsRiderIdInt=MethodUtil.StringToIntConverterWithAddition(riderDetailsRiderId,DPHConstants.FIVE_CRORE);
	    	if(riderDetailsRiderIdInt==null) {
	    		return false;
		    }else {
		    	pstmt.setInt(counter,riderDetailsRiderIdInt);
	    	}
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error(" Error while getting MNYL_RIDER_DETAILS ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}

	public void insert_NG_NB_LIST_RIDER_DETAILS(String wiName, String coverageTerm,
			String sumAssured, String modalPremium, String insuredDetails, String riderType, String gst,String riderDetailsRiderId,Integer CoveragedetailsPK) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_RIDER_DETAILS);
	        //Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Double sumAssuredDouble=MethodUtil.StringToDoubleConverter(sumAssured,2);
	        Double modalPremiumDouble=MethodUtil.StringToDoubleConverter(modalPremium,2);
	        Double gstDouble=MethodUtil.StringToDoubleConverter(gst,2);
	        Integer riderDetailsRiderIdInt=MethodUtil.StringToIntConverterWithAddition(riderDetailsRiderId,DPHConstants.FIVE_CRORE);
	        
	        if(riderDetailsRiderIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, riderDetailsRiderIdInt);
	        }
	        
	        if(CoveragedetailsPK==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, CoveragedetailsPK);
		    }
	        
	        if(MethodUtil.isNull(coverageTerm)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++,coverageTerm);
	        }
	        
	        if(sumAssuredDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++,sumAssuredDouble);	
	        }
	        
	        if(modalPremiumDouble==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setDouble(counter++,modalPremiumDouble);	
	        }
	        
	        if(MethodUtil.isNull(insuredDetails)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++,insuredDetails);
	        }
	        
	        if(MethodUtil.isNull(riderType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++,riderType);
	        }
	        
	        if(gstDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++,gstDouble);	
	        }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_LIST_RIDER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_NG_NB_LIST_RIDER_DETAILS(String wiName, String coverageTerm,
			String sumAssured, String modalPremium, String insuredDetails, String riderType, String gst,String riderDetailsRiderId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_RIDER_DETAILS);
	        //Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Double sumAssuredDouble=MethodUtil.StringToDoubleConverter(sumAssured,2);
	        Double modalPremiumDouble=MethodUtil.StringToDoubleConverter(modalPremium,2);
	        Double gstDouble=MethodUtil.StringToDoubleConverter(gst,2);
	        Integer riderDetailsRiderIdInt=MethodUtil.StringToIntConverterWithAddition(riderDetailsRiderId,DPHConstants.FIVE_CRORE);
	        
	          
	       if(MethodUtil.isNull(coverageTerm)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++,coverageTerm);
	        }
	        
	        if(sumAssuredDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++,sumAssuredDouble);	
	        }
	        
	        if(modalPremiumDouble==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setDouble(counter++,modalPremiumDouble);	
	        }
	        
	        if(MethodUtil.isNull(insuredDetails)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++,insuredDetails);
	        }
	        
	        if(MethodUtil.isNull(riderType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++,riderType);
	        }
	        
	        if(gstDouble==null) {
	        	pstmt.setNull(counter++,Types.DOUBLE);
	        }else {
	        	pstmt.setDouble(counter++,gstDouble);	
	        }
	        
	        if(riderDetailsRiderIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, riderDetailsRiderIdInt);
	        }
	        pstmt.execute();
	   }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_LIST_RIDER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
}
