package com.dolphin.cdcdatamigration.daoImpl;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;

@Service
public class DolphinAppCaseDAO {

	private final Logger logger = LoggerFactory.getLogger(DolphinAppCaseDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	@Autowired
	@Qualifier(value = "masterMap")
	Map<String,Map<String,Map>> masterMap;
	
	public boolean getAppCaseExistOrNot(String wiName) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_APP_CASE);
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter, wiNameInt);	
	    	}
	    	
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("Error while verifying Entry Exist in APP Case or Not",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	public void insert_NG_NB_CEIP_DETAILS(String bdmID,String enrollerID,String finderID,String businessType,String companyName,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	Long bdmIdLong=MethodUtil.StringToLongConverter(bdmID);
	    	Long enrollerIdLong=MethodUtil.StringToLongConverter(enrollerID);
	    	Long finderIdLong=MethodUtil.StringToLongConverter(finderID);
	    	Integer companyId=MethodUtil.StringToIntConverter(companyName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_CEIP_DETAILS);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	    	
	        if(bdmIdLong==null) {
	        	pstmt.setNull(counter++, Types.BIGINT);
	        }else {
	        	pstmt.setLong(counter++, bdmIdLong);
	        }
	        
	        if(enrollerIdLong==null) {
	        	pstmt.setNull(counter++, Types.BIGINT);	
	        }else {
	        	pstmt.setLong(counter++, enrollerIdLong);
	        }
	    	
	        if(finderIdLong==null) {
	        	pstmt.setNull(counter++, Types.BIGINT);	
	        }else {
	        	pstmt.setLong(counter++, finderIdLong);
	        }
	        
	    	if(MethodUtil.isNull(businessType)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}
	    	else {	
	    		pstmt.setString(counter++, businessType);
	    	}
	    	
	    	if(companyId==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    	    pstmt.setInt(counter++, companyId);
	    	}
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_CEIP_DETAILS(String bdmID,String enrollerID,String finderID,String businessType,String companyName,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	Long bdmIdLong=MethodUtil.StringToLongConverter(bdmID);
	    	Long enrollerIdLong=MethodUtil.StringToLongConverter(enrollerID);
	    	Long finderIdLong=MethodUtil.StringToLongConverter(finderID);
	    	Integer companyId=MethodUtil.StringToIntConverter(companyName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_CEIP_DETAILS);
	        if(bdmIdLong==null) {
	        	pstmt.setNull(counter++, Types.BIGINT);
	        }else {
	        	pstmt.setLong(counter++, bdmIdLong);
	        }
	        
	        if(enrollerIdLong==null) {
	        	pstmt.setNull(counter++, Types.BIGINT);	
	        }else {
	        	pstmt.setLong(counter++, enrollerIdLong);
	        }
	    	
	        if(finderIdLong==null) {
	        	pstmt.setNull(counter++, Types.BIGINT);	
	        }else {
	        	pstmt.setLong(counter++, finderIdLong);
	        }
	        
	    	
	        if(MethodUtil.isNull(businessType)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}
	    	else {	
	    		pstmt.setString(counter++, businessType);
	    	}
	    	
	        if(companyId==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    	    pstmt.setInt(counter++, companyId);
	    	}
	    	
	    	if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void insert_NG_NB_EXT_TABLE(String wiName,String planName,String channel,String workStatus,String l2BiName,String priorityType,String medNonMed) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	logger.info("MASTER MAP IS=="+masterMap);
	    	String channelStr=masterMap.get("masterMap").get("channelcodeMap").get(channel)+"";
	    	
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_TABLE);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Map baseProdMap=masterMap.get("masterMap").get("baseProdMap");
	        //Map baseProductMap=masterMap.get("masterMap").get("baseProduct");
	        String plandId=  baseProdMap.get(planName)+"";
	        //String  plandId=baseProdMap.get(productCode)+"";
	        Integer planIdInt=MethodUtil.StringToIntConverter(plandId);
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);	
	        }
	    	
	        if(planIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, planIdInt);	
	        }
	    	
	    	if(MethodUtil.isNull(channelStr)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);	
	        }else {
	           pstmt.setString(counter++, channelStr);
	        }
	        
	        /*
	    	pstmt.setString(counter++, workStatus);
	    	*/
	        
	        pstmt.setNull(counter++,Types.VARCHAR);
	        /*
	        Ends
	        */
	        //if(MethodUtil.isNull(l2BiName)) {
	        pstmt.setNull(counter++, Types.VARCHAR);	
	        /*}else {
	    	pstmt.setString(counter++, l2BiName);
	        }*/
	        
	        if(MethodUtil.isNull(priorityType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	pstmt.setString(counter++, priorityType);
	        }
	        
	        if(MethodUtil.isNull(medNonMed)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	pstmt.setString(counter++, medNonMed);
	        }
	        
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERTION NG_NB_EXT_TABLE For AppCase ",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_EXT_TABLE(String wiName, String planName, String channel, String workStatus,String l2BiName,String  priorityType,String medNonMed) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			logger.info("MASTER MAP IS=="+masterMap);
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	Map baseProdMap=masterMap.get("masterMap").get("baseProdMap");
		    Map baseProductMap=masterMap.get("masterMap").get("baseProduct");
		    logger.info(baseProductMap+"");
		   // String productCode=  baseProductMap.get(planName)+"";
		    String  plandId=baseProdMap.get(planName)+"";
		    String channelStr=masterMap.get("masterMap").get("channelcodeMap").get(channel)+"";
		    Integer planIdInt=MethodUtil.StringToIntConverter(plandId);
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_TABLE);
	        
	        if(planIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, planIdInt);	
	        }
	        
	        if(MethodUtil.isNull(channelStr)) {
	        	pstmt.setNull(counter++,Types.VARCHAR);	
	        }else {
	           pstmt.setString(counter++, channelStr);
	        }
	        /*
	    	pstmt.setString(counter++, workStatus);
	    	*/
	        
	        pstmt.setNull(counter++,Types.VARCHAR);
	        /*
	        Ends
	        */
	       // if(MethodUtil.isNull(l2BiName)) {
	        pstmt.setNull(counter++, Types.VARCHAR);	
	       /* }else {
	    	pstmt.setString(counter++, l2BiName);
	        } */
	        
	        if(MethodUtil.isNull(priorityType)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	pstmt.setString(counter++, priorityType);
	        }
	        
	        if(MethodUtil.isNull(medNonMed)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	    	pstmt.setString(counter++, medNonMed);
	        }
		        
	    	if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);	
	        }
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_POLICY_DETAILS(String wiName, String appRecieveDate,String proposalNumber, String objOfInsurance,String ruralurbanSocialStr,String srcOfSale,String prevProposalNumber,String crmLeadid,String productSolution,String comboProposalNumber,String lifeStage,String qRops,String sparcLeadSrc) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			logger.info("MASTER MAP IS=="+masterMap);
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Long appRecieveDateLong=MethodUtil.StringToLongConverter(appRecieveDate);
	    	Integer crmLeadIdInt=MethodUtil.StringToIntConverter(crmLeadid);
	       // Integer lifeStageInt=MethodUtil.StringToIntConverter(lifeStage);
	    	String objOfInsuranceStr=masterMap.get("masterMap").get("objOfInsurerMap").get(objOfInsurance)+"";
	    	Integer objOfInsuranceInt=MethodUtil.StringToIntConverter(objOfInsuranceStr);
	    	String productSolutionStr=masterMap.get("masterMap").get("productSolution").get(productSolution)+"";
	    	Integer productSolutionIdInt=MethodUtil.StringToIntConverter(productSolutionStr);
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_POLICY_DETAILS);
	    	String srcOfSalestr=masterMap.get("masterMap").get("sourceOfSaleMap").get(srcOfSale)+"";
	    	String ruralUrbanSocial=masterMap.get("masterMap").get("mnylRuralMap").get(ruralurbanSocialStr)+"";
	    	Integer ruralUrbanInteger=MethodUtil.StringToIntConverter(ruralUrbanSocial);
	    	Integer srcOfSaleInt=MethodUtil.StringToIntConverter(srcOfSalestr);
	    	
	    	
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	    	if(appRecieveDateLong==null) {
	    		pstmt.setNull(counter++, Types.DATE);	
	    	}else {
	    		pstmt.setTimestamp(counter++, new Timestamp(appRecieveDateLong));
	    	}
	    	
	    	if(MethodUtil.isNull(proposalNumber)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    	    pstmt.setString(counter++, proposalNumber);
	    	}
	    	
	    	
	    	if(productSolutionIdInt==null) {
	    		pstmt.setNull(counter++,Types.INTEGER);
	    	}else {
	    	   pstmt.setInt(counter++, objOfInsuranceInt);
	    	}
	    	
	    	if(ruralUrbanInteger==null)
	    	{
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    	    pstmt.setInt(counter++, ruralUrbanInteger);
	    	}
	    	
	    	
	    	
	    	
	    	if(srcOfSaleInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, srcOfSaleInt);
	    	}
	    	
	    	
	    	
	    	if(appRecieveDateLong==null) {
	    		pstmt.setNull(counter++, Types.DATE);	
	    	}else {
	    		pstmt.setTimestamp(counter++, new Timestamp(appRecieveDateLong));
	    	}
	    	
	    	if(MethodUtil.isNull(prevProposalNumber)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);	
	    	}else {
	    	    pstmt.setString(counter++, prevProposalNumber);
	    	}
	    	
	    	if(MethodUtil.isNull(ruralUrbanSocial))
	    	{	
	    	pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    		if(ruralUrbanInteger==1 || ruralUrbanInteger==4)
	    		{
	    			pstmt.setString(counter++, "Y");
	    		}
	    		else {
	    			pstmt.setString(counter++, "N");
	    		}
	    	}
	    	
	    	if(MethodUtil.isNull(ruralUrbanSocial))
	    	{	
	    	   pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    		if(ruralUrbanInteger==1 || ruralUrbanInteger==4)
	    		{
	    			pstmt.setString(counter++, "Y");
	    		}
	    		else {
	    			pstmt.setString(counter++, "N");
	    		}
	    	}
	    	
	    	
	    	if(crmLeadIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++, crmLeadIdInt);	
	    	}
	    	
	    	if(productSolutionIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}
	    	else {
	    	    pstmt.setInt(counter++, productSolutionIdInt);
	    	}
	    	
	    	if(MethodUtil.isNull(comboProposalNumber)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, comboProposalNumber);	
	    	}
	    	
	    	
	    	//if(lifeStageInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	/*}else {
	    		pstmt.setInt(counter++, lifeStageInt);
	    	}*/
	    	if(MethodUtil.isNull(qRops)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, qRops);
	    	}
	    	
	    	if(MethodUtil.isNull(sparcLeadSrc)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, sparcLeadSrc);
	    	}
	    	
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_POLICY_DETAILS(String wiName, String appRecieveDate,String proposalNumber, String objOfInsurance,String ruralurbanSocialStr,String srcOfSale,String prevProposalNumber,String crmLeadid,String productSolution,String comboProposalNumber,String lifeStage,String qRops,String sparcLeadSrc) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			logger.info("MASTER MAP IS=="+masterMap);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Long appRecieveDateLong=MethodUtil.StringToLongConverter(appRecieveDate);
	    	Integer crmLeadIdInt=MethodUtil.StringToIntConverter(crmLeadid);
	    	String productSolutionStr=masterMap.get("masterMap").get("productSolution").get(productSolution)+"";
	    	String objOfInsuranceStr=masterMap.get("masterMap").get("objOfInsurerMap").get(objOfInsurance)+"";
	    	Integer objOfInsuranceInt=MethodUtil.StringToIntConverter(objOfInsuranceStr);
	    	Integer productSolutionIdInt=MethodUtil.StringToIntConverter(productSolutionStr);
	    	String srcOfSalestr=masterMap.get("masterMap").get("sourceOfSaleMap").get(srcOfSale)+"";
	    	Integer srcOfSaleInt=MethodUtil.StringToIntConverter(srcOfSalestr);
	       // Integer lifeStageInt=MethodUtil.StringToIntConverter(lifeStage);
	    	String ruralUrbanSocial=masterMap.get("masterMap").get("mnylRuralMap").get(ruralurbanSocialStr)+"";
	    	Integer ruralUrbanInteger=MethodUtil.StringToIntConverter(ruralUrbanSocial);
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_POLICY_DETAILS);
	    	
	    	if(appRecieveDateLong==null) {
	    		pstmt.setNull(counter++, Types.DATE);	
	    	}else {
	    		pstmt.setTimestamp(counter++, new Timestamp(appRecieveDateLong));
	    	}
	    	
	    	if(MethodUtil.isNull(proposalNumber)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
		    	pstmt.setString(counter++, proposalNumber);
		    	
	    	}
	    	

	    	if(objOfInsuranceInt==null) {
	    		pstmt.setNull(counter++,Types.INTEGER);
	    	}else {
	    	   pstmt.setInt(counter++, objOfInsuranceInt);
	    	}
	    	
	    	if(ruralUrbanInteger==null)
	    	{
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    	  pstmt.setInt(counter++, ruralUrbanInteger);
	    	}
	    	
	    	
	    	
	    	if(srcOfSaleInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, srcOfSaleInt);
	    	}
	    	
	    	
	    	
	    	if(appRecieveDateLong==null) {
	    		pstmt.setNull(counter++, Types.DATE);	
	    	}else {
	    		pstmt.setTimestamp(counter++, new Timestamp(appRecieveDateLong));
	    	}
	    	
	    	if(MethodUtil.isNull(prevProposalNumber)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, prevProposalNumber);
		    	
	    	}
	    	
	    	if(MethodUtil.isNull(ruralUrbanSocial)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		if(ruralUrbanInteger==1 || ruralUrbanInteger==4)
	    		{
	    			pstmt.setString(counter++, "Y");
	    		}
	    		else {
	    			pstmt.setString(counter++, "N");
	    		}
	    	}
	    	
            if(MethodUtil.isNull(ruralUrbanSocial)) {
            	pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		if(ruralUrbanInteger==1 || ruralUrbanInteger==4)
	    		{
	    			pstmt.setString(counter++, "Y");
	    		}
	    		else {
	    			pstmt.setString(counter++, "N");
	    		}
	    	}
	    	
	    	if(crmLeadIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++, crmLeadIdInt);	
	    	}
	    	
	    	if(productSolutionIdInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}
	    	else {
	    	    pstmt.setInt(counter++, productSolutionIdInt);
	    	}
	    		
	    	
	    	if(MethodUtil.isNull(comboProposalNumber)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, comboProposalNumber);
		    }
	    	
	    	
	    	//if(lifeStageInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	/*}else {
	    		pstmt.setInt(counter++, lifeStageInt);
	    	}*/
	    	
	    	if(MethodUtil.isNull(qRops)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, qRops);
		    }
	    	
	    	if(MethodUtil.isNull(sparcLeadSrc)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, sparcLeadSrc);
		    }
	    	
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_EXT_TABLE Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_PROPOSER_DETAILS(String wiName,String eiaNoAvailable) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_PROPOSER_DETAILS);
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++,wiNameInt);
	    	}
	    	
	    	if(MethodUtil.isNull(eiaNoAvailable)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, eiaNoAvailable);
	    	}
	    	
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_PROPOSER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_PROPOSER_DETAILS(String wiName,String eiaNoAvailable) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_PROPOSER_DETAILS);
	    	if(MethodUtil.isNull(eiaNoAvailable)) {
	    		pstmt.setNull(counter++,Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, eiaNoAvailable);
	    	}
	        if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++,wiNameInt);
	    	}
	        
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_PROPOSER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void insert_NG_NB_LIST_AGENT_DETAILS(String wiName,String goCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_AGENT_DETAILS);
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	   	    //pstmt.setString(counter++, goCode);   commented as Mangaleshwar
	    	pstmt.setNull(counter++, Types.VARCHAR); 
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_LIST_AGENT_DETAILS(String wiName,String goCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_AGENT_DETAILS);
	        //pstmt.setString(counter++, goCode);   commented as Mangaleshwar
	    	pstmt.setNull(counter++, Types.VARCHAR); 
    	    if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);
	    	}
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void insert_NG_NB_POLICY_VALIDATION_DETAILS(String wiName,String satrightPassCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_POLICY_VALIDATION_DETAILS);
	    	if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);	
	    	}
	        
	    	if(MethodUtil.isNull(satrightPassCode)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	        pstmt.setString(counter++, satrightPassCode);
	    	}
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_VALIDATION_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_POLICY_VALIDATION_DETAILS(String wiName,String satrightPassCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_POLICY_VALIDATION_DETAILS);
	    	if(MethodUtil.isNull(satrightPassCode)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	        pstmt.setString(counter++, satrightPassCode);
	    	}
	    	
	        if(wiNameInt==null) {
	    		pstmt.setNull(counter++, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter++, wiNameInt);	
	    	}
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String wiName,String sp_cert_no) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_AGENT_INFORMATION);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
		    }else {
		    	pstmt.setInt(counter++, wiNameInt);
	        }
	    	if(MethodUtil.isNull(sp_cert_no)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, sp_cert_no);
	    	}
	    	
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_VALIDATION_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String wiName,String sp_cert_no) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_AGENT_INFORMATION);
	    	if(MethodUtil.isNull(sp_cert_no)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, sp_cert_no);
	    	}
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);
	        }
	        
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void insert_NG_NB_DEFENCE_DETAILS(String wiName,String defenceChannelCase,String armyNumber,String unitName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try
		{
	    	int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_DEFENCE_DETAILS);
	    	if(wiNameInt==null)
	    	{
	    		pstmt.setNull(counter++,Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++,wiNameInt);
	    	}
	    	if(MethodUtil.isNull(defenceChannelCase)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, defenceChannelCase);	
	    	}
	        
	    	if(MethodUtil.isNull(armyNumber)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, armyNumber);
	    	}
	    	
	    	if(MethodUtil.isNull(unitName)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, unitName);
	    	}
	    	
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_VALIDATION_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_DEFENCE_DETAILS(String wiName,String defenceChannelCase,String armyNumber,String unitName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_DEFENCE_DETAILS);
			
			if(MethodUtil.isNull(defenceChannelCase)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    		pstmt.setString(counter++, defenceChannelCase);	
	    	}
	        
	    	if(MethodUtil.isNull(armyNumber)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, armyNumber);
	    	}
	    	
	    	if(MethodUtil.isNull(unitName)) {
	    		pstmt.setNull(counter++, Types.VARCHAR);
	    	}else {
	    	pstmt.setString(counter++, unitName);
	    	}
	    	
	        if(wiNameInt==null)
	    	{
	    		pstmt.setNull(counter++,Types.INTEGER);	
	    	}else {
	    		pstmt.setInt(counter++,wiNameInt);
	    	}
	        
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_LIST_AGENT_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	
	///////////////////////////////////////////////////////////APP_CASE_CI STARTS////////////////////////////////////////////////////////////                  
	public boolean getAppCaseCIExistOrNot(String caseCIId) {
		
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	Integer caseCIIdInt=MethodUtil.StringToIntConverter(caseCIId);
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_SELECT);
	    	if(caseCIIdInt==null) {
	    		pstmt.setNull(counter, Types.INTEGER);
	    	}else {
	    		pstmt.setInt(counter, caseCIIdInt);	
	    	}
	    	
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("Error while verifying Entry Exist in APP_CASE_CI or Not",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	
	public void INSERT_NG_NB_EXT_CI(String caseCIId,String caseId,String nbProdId,String proposalNumber,String priorityCd) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_EXT_TABLE_INSERT);
	        Integer caseCIIdInt=MethodUtil.StringToIntConverter(caseCIId);
			Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
			Integer nbProdIdInt=MethodUtil.StringToIntConverter(nbProdId);
	        if(caseCIIdInt==null) {
	          pstmt.setNull(counter++, Types.NULL);	
	        }else {
	        	pstmt.setInt(counter++, caseCIIdInt);
	        }
	        if(caseIdInt==null) {
	        	pstmt.setNull(counter++, Types.NULL);
	        }else {
	        	pstmt.setInt(counter++, caseIdInt);
	        }
	        if(nbProdIdInt==null) {
	        	pstmt.setNull(counter++, Types.NULL);
	        }else {
	        	pstmt.setInt(counter++,nbProdIdInt);
	        }
	        
	        if(MethodUtil.isNull(proposalNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, proposalNumber);
	        }
	        
            if(MethodUtil.isNull(priorityCd)) {
            	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	 pstmt.setString(counter++, priorityCd);
	        }
	        
	        
	        
	        
	       
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_EXT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	public void UPDATE_NG_NB_EXT_CI(String caseCIId,String caseId,String nbProdId,String proposalNumber,String priorityCd) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_EXT_TABLE_UPDATE);
			Integer caseCIIdInt=MethodUtil.StringToIntConverter(caseCIId);
			Integer caseIdInt=MethodUtil.StringToIntConverter(caseId);
			Integer nbProdIdInt=MethodUtil.StringToIntConverter(nbProdId);
	        if(caseIdInt==null) {
	        	pstmt.setNull(counter++, Types.NULL);
	        }else {
	        	pstmt.setInt(counter++, caseIdInt);
	        }
	        if(nbProdIdInt==null) {
	        	pstmt.setNull(counter++, Types.NULL);
	        }else {
	        	pstmt.setInt(counter++,nbProdIdInt);
	        }
	        if(MethodUtil.isNull(proposalNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, proposalNumber);
	        }
	        
            if(MethodUtil.isNull(priorityCd)) {
            	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	 pstmt.setString(counter++, priorityCd);
	        }
	        if(caseCIIdInt==null) {
	          pstmt.setNull(counter++, Types.NULL);	
	        }else {
	        	pstmt.setInt(counter++, caseCIIdInt);
	        }
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_EXT Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void INSERT_NG_NB_POLICY_DETAILS_EXT_CI(String caseCIId,String proposalNumber,String caseAppRecievedDate,
			String objectiveOfInsurance,String caseBussinessArea
			,String prevPolicyNumber,String sourceOfSale,String leadId,String productSolutionId
			,String comboProposalNumber,String lifeStgId,String qurops,
			String sparcsourceCode
			) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			logger.info("MASTER MAP IS=="+masterMap);
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_POLICY_DETAILS_INSERT);
			Integer caseCIIdInt=MethodUtil.StringToIntConverter(caseCIId);
			Long caseAppRecievedDateLong=MethodUtil.StringToLongConverter(caseAppRecievedDate);
	        Integer objectiveOfInsuranceInt=MethodUtil.StringToIntConverter(objectiveOfInsurance);
	        Integer mnylLeadInt=MethodUtil.StringToIntConverter(leadId);
	        String productSolutionStr=masterMap.get("masterMap").get("productSolution").get(productSolutionId)+"";
	    	Integer productSolutionIdInt=MethodUtil.StringToIntConverter(productSolutionStr);
	       // Integer lifeStagIdInt=MethodUtil.StringToIntConverter(lifeStgId);
	    	String srcOfSalestr=masterMap.get("masterMap").get("sourceOfSaleMap").get(sourceOfSale)+"";
	    	Integer srcOfSaleInt=MethodUtil.StringToIntConverter(srcOfSalestr);
	    	
	        if(caseCIIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,caseCIIdInt);
	        }
	        
	        if(MethodUtil.isNull(proposalNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++, proposalNumber);
	        }
	        
	        if(caseAppRecievedDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(caseAppRecievedDateLong));
	        }
	        
	        if(objectiveOfInsuranceInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,objectiveOfInsuranceInt);
	        }
	        
	        if(MethodUtil.isNull(caseBussinessArea)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,caseBussinessArea );
	        }
	        
	        if(MethodUtil.isNull(prevPolicyNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,prevPolicyNumber );
	        }
	        
	        if(srcOfSaleInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, srcOfSaleInt);
	        }
	        
	        if(mnylLeadInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,mnylLeadInt);
	        }
	        
	        pstmt.setNull(counter++, Types.INTEGER);//Discussion requires with Mangaleshwar
	       
	        if(productSolutionIdInt==null) {
	          	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,productSolutionIdInt);
	        }
	       
	        if(MethodUtil.isNull(comboProposalNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++, comboProposalNumber);
	        }
	        pstmt.setNull(counter++, Types.INTEGER);//DISCUSS WITH MANGALESHWAR
	        /*
	        if(lifeStagIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,lifeStagIdInt);
	        }
	        */
	        if(MethodUtil.isNull(qurops)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, qurops);	
	        }
	        
	        if(MethodUtil.isNull(sparcsourceCode)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, sparcsourceCode);	
	        }
	        
	        
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	public void UPDATE_NG_NB_POLICY_DETAILS_CI(String caseCIId,String proposalNumber,String caseAppRecievedDate,
			String objectiveOfInsurance,String caseBussinessArea
			,String prevPolicyNumber,String sourceOfSale,String leadId,String productSolutionId
			,String comboProposalNumber,String lifeStgId,String qurops,
			String sparcsourceCode) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			logger.info("MASTER MAP IS=="+masterMap);
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_POLICY_DETAILS_UPDATE);
			Integer caseCIIdInt=MethodUtil.StringToIntConverter(caseCIId);
			Long caseAppRecievedDateLong=MethodUtil.StringToLongConverter(caseAppRecievedDate);
	        Integer objectiveOfInsuranceInt=MethodUtil.StringToIntConverter(objectiveOfInsurance);
	        //Integer sourceOSaleInt=MethodUtil.StringToIntConverter(sourceOfSale);
	        Integer mnylLeadInt=MethodUtil.StringToIntConverter(leadId);
	        String productSolutionStr=masterMap.get("masterMap").get("productSolution").get(productSolutionId)+"";
	    	Integer productSolutionIdInt=MethodUtil.StringToIntConverter(productSolutionStr);
	       // Integer lifeStagIdInt=MethodUtil.StringToIntConverter(lifeStgId);
	    	String srcOfSalestr=masterMap.get("masterMap").get("sourceOfSaleMap").get(sourceOfSale)+"";
	    	Integer srcOfSaleInt=MethodUtil.StringToIntConverter(srcOfSalestr);
	        if(MethodUtil.isNull(proposalNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	            pstmt.setString(counter++, proposalNumber);
	        }
	        
	        if(caseAppRecievedDateLong==null) {
	        	pstmt.setNull(counter++, Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++, new Timestamp(caseAppRecievedDateLong));
	        }
	        
	        if(objectiveOfInsuranceInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,objectiveOfInsuranceInt);
	        }
	        
	        if(MethodUtil.isNull(caseBussinessArea)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,caseBussinessArea );
	        }
	        
	        if(MethodUtil.isNull(prevPolicyNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        pstmt.setString(counter++,prevPolicyNumber );
	        }
	        
	        if(srcOfSaleInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, srcOfSaleInt);
	        }
	         
	        if(mnylLeadInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,mnylLeadInt);
	        }
	        
	        pstmt.setNull(counter++, Types.INTEGER);//Discussion requires with Mangaleshwar
	        
	        if(productSolutionIdInt==null) {
	          	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,productSolutionIdInt);
	        }
	      
	        if(MethodUtil.isNull(comboProposalNumber)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);	
	        }else {
	        pstmt.setString(counter++, comboProposalNumber);
	        }
	        pstmt.setNull(counter++, Types.INTEGER);//DISCUSS WITH MANGALESHWAR
	        /*
	        if(lifeStagIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,lifeStagIdInt);
	        }
	        */
	        if(MethodUtil.isNull(qurops)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, qurops);	
	        }
	        
	        if(MethodUtil.isNull(sparcsourceCode)) {
	        	pstmt.setNull(counter++, Types.VARCHAR);
	        }else {
	        	pstmt.setString(counter++, sparcsourceCode);	
	        }
	        
	        if(caseCIIdInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,caseCIIdInt);
	        }
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_POLICY_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void INSERT_NG_NB_CEIP_DETAILS_CI(String caseCIID,String businType,String mnylCompanyId,String bdmId,String enrollerId,String mnylFinderId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			Integer caseCIIdInt=MethodUtil.StringToIntConverter(caseCIID);
			Integer companyIdInt=MethodUtil.StringToIntConverter(mnylCompanyId);
			Long bdmIdLong=MethodUtil.StringToLongConverter(bdmId);
			Long enrollerIdLong=MethodUtil.StringToLongConverter(enrollerId);
			Long finderIdLong=MethodUtil.StringToLongConverter(mnylFinderId);
			/*
			 " INSERT INTO MNYL_APP_CASE_CI(MNYL_CASE_CI_ID,MNYL_BUSIN_TYP "+
			" ,MNYL_COMPANY_ID, "+
			" MNYL_BDM_ID,MNYL_ENROLLER_ID,MNYL_FINDER_ID "+
			" ) VALUES(?,?,?,?,?,?) ";
			 */
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_CEIP_DETAILS_INSERT);
	        
			if(caseCIIdInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, caseCIIdInt);
			}
			
			
			if(MethodUtil.isNull(businType)) {
			pstmt.setNull(counter++, Types.VARCHAR);	
			}else {
			pstmt.setString(counter++, businType);
			}
			
			if(companyIdInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, companyIdInt);
			}
			
			if(bdmIdLong==null) {
				pstmt.setNull(counter++, Types.BIGINT);
			}else {
				pstmt.setLong(counter++, bdmIdLong);
			}
			
			if(enrollerIdLong==null) {
				pstmt.setNull(counter++, Types.BIGINT);
			}else {
				pstmt.setLong(counter++, enrollerIdLong);
			}
			
			if(finderIdLong==null) {
				pstmt.setNull(counter++, Types.BIGINT);
			}else {
				pstmt.setLong(counter++, finderIdLong);
			}
			
			
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS_CI Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	public void UPDATE_NG_NB_CEIP_DETAILS_CI(String caseCIID,String businType,String mnylCompanyId,String bdmId,String enrollerId,String mnylFinderId) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_CEIP_DETAILS_UPDATE);
			Integer caseCIIdInt=MethodUtil.StringToIntConverter(caseCIID);
			Integer companyIdInt=MethodUtil.StringToIntConverter(mnylCompanyId);
			Long bdmIdLong=MethodUtil.StringToLongConverter(bdmId);
			Long enrollerIdLong=MethodUtil.StringToLongConverter(enrollerId);
			Long finderIdLong=MethodUtil.StringToLongConverter(mnylFinderId);
	        
			if(caseCIIdInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, caseCIIdInt);
			}
			
			if(MethodUtil.isNull(businType)) {
				pstmt.setNull(counter++, Types.VARCHAR);	
				}else {
				pstmt.setString(counter++, businType);
			}
			
			if(companyIdInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, companyIdInt);
			}
			
			if(bdmIdLong==null) {
				pstmt.setNull(counter++, Types.BIGINT);
			}else {
				pstmt.setLong(counter++, bdmIdLong);
			}
			
			if(enrollerIdLong==null) {
				pstmt.setNull(counter++, Types.BIGINT);
			}else {
				pstmt.setLong(counter++, enrollerIdLong);
			}
			
			if(finderIdLong==null) {
				pstmt.setNull(counter++, Types.BIGINT);
			}else {
				pstmt.setLong(counter++, finderIdLong);
			}
			
			
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS_CI Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void INSERT_NG_NB_AGENT_INFORMATION_CI(String caseCIID,String spCerificateNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_CEIP_DETAILS_INSERT);
			Integer caseCIIDInt=MethodUtil.StringToIntConverter(caseCIID);
			if(caseCIIDInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, caseCIIDInt);
			}
			pstmt.setString(counter++, spCerificateNumber);
	        pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION CI Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	public void UPDATE_NG_NB_AGENT_INFORMATION_CI(String caseCIID,String spCerificateNumber) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_CEIP_DETAILS_UPDATE);
			Integer caseCIIDInt=MethodUtil.StringToIntConverter(caseCIID);
			pstmt.setString(counter++, spCerificateNumber);
			if(caseCIIDInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, caseCIIDInt);
			}
			pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION CI Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void INSERT_NG_NB_DEFENCE_DETAILS_CI(String caseCIID,String deffenceCXhannel,String armyNumber,String unitName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_DEFENCE_DETAILS_INSERT);
			Integer caseCIIDInt=MethodUtil.StringToIntConverter(caseCIID);
			if(caseCIIDInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, caseCIIDInt);
			}
			
			if(MethodUtil.isNull(deffenceCXhannel)) {
				pstmt.setNull(counter++, Types.VARCHAR);
			}else {
			pstmt.setString(counter++, deffenceCXhannel);
			}
			
			if(MethodUtil.isNull(armyNumber)) {
				pstmt.setNull(counter++, Types.VARCHAR);
			}else {
			pstmt.setString(counter++, armyNumber);
			}
			
			if(MethodUtil.isNull(unitName)) {
				pstmt.setNull(counter++, Types.VARCHAR);
			}else {
			pstmt.setString(counter++, unitName);
			}
			
			pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_DEFENCE_DETAILS CI Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}

	public void UPDATE_NG_NB_DEFENCE_DETAILS_CI(String caseCIID,String deffenceCXhannel,String armyNumber,String unitName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			conn= dolphinConfiguration.getDolphinConnection();
			pstmt=conn.prepareStatement(DPHConstants.APP_CASE_CI_NG_NB_DEFENCE_DETAILS_UPDATE);
			Integer caseCIIDInt=MethodUtil.StringToIntConverter(caseCIID);
			if(MethodUtil.isNull(deffenceCXhannel)) {
				pstmt.setNull(counter++, Types.VARCHAR);
			}else {
			pstmt.setString(counter++, deffenceCXhannel);
			}
			
			if(MethodUtil.isNull(armyNumber)) {
				pstmt.setNull(counter++, Types.VARCHAR);
			}else {
			pstmt.setString(counter++, armyNumber);
			}
			
			if(MethodUtil.isNull(unitName)) {
				pstmt.setNull(counter++, Types.VARCHAR);
			}else {
			pstmt.setString(counter++, unitName);
			}
			if(caseCIIDInt==null) {
				pstmt.setNull(counter++, Types.INTEGER);
			}else {
				pstmt.setInt(counter++, caseCIIDInt);
			}
			pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("NG_NB_DEFENCE_DETAILS CI Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
   ///////////////////////////////////////////////////////////APP_CASE_CI ENDS  ////////////////////////////////////////////////////////////
}
