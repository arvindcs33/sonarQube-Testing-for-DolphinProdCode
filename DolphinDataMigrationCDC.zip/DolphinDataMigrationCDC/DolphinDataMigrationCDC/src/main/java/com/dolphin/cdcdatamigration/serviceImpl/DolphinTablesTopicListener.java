package com.dolphin.cdcdatamigration.serviceImpl;



import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import com.dolphin.cdcdatamigration.DolphinConfiguration;
import com.dolphin.cdcdatamigration.daoImpl.AgentDAO;
import com.dolphin.cdcdatamigration.daoImpl.CaseAgentDAO;
import com.dolphin.cdcdatamigration.daoImpl.CaseCancelNeedDAO;
import com.dolphin.cdcdatamigration.daoImpl.CasePlanFundsDAO;
import com.dolphin.cdcdatamigration.daoImpl.CaseReqtDAO;
import com.dolphin.cdcdatamigration.daoImpl.CoverageDAO;
import com.dolphin.cdcdatamigration.daoImpl.CustomerDeclartionCIDAO;
import com.dolphin.cdcdatamigration.daoImpl.DolphinAppCaseDAO;
import com.dolphin.cdcdatamigration.daoImpl.DolphinCustomerDeclarationDAO;
import com.dolphin.cdcdatamigration.daoImpl.MNYLMoneyDAO;
import com.dolphin.cdcdatamigration.daoImpl.PClientAddressDAO;
import com.dolphin.cdcdatamigration.daoImpl.PClientDAO;
import com.dolphin.cdcdatamigration.daoImpl.PaymentDAO;
import com.dolphin.cdcdatamigration.daoImpl.QuestionArreDAO;
import com.dolphin.cdcdatamigration.daoImpl.RiderDetailsDAO;
import com.dolphin.cdcdatamigration.daoImpl.UWDecisionDAO;
import com.dolphin.cdcdatamigration.daoImpl.WelComeCallDAO;
import com.dolphin.cdcdatamigration.daoImpl.WorkBasketDAO;
import com.dolphin.cdcdatamigration.util.DPHConstants;
import com.dolphin.cdcdatamigration.util.MethodUtil;


@Service
public class DolphinTablesTopicListener {
	
	private final Logger logger = LoggerFactory.getLogger(DolphinTablesTopicListener.class);
	

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	@Autowired
	DolphinAppCaseDAO  dolphinAppCaseDAO;
	
	@Autowired 
	DolphinCustomerDeclarationDAO dolphinCustomerDeclarationDAO;
	
	@Autowired
	CaseAgentDAO  caseAgentDAO;
	
	@Autowired
	AgentDAO  agentDAO;
	
	@Autowired
	PaymentDAO paymentDAO;
	
	@Autowired
	CoverageDAO coverageDAO;
	
	@Autowired 
	CaseReqtDAO   caseReqtDAO;
	
	@Autowired
	RiderDetailsDAO    riderDetailsDAO;
	
	@Autowired
	UWDecisionDAO uWDecisionDAO;
	   
	@Autowired
	WorkBasketDAO  workBasketDAO;
	
	@Autowired 
	PClientAddressDAO  pclientAddessDao;
	
	@Autowired 
	MNYLMoneyDAO mnylMoneyDao;
	
	@Autowired 
	CaseCancelNeedDAO  caseCancelDAO;
	
	@Autowired 
	CasePlanFundsDAO  casePlanFundDAO;
	
	@Autowired
	CustomerDeclartionCIDAO  customerDeclarationCIDAO;
	
	@Autowired
	QuestionArreDAO     questionArreDao;
	
	@Autowired
	PClientDAO pClientDAO;
	
	@Autowired
	WelComeCallDAO  welcomeCallDao;
	
	
	/*@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_CEIP_DETAILS"}, groupId = "console-consumer-44039" )
	public void consumeNG_NB_CEIP_DETAILS(@Payload String data) {
    	
    	try{
    		
    	logger.info(data);
    	
    	JSONObject parentObject=new JSONObject(data);
    	
    	JSONObject payload=parentObject.getJSONObject("payload");
	    
    	JSONObject afterObject=payload.getJSONObject("after");
    	
	    String bdmID=afterObject.get("BDM_ID")+"";
	    
	    String enrollerID=afterObject.get("ENROLLER_ID")+"";
	    
	    String finderID=afterObject.get("FINDER_ID")+"";
	    
    	String businessType=afterObject.get("BUSINESS_TYPE")+"";
    	
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    
	    String companyName=afterObject.get("NAME_OF_COMPANY")+"";
	    
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!MethodUtil.isNull(wiName)) {
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_CEIP_DETAILS(bdmID, enrollerID, finderID, businessType,companyName, wiName);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_CEIP_DETAILS(bdmID, enrollerID, finderID, businessType,companyName, wiName);
	    }
	    }else {
	    	logger.info(DPHConstants.WI_NAME_NULL);
	    }*/
		////////////////////////////////////////////////DOLPHIN APP CASE CI STARTS///////////////////////////////////////
		/*
	    String caseCIId="";
		exist=dolphinAppCaseDAO.getAppCaseCIExistOrNot(caseCIId);
		if(!exist) {
			dolphinAppCaseDAO.INSERT_NG_NB_CEIP_DETAILS_CI(caseCIId, businessType, companyName, bdmID, enrollerID, finderID);
		}else {
			dolphinAppCaseDAO.UPDATE_NG_NB_CEIP_DETAILS_CI(caseCIId, businessType, companyName, bdmID, enrollerID, finderID);
		}
	    */	
		///////////////////////////////////////////////DOLPHIN APP_CASE CI ENDS///////////////////////////////////////////
	    
    	/*}catch(Exception ec){
    		logger.error("Exception in NG_NB_CEIP Details",ec);
    	}
    	
	}
    */
     
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_EXT_TABLE"}, groupId = "console-consumer-44048")
	public void consumeNG_NB_EXT_TABLE(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String planName=afterObject.get("PLAN_NAME")+"";
	    String channel=afterObject.get("CHANNEL")+"";
	    String workStatus=afterObject.get("WORK_STATUS")+"";
	    String l2BiName=afterObject.get("L2BI_NAME")+"";
	    String priorityType=afterObject.get("PRIORITY_TYPE")+"";
	    String medNonMed=afterObject.get("MED_NON_MED")+"";
	    //String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
	    String policyId=afterObject.get("PROPOSAL_NUMBER")+"";
	    
	    if(!MethodUtil.isNull(wiName)) {
	    
	    
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    /*
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_EXT_TABLE(wiName, planName, channel, workStatus,l2BiName, priorityType,medNonMed);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_EXT_TABLE(wiName, planName, channel, workStatus,l2BiName, priorityType,medNonMed);
	    }
	    */
	    
	    ////////////////////////////////////: Dholphin Table NG_NB_EXT_TABLE Payment Details 7-SEP-2020 :////////////////////////////////////
	    /*
	    String payorClientId=afterObject.get("PAYOR_CLIENT_ID")+"";
	    String mnylProposerId="";
		
	    exist=paymentDAO.paymentDetailoExistOrNot(wiName);
	    if(!exist) {
	    	paymentDAO.insert_NG_NB_EXT_TABLE(payorClientId,wiName,mnylProposerId);
	    }else {
	    	paymentDAO.update_NG_NB_EXT_TABLE(payorClientId,wiName,mnylProposerId);
	    }
	    */
       ////////////////////////////////////: Dholphin Table NG_NB_EXT_TABLE Payment Details 7-SEP-2020 :////////////////////////////////////
	    
	    /*
	    String adjustedAfyp=afterObject.get("ADJUSTED_AFYP")+"";
	    String adjustedMfyp=afterObject.get("ADJUSTED_MFYP")+"";
	    String mnylCaseMnylDetailId="";//Discuss With Mangaleshwar 
       
	    exist=coverageDAO.getCaseIdExistOrNot(wiName); 
	    if(!exist) {
	    	coverageDAO.insert_NG_NB_EXT_TABLE1(wiName,adjustedAfyp, adjustedMfyp,mnylCaseMnylDetailId);
	    }else {
	    	coverageDAO.update_NG_NB_EXT_TABLE1(adjustedAfyp, adjustedMfyp,wiName,mnylCaseMnylDetailId);
	    }
	    */
	        
	    //////////////////////////////////////////////MNYL_CASE_UW_DECN STARTS//////////////////////////////////////////  
	    /*
	    String caseUWDecnId="";
	    String  finalUWDecision=afterObject.get("FINAL_UW_DECISION")+"";
	    String  uwDecisionDate=afterObject.get("UW_DECISIONED_DATE")+"";
	    exist=uWDecisionDAO.getUWDecisionExistOrNot(wiName);
	    if(!exist) {
	    	uWDecisionDAO.insert_NG_NB_EXT_TABLE(wiName, finalUWDecision, uwDecisionDate,caseUWDecnId);
	    }else{
	    	uWDecisionDAO.update_NG_NB_EXT_TABLE(wiName, finalUWDecision, uwDecisionDate,caseUWDecnId);
	    }
	    */
	    //////////////////////////////////////////////MNYL_CASE_UW_DECN STARTS//////////////////////////////////////////
	    
       //////////////////////////////////////////////////////MNYL MONEY /////////////////////////////////////////////////////////////////
	    /*
	    
	    String moneyStatus=afterObject.get("MONEY_STATUS")+"";
	    String clearedAmount=afterObject.get("CLEARED_AMOUNT")+"";
	    String unclearedAmount=afterObject.get("BOUNCE_AMOUNT")+"";
	    exist=mnylMoneyDao.getMnylMoneyexistOrNot(policyId); 
	    if(!exist) {
	    	mnylMoneyDao.insert_PClientAddress(policyId, moneyStatus, clearedAmount, unclearedAmount);
	    }else {
	    	mnylMoneyDao.update_PClientAddress(policyId, moneyStatus, clearedAmount, unclearedAmount);
	    }
	    */
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	    
	    ////////////////////////////////////////////////////MNYL_CASE_CANCEL STARTS/////////////////////////////////////////
	    /*
	    String cancelId=wiName;
	    String reasonCd=afterObject.get("CANCELLATION_REASON")+"";
	    String cancelDate=afterObject.get("CANCELLATION_DATE")+"";		
	    exist=caseCancelDAO.getMnylCaseCancelExistOrNot(cancelId);
	    if(!exist) {
	    	caseCancelDAO.insert_MnylCaseCancel(wiName, reasonCd, cancelDate,cancelId);
	    }else {
	    	caseCancelDAO.update_MnylCaseCancel(wiName, reasonCd, cancelDate,cancelId);
	    }
	    */
        ////////////////////////////////////////////////////MNYL_CASE_CANCEL ENDS/////////////////////////////////////////
	    
	    
	    ///////////////////////////////////////////////CASE_PCLIENT_ASSOC STARTS/////////////////////////////////////////////
	    /*
	    String cpClid="";// will be disccussed with Mangaleshwar
	    String cpCliAgeNum=afterObject.get("PROPOSER_AGE")+"";
	    if("null".equals(cpCliAgeNum.trim()) ||"".equals(cpCliAgeNum.trim()) ) {
	    	cpCliAgeNum=afterObject.get("INSURED_AGE")+"";
	    }
	    String cpcliSamePayrInd=afterObject.get("ISPAYORCLIENTIDCHANGE")+"";
	    exist=pclientAddessDao.getPClientAssocSelect(cpClid);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAssocNgNBExtTables(cpClid, wiName, cpCliAgeNum, cpcliSamePayrInd);
	    }else {
	    	pclientAddessDao.update_PClientAssocNgNBExtTables(cpClid, wiName, cpCliAgeNum, cpcliSamePayrInd);
	    }
	    */
        ///////////////////////////////////////////////CASE_PCLIENT_ASSOC_CI ENDS/////////////////////////////////////////////
	    
	    
	    ///////////////////////////////////////////////APP CASE CI STARTS////////////////////////////////////////////////////
	    /*
	    String caseCIId=null;
	    String proposalNumber=afterObject.get("PROPOSAL_NO")+"";
	    exist=dolphinAppCaseDAO.getAppCaseCIExistOrNot(caseCIId);
	    if(!exist) {
	    	dolphinAppCaseDAO.INSERT_NG_NB_EXT_CI(caseCIId, wiName, planName, proposalNumber, priorityType);
	    }else {
	    	dolphinAppCaseDAO.UPDATE_NG_NB_EXT_CI(caseCIId, wiName, planName, proposalNumber, priorityType);
	    }
	    */
	    ///////////////////////////////////////////////APP CASE END//////////////////////////////////////////////////////////
	    
	    /////////////////////////////////////////////////WELCOME CALL BULK UPLOAD STARTS/////////////////////////////////////
	    /*
	    String seqNum="";
	    
	    exist=welcomeCallDao.ExistOrNot(wiName);
	    if(!exist) {
	    	welcomeCallDao.insert_NG_NB_EXT(seqNum, policyId, wiName);
	    }else {
	    	welcomeCallDao.update_NG_NB_EXT(policyId, wiName);
	    }
	    */
        /////////////////////////////////////////////////WELCOME CALL BULK UPLOAD ENDS/////////////////////////////////////
	    
	    
	    /* }else {
	    	logger.info(DPHConstants.WI_NAME_NULL);
	    } */
	//}
	
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_POLICY_DETAILS"}, groupId = "console-consumer-44041")
	public void consumeNG_NB_POLICY_DETAILS(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String appRecieveDate=afterObject.get("APP_RECEIVE_DATE")+"";
	    String proposalNumber=afterObject.get("PROPOSAL_NO")+"";
	    String objOfInsurance=afterObject.get("OBJ_OF_INSURANCE")+"";
	    String ruralurbanSocial=afterObject.get("RURAL_URBAN_SOCIAL")+"";
	    String srcOfSale=afterObject.get("SRC_OF_SALE")+"";
	    String prevProposalNumber=afterObject.get("PREV_PROPOSAL_NO")+"";
	    String crmLeadid=afterObject.get("CRM_LEAD_ID")+"";
	    String productSolution=afterObject.get("PRODUCT_SOLUTION")+"";
	    String comboProposalNumber=afterObject.get("COMBO_PROPOSAL_NO")+"";
	    String lifeStage=afterObject.get("LIFE_STAGE")+"";
	    String qRops=afterObject.get("QROPS")+"";
	    String sparcLeadSrc=afterObject.get("SPARC_LEAD_SRC")+"";
	    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
	    
	    if(!MethodUtil.isNull(wiName)) {
	    
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    /*
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_POLICY_DETAILS(wiName, appRecieveDate, proposalNumber, objOfInsurance,ruralurbanSocial, srcOfSale,prevProposalNumber,crmLeadid,productSolution,comboProposalNumber,lifeStage,qRops,sparcLeadSrc);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_POLICY_DETAILS(wiName, appRecieveDate, proposalNumber, objOfInsurance,ruralurbanSocial, srcOfSale,prevProposalNumber,crmLeadid,productSolution,comboProposalNumber,lifeStage,qRops,sparcLeadSrc);
	    }
	    */
	    
	    ////////////////////////////////////////////////////MNYL_CASE_NEED STARTS//////////////////////////////////////////////
	    /*
	    String need=afterObject.get("NEED")+"";
	    String caseNeedId=insertionOrderId;
	    exist=caseCancelDAO.getMnylCaseNeedExistOrNot(wiName);
	    if(!exist) {
	    	caseCancelDAO.insert_MnylCaseNeed(wiName, need,caseNeedId);
	    }else {
	    	caseCancelDAO.update_MnylCaseNeed(wiName, need,caseNeedId);
	    }
	    */
	    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	    
	    /////////////////////////////////////////////////////APP_CASE_CI STARTS///////////////////////////////////////////////
	    /*
	    String caseCIId="";
	    exist=dolphinAppCaseDAO.getAppCaseCIExistOrNot(caseCIId);
	    if(!exist) {
	    	dolphinAppCaseDAO.INSERT_NG_NB_POLICY_DETAILS_EXT_CI(caseCIId, prevProposalNumber, appRecieveDate, objOfInsurance, ruralurbanSocial, prevProposalNumber, srcOfSale, crmLeadid, productSolution, comboProposalNumber, lifeStage, qRops, sparcLeadSrc);
	    }else {
	    	dolphinAppCaseDAO.UPDATE_NG_NB_POLICY_DETAILS_CI(caseCIId, prevProposalNumber, appRecieveDate,  objOfInsurance, ruralurbanSocial, prevProposalNumber, srcOfSale, crmLeadid, productSolution, comboProposalNumber, lifeStage, qRops, sparcLeadSrc);
	    }
	    */
	    
        /////////////////////////////////////////////////////APP_CASE_CI ENDS///////////////////////////////////////////////
	   /* }else {
	    	logger.info(DPHConstants.WI_NAME_NULL);
	    }*/
	//}
	

	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_PROPOSER_DETAILS"}, groupId = "console-consumer-44039")
	public void consumeNG_NB_PROPOSER_DETAILS(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");      ///Currently Its value should be null mangleshwar will tell
	    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
	    
	    String eiaNoAvailable=afterObject.get("EIA_NO_AVAILABLE")+"";
	    boolean exist=false;
	    if(!MethodUtil.isNull(wiName)) {
	    
	    	exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_PROPOSER_DETAILS(wiName, eiaNoAvailable);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_PROPOSER_DETAILS(wiName, eiaNoAvailable);
	    }
	    
	    }else {
	    	logger.info(DPHConstants.WI_NAME_NULL);
	    }
	      ////////////////////////////////////////////////////PCLIENT_ADDRESS  STARTS////////////////////////////////////////////
	    /*
	    String stPrCd=afterObject.get("STATE_UT")+"";
	    String ctryCd=afterObject.get("COUNTRY")+"";
	    String pcladrZipCd=afterObject.get("PIN_CODE")+"";
	    String mnylVillage=afterObject.get("VILLAGE_TOWN")+"";
	    String mnylLandmark=afterObject.get("LANDMARK")+"";
	    String mnylSector=afterObject.get("ROAD_AREA_SECTOR")+"";
	    String mnylHouseNo=afterObject.get("HOUSE_NO_APT_NAME")+"";
	    String mnylMobleNo1=afterObject.get("MOBILE_NO_1")+"";
	    String mnylMobleNo2=afterObject.get("MOBILE_NO_2")+"";
	    String mnylLandline1=afterObject.get("LANDLINE_NO")+"";
	    String mnylStdCode=afterObject.get("STD")+"";
	    String cityName=afterObject.get("CITY_DISTRICT")+"";
	    String stateName=afterObject.get("STATE_UT")+"";
	    String pcli_id=insertionOrderId;
	    exist=pclientAddessDao.getPClientAddressSelectCRA(pcli_id,DPHConstants.FIVE_CRORE);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAddress(pcli_id, "CRA", stPrCd, ctryCd, pcladrZipCd, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo1, mnylMobleNo2, mnylLandline1, mnylStdCode, cityName, stateName, DPHConstants.FIVE_CRORE);
	    }else {
	    	pclientAddessDao.update_PClientAddress(pcli_id, "CRA", stPrCd, ctryCd, pcladrZipCd, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo1, mnylMobleNo2, mnylLandline1, mnylStdCode, cityName, stateName,DPHConstants.FIVE_CRORE);
	    }
	    
	    String stPrCdPerm=afterObject.get("PERM_STATE_UT")+"";
	    String ctryCdperm=afterObject.get("PERM_COUNTRY")+"";
	    String pcladrZipCdPerm=afterObject.get("PERM_PIN_CODE")+"";
	    String mnylVillagePerm=afterObject.get("PERM_VILLAGE_TOWN")+"";
	    String mnylLandmarkPerm=afterObject.get("PERM_LANDMARK")+"";
	    String mnylSectorPerm=afterObject.get("PERM_ROAD_AREA_SECTOR")+"";
	    String mnylHouseNoPerm=afterObject.get("PERM_HOUSE_NO_APT_NAME")+"";
	    String mnylMobleNo1Perm=afterObject.get("PERM_MOBILE_NO_1")+"";
	    String mnylMobleNo2Perm=afterObject.get("PERM_MOBILE_NO_2")+"";
	    String mnylLandline1Perm=afterObject.get("PERM_LANDLINE_NO")+"";
	    String mnylStdCodePerm=afterObject.get("PERM_STD")+"";
	    String cityNamePerm=afterObject.get("PERM_CITY_DISTRICT")+"";
	    String stateNamePerm=afterObject.get("PERM_STATE_UT")+"";
	    exist=pclientAddessDao.getPClientAddressSelectPRA(pcli_id,DPHConstants.FIVE_CRORE);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAddress(pcli_id, "PRA", stPrCdPerm, ctryCdperm, pcladrZipCdPerm, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo1Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, cityNamePerm, stateNamePerm,DPHConstants.FIVE_CRORE);
	    }else {
	    	pclientAddessDao.update_PClientAddress(pcli_id, "PRA", stPrCdPerm, ctryCdperm, pcladrZipCdPerm, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo1Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, cityNamePerm, stateNamePerm,DPHConstants.FIVE_CRORE);
	    }
	    */
       /////////////////////////////////////////////////////PCLIENT_ADDRESS  ENDS////////////////////////////////////////////
	    
	    
	   ////////////////////////////////////////////////////PCLIENT_ADDRESS_CI STARTS////////////////////////////////////////// 
	    /*
	    String pcliIdCI="";
	    exist=pclientAddessDao.getPClientAddressCISelectCRA(pcliIdCI);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAddressCI(pcliIdCI, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo2, mnylMobleNo2, mnylLandline1, mnylStdCode, pcladrZipCd, "CRA", stPrCd, ctryCd, cityName, stateName);
	    }else {
	    	pclientAddessDao.update_PClientAddressCI(pcliIdCI, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo2, mnylMobleNo2, mnylLandline1, mnylStdCode, pcladrZipCd, "CRA", stPrCd, ctryCd, cityName, stateName);
	    }
	    
	    exist=pclientAddessDao.getPClientAddressCISelectPRA(pcliIdCI);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAddressCI(pcliIdCI, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo2Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, pcladrZipCdPerm, "PRA", stPrCdPerm, ctryCdperm, cityNamePerm, stateNamePerm);
	    }else {
	    	pclientAddessDao.insert_PClientAddressCI(pcliIdCI, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo2Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, pcladrZipCdPerm, "PRA", stPrCdPerm, ctryCdperm, cityNamePerm, stateNamePerm);
	    }
	   */ 
	    
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
	    
	    
	    
	    ///////////////////////////////////////PCLIENT  STARTS/////////////////////////////////////////////////////////////////
	    /*
	    String proposer="Proposer";
	    String occupation=afterObject.get("OCCUPATION")+""; 
	    String middleName=afterObject.get("MIDDLE_NAME")+"";
	    String firstName=afterObject.get("FIRST_NAME")+"";
	    String lastName=afterObject.get("LAST_NAME")+"";
	    String dateOfBirth=afterObject.get("DATE_OF_BIRTH")+"";
	    String gender=afterObject.get("GENDER")+"";
	    String typeOfVisa=afterObject.get("TYPE_OF_VISA")+"";
	    String prefMailAddress=afterObject.get("PREF_MAIL_ADDRESS")+"";
	    String idProofProp=afterObject.get("ID_PROOF_PROP")+"";
	    String nationality=afterObject.get("NATIONALITY")+"";
	    String natureOfDuties=afterObject.get("NATURE_OF_DUTIES")+"";
	    String maritalStatus=afterObject.get("MARITAL_STATUS")+"";
	    String title=afterObject.get("TITLE")+"";
	    String emailId=afterObject.get("EMAIL_ID")+"";
	    String exactIncome=afterObject.get("EXACT_INCOME")+"";
	    String dobProof=afterObject.get("DOB_PROOF")+"";
	    String addrProofProp=afterObject.get("ADDR_PROOF_PROP")+"";
	    String clientId=afterObject.get("CLIENT_ID")+"";
	    String politicalExp=afterObject.get("POLITICAL_EXP")+"";
	    String preferredLanguage=afterObject.get("PREFERRED_LANGUAGE")+"";   
	    String education=afterObject.get("EDUCATION")+"";   
	    String industryType=afterObject.get("INDUSTRY_TYPE")+"";   
	    String panNumber=afterObject.get("PAN_NUMBER")+"";   
	    String eiaNoAvailable2=afterObject.get("EIA_NO_AVAILABLE")+"";   
	    String eiaNumber=afterObject.get("EIA_NUMBER")+"";   
	    String repository=afterObject.get("REPOSITORY")+"";   
	    String neftBankAccNo=afterObject.get("NEFT_BANK_ACC_NO")+"";
	    String dateOfIncor=afterObject.get("DATE_OF_INCOR")+"";   
	    String fatherNameHusbandName=afterObject.get("FATHER_NAME")+"";  
	    if(MethodUtil.isNull(fatherNameHusbandName)){
	    	fatherNameHusbandName=afterObject.get("HUSBAND_NAME")+"";
	    }
	    String countryResidingIn=afterObject.get("COUNTRY_RESIDING_IN")+"";   
	    String organizationType=afterObject.get("ORGANIZATION_TYPE")+"";
	    String annuityOption=afterObject.get("ANNUITY_OPTION")+"";   
	    String aadhaarNumber=afterObject.get("AADHAAR_NUMBER")+"";
	    String aadhaarEnrolNo=afterObject.get("AADHAAR_ENROL_NO")+"";   
	   
	    String pcliId=insertionOrderId;
	    exist=pClientDAO.getPcliIdExistOrNot(pcliId,DPHConstants.FIVE_CRORE);
	    if(!exist) {
	    	pClientDAO.insert_NG_NB_PROPOSER_DETAILS(pcliId,proposer,occupation,middleName,firstName,lastName,dateOfBirth,gender,typeOfVisa,prefMailAddress,idProofProp,nationality,natureOfDuties,maritalStatus,title,emailId,exactIncome,dobProof,addrProofProp,clientId,politicalExp,preferredLanguage,education,industryType,panNumber,eiaNoAvailable,eiaNoAvailable2,eiaNumber,repository,neftBankAccNo,dateOfIncor,fatherNameHusbandName,countryResidingIn,organizationType,annuityOption,aadhaarNumber,aadhaarEnrolNo,DPHConstants.FIVE_CRORE);
	    }else {
	    	pClientDAO.update_NG_NB_PROPOSER_DETAILS(pcliId,proposer,occupation,middleName,firstName,lastName,dateOfBirth,gender,typeOfVisa,prefMailAddress,idProofProp,nationality,natureOfDuties,maritalStatus,title,emailId,exactIncome,dobProof,addrProofProp,clientId,politicalExp,preferredLanguage,education,industryType,panNumber,eiaNoAvailable,eiaNoAvailable2,eiaNumber,repository,neftBankAccNo,dateOfIncor,fatherNameHusbandName,countryResidingIn,organizationType,annuityOption,aadhaarNumber,aadhaarEnrolNo,DPHConstants.FIVE_CRORE);
	    }
	    */
	    /////////////////////////////////////PCLIENT ENDS/////////////////////////////////////////////////////////////////////
	    
	    
	/*}
	*/
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_LIST_AGENT_DETAILS"}, groupId = "console-consumer-44039")
	public void consumeNG_NB_LIST_AGENT_DETAILS(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String goCode=afterObject.get("GO_CODE")+"";
	    if(!MethodUtil.isNull(wiName)) {
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_LIST_AGENT_DETAILS(wiName, goCode);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_LIST_AGENT_DETAILS(wiName, goCode);
	    }
	    }else {
	    	logger.info(DPHConstants.WI_NAME_NULL +" IN NG_NB_LIST_AGENT_DETAILS");
	    }
	}
	*/
	
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_POLICY_VALIDATION_DETAILS"}, groupId = "console-consumer-44039")
	public void consumeNG_NB_POLICY_VALIDATION_DETAILS(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String satrightPassCode=afterObject.get("STRAIGHT_PASS_CASE")+"";
	    if(!MethodUtil.isNull(wiName)) {
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_POLICY_VALIDATION_DETAILS(wiName, satrightPassCode);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_POLICY_VALIDATION_DETAILS(wiName, satrightPassCode);
	    }
	    
	    
	    //////////////////////////////////////CUSTOMER_DECLARATION_CI STARTS////////////////////////////////////
	    /*
	    String customerId="";   //Discuss with Mangaleshwar
	    String irpReq=afterObject.get("IRP_REQ")+"";
	     exist=customerDeclarationCIDAO.getMnylCustomerInformationExistOrNot(customerId);
	     if(exist) {
	    	 customerDeclarationCIDAO.insert_NG_NB_POLICY_VALIDATION_DETAILS_CTR_INFRMTION_CI(wiName, irpReq, customerId);
	     }else {
	    	 customerDeclarationCIDAO.update_NG_NB_POLICY_VALIDATION_DETAILS_CTR_INFRMTION_CI(wiName, irpReq, customerId);
	     }
	     */
	    ///////////////////////////////////////////////////////////////////////////////////////////////////////
	     
	     
	     
	    ///////////////////////////////////PCLIENT STARTS////////////////////////////////////////////////////////
	   /*
	    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
	     String pcliId=insertionOrderId;
	     String creditScore=afterObject.get("CREDIT_SCORE")+""; 
	    String incomeSegment=afterObject.get("INCOME_SEGMENT")+"";
	    exist=pClientDAO.getPcliIdExistOrNot(pcliId,DPHConstants.FIVE_CRORE);
	    if(!exist) {
	    //No INSERTION  VALUE SHOULD BE INSERTED UNTIL NG_NB_PROPOSER_DETAILS	//pClientDAO.insert_NG_NB_POLICY_VALIDATION_DETAILS(pcliId,creditScore,incomeSegment);
	    }else {
	    	pClientDAO.update_NG_NB_POLICY_VALIDATION_DETAILS(pcliId,creditScore,incomeSegment,DPHConstants.FIVE_CRORE);
	    }
	    */
	    //////////////////////////////////PCLIENT ENDS/////////////////////////////////////////////////////////
	    
	    /*
	    String pancardRequired=afterObject.get("PAN_CARD_COPY_REQ")+"";
	    exist=paymentDAO.paymentDetailoExistOrNot(wiName);
	    if(!exist) {
	    	////No INSERTION  VALUE SHOULD BE INSERTED UNTIL NG_NB_PROPOSER_DETAILS	//pClientDAO.insert_NG_NB_POLICY_VALIDATION_DETAILS(pcliId,creditScore,incomeSegment);
	    }else {
	    	paymentDAO.update_NG_NB_POLICY_VALIDATION_DETAILS(wiName,pancardRequired);
	    }
	    */	
	   /* }else {
	    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_POLICY_VALIDATION_DETAILS");
	    } */
	    
//	}
	
	
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_DEFENCE_DETAILS"}, groupId = "console-consumer-44039")
	public void consumeNG_NB_DEFENCE_DETAILS(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String defenceChannelCase=afterObject.get("DEFENCE_CHANNEL_CASE")+"";
	    String armyNumber=afterObject.get("ARMY_NUMBER")+"";
	    String unitName=afterObject.get("UNIT_NAME")+"";
	    if(!MethodUtil.isNull(wiName)) {
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_DEFENCE_DETAILS(wiName, defenceChannelCase,armyNumber,unitName);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_DEFENCE_DETAILS(wiName, defenceChannelCase,armyNumber,unitName);
	    }
	    
	    /////////////////////////////////////////////////APP CASE CI STARTS////////////////////////////////////// 
	    /*
	    String caseCIId="";
	    exist=dolphinAppCaseDAO.getAppCaseCIExistOrNot(caseCIId);
	    if(!exist) {
	    	dolphinAppCaseDAO.INSERT_NG_NB_DEFENCE_DETAILS_CI(caseCIId, defenceChannelCase, armyNumber, unitName);
	    }else {
	    	dolphinAppCaseDAO.UPDATE_NG_NB_DEFENCE_DETAILS_CI(caseCIId, defenceChannelCase, armyNumber, unitName);
	    }
	    */
        /////////////////////////////////////////////////APP CASE CI ENDS//////////////////////////////////////
	   /* }else {
	    	
	    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_DEFENCE_DETAILS");
	    }*/
	//}
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_CUSTOMER_INFORMATION"}, groupId = "console-consumer-44039")
	public void consumeNG_NB_CUSTOMER_INFORMATION(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String custId=afterObject.get("CUSTOMER_ID")+"";
	    String caseId=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String customerSignDate=afterObject.get("CUSTOMER_SIGN_DATE")+"";
	    String replacePolicySale=afterObject.get("REPLACEMENT_POLICY_SALE")+"";
	    String custClassification=afterObject.get("AXIS_CUST_CLASS")+"";
	    if("null".equals(custClassification.trim())|| "".equals(custClassification.trim())) {
	    	custClassification=afterObject.get("YBL_CUST_CLASS")+"";
	    }
	    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
	    
	    if(!MethodUtil.isNull(caseId)) {
	    /*
	    boolean exist=dolphinCustomerDeclarationDAO.getAppCaseExistOrNot(caseId);
	    if(!exist) {
	    	dolphinCustomerDeclarationDAO.insert_NG_NB_CUSTOMER_INFORMATION(insertionOrderId,caseId, customerSignDate, custId, replacePolicySale, custClassification);
	    }else {
	    	dolphinCustomerDeclarationDAO.update_NG_NB_CUSTOMER_INFORMATION(custId,caseId, customerSignDate, custId, replacePolicySale, custClassification);
	    }
	     */
	    
	    //////////////////////////////////////////////////////CUSTOMER_DECLARATION_CI//////////////////////////////////////////////////
	  
	    /*
	    String irpScore=afterObject.get("IRP_SCORE")+"";
	    exist=customerDeclarationCIDAO.getMnylCustomerInformationExistOrNot(caseId);
	    if(!exist) {
	    	customerDeclarationCIDAO.insert_NG_NB_CUSTOMER_INFORMATION(custId, caseId, customerSignDate, replacePolicySale, custClassification, irpScore);
	    }else {
	    	customerDeclarationCIDAO.update_NG_NB_CUSTOMER_INFORMATION(custId, caseId, customerSignDate, replacePolicySale, custClassification, irpScore);
	    }
	    */ 
	    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  /*  }else {
	    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_CUSTOMER_INFORMATION");
	    } */
	//}

	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_AGENT_INFORMATION"}, groupId = "console-consumer-44039")
	public void consumeNG_NB_AGENT_INFORMATION(@Payload String data) {
		logger.info(data);
		
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    boolean exist=false;
		///////////////////////////////////////////////////////APP CASE TABLE EXEC/////////////////////////////////////////
	    
        String caseId=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
        if(!MethodUtil.isNull(caseId)) {
        String sp_cert_no=afterObject.get("SP_CERTI_NO")+"";
	    exist=dolphinAppCaseDAO.getAppCaseExistOrNot(caseId);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_AGENT_INFORMATION(caseId, sp_cert_no);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_AGENT_INFORMATION(caseId, sp_cert_no);
	    }
	    
		///////////////////////////////////////////////////////APP CASE TABLE EXEC/////////////////////////////////////////
		
		
		/////////////////////////////////////////////////////CUSTOMER DECLARATION STARTS////////////////////////////////////////
		 /*
	    String mnylSSNCode=afterObject.get("SSN_CODE")+"";
	    String mnylApplicationID=afterObject.get("APPLICATION_ID")+"";
	    String solId=afterObject.get("SOL_ID")+"";
	    String agentSignDate=afterObject.get("AGENT_SIGN_DATE")+"";
	    String wmsSerialNumber=afterObject.get("WMS_SERIAL_NO")+"";
	    String insertionOrderId="INSERTIONORDERID";
	    exist=dolphinCustomerDeclarationDAO.getAppCaseExistOrNot(caseId);
	    if(!exist) {
	    	dolphinCustomerDeclarationDAO.insert_NG_NB_AGENT_INFORMATION(caseId, mnylSSNCode, mnylApplicationID, solId, agentSignDate,wmsSerialNumber,insertionOrderId);
	    }else {
	    	dolphinCustomerDeclarationDAO.update_NG_NB_AGENT_INFORMATION(caseId, mnylSSNCode, mnylApplicationID, solId, agentSignDate,wmsSerialNumber,insertionOrderId);
	    }
	    */
       /////////////////////////////////////////////////////CUSTOMER DECLARATION ENDS////////////////////////////////////////
      
	    
	   //////////////////////////////////////////////////////////////CASE AGENT EXEC//////////////////////////////////////////////////// 
	   /*
	   String caseAgentID=insertionOrderId; 
	   String agentCode=afterObject.get("AGENT_CODE")+""; 
	   String agentName=afterObject.get("AGENT_NAME")+""; 
	   String commissionShare= afterObject.get("COMMISSION_SHARE")+"";
	   exist=caseAgentDAO.getCaseAgentExistOrNot(caseId);
	   if(!exist) {
		   caseAgentDAO.insert_NG_NB_AGENT_INFORMATION(caseId, agentCode, agentName, commissionShare,caseAgentID);
	   }else {
		   caseAgentDAO.update_NG_NB_AGENT_INFORMATION(caseId, agentCode, agentName, commissionShare,caseAgentID);
	   }
	   */
       //////////////////////////////////////////////////////////////CASE AGENT EXEC//////////////////////////////////////////////////// 
	   
	   ///////////////////////////////////////////////MNYL AGENt START/////////////////////////////////////////////////////////////////
	   /*
	   String spCrtFktNumber=afterObject.get("SP_CRTFKT_NUMBER")+"";
	   exist=agentDAO.getAgentExistOrNot(agentCode);
	    if(!exist) {
	    	agentDAO.insert_NG_NB_AGENT_INFORMATION(agentCode, spCrtFktNumber);
	    }else {
	    	agentDAO.update_NG_NB_AGENT_INFORMATION(agentCode, spCrtFktNumber);
	    }
	    */
      ///////////////////////////////////////////////MNYL  AGENT END/////////////////////////////////////////////////////////////////
	   
	    
	  //////////////////////////////////////////////CUSTOMER DECLARATION CI////////////////////////////////////////
	   /*
	   exist=customerDeclarationCIDAO.getMnylCustomerInformationExistOrNot(custId); 
	   if(!exist) {
		   customerDeclarationCIDAO.insert_NG_NB_AGENT_INFORMATION_CTR_INFRMTION_CI(caseId, mnylSSNCode, mnylApplicationID, solId, agentSignDate, wmsSerialNumber,custId);
	   }else {
		   customerDeclarationCIDAO.update_NG_NB_AGENT_INFORMATION_CTR_INFRMTION_CI(caseId, mnylSSNCode, mnylApplicationID, solId, agentSignDate, wmsSerialNumber,custId);
	   }
	   */ 
	   /////////////////////////////////////////////////////////////////////////////////////////////////////////   
	   
	   
	   ////////////////////////////////////////////////////////MNYL_CASE_AGENT_CI STARTS////////////////////////////////////////////////////
	   /*
	   String caseAgentId="";
	   exist=agentDAO.getAgentCIExistOrNot(caseAgentId);
	   if(!exist) {
		   agentDAO.insert_MNYL_CASE_AGENT_CI(agentCode, caseId, agentName, commissionShare,caseAgentId);
	   }else {
		   agentDAO.update_MNYL_CASE_AGENT_CI(agentCode, caseId, agentName, commissionShare,caseAgentId);
	   }
	   */
	   /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	   
      /*  }else {
        	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_AGENT_INFORMATION");
        } */
	   
	   
	   
	//}
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_LIST_AGENT_DETAILS_GRID"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_LIST_AGENT_DETAILS_GRID(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
		String strAgentCd=afterObject.get("AGENT_CODE")+"";
	    String strAgentName=afterObject.get("AGENT_NAME")+"";
	    String strAgentStatus=afterObject.get("AGENT_STATUS")+"";
	    String goCode=afterObject.get("GO_CODE")+"";
	    String afterJoiningDate=afterObject.get("AGENT_JOINING_DATE")+"";
	    String reportingManagerCode=afterObject.get("REPORTING_MANAGER_CODE")+"";
	    String reportingManagerName=afterObject.get("REPORTING_MANAGER_NAME")+"";
	    String agentContactNumber=afterObject.get("AGENT_CONTACT_NUMBER")+"";
	    String agentEmail=afterObject.get("AGENT_EMAIL")+"";
	    String currentUlipStartDate=afterObject.get("CURR_ULIP_START_DATE")+"";
	    String currentUlipEndDate=afterObject.get("CURR_ULIP_END_DATE")+"";
	    String previousUlipStartDate=afterObject.get("PREV_ULIP_START_DATE")+"";
	    String previousUlipEndDate=afterObject.get("PREV_ULIP_END_DATE")+"";
	    String currentAmlStartDate=afterObject.get("CURR_AML_START_DATE")+"";
	    String currentAmlEndDate=afterObject.get("CURR_AML_END_DATE")+"";
	    String previousAmlStartDate=afterObject.get("PREV_AML_START_DATE")+"";
	    String previousAmlEndDate=afterObject.get("PREV_AML_END_DATE")+"";
	    
	    boolean exist=agentDAO.getAgentExistOrNot(strAgentCd);
	    if(!exist) {
	    	agentDAO.insert_NG_NB_LIST_AGENT_DETAILS_GRID(strAgentCd, strAgentName, strAgentStatus, goCode, afterJoiningDate, reportingManagerCode, reportingManagerName, agentContactNumber, agentEmail, currentUlipStartDate, currentUlipEndDate, previousUlipStartDate, previousUlipEndDate, currentAmlStartDate, currentAmlEndDate, previousAmlStartDate, previousAmlEndDate);
	    }else {
	    	agentDAO.update_NG_NB_LIST_AGENT_DETAILS_GRID(strAgentCd, strAgentName, strAgentStatus, goCode, afterJoiningDate, reportingManagerCode, reportingManagerName, agentContactNumber, agentEmail, currentUlipStartDate, currentUlipEndDate, previousUlipStartDate, previousUlipEndDate, currentAmlStartDate, currentAmlEndDate, previousAmlStartDate, previousAmlEndDate);
	    }
	}
	
	*/
	
	//********************************************************************************************START ARVIND CODE ON DATE 4TH SEP 2020 ***********************************************************************************************************************
	
    //=================================== START ===================:- MNYL_CASE_COVERAGE_DETAILS -: ========================================================================================================================================================
		
	/*
		@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_COVERAGE_DETAILS"}, groupId = "console-consumer-44041")
		public void consumeNG_NB_COVERAGE_DETAILS(@Payload String data) {
			logger.info(data);
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
			String wiName=MethodUtil.removeUnRequiredCharacterCaseId( afterObject.get("WI_NAME")+"") ;
			String premiumPayTerm=afterObject.get("PREMIUM_PAY_TERM")+"";
		    String reqModalPremium=afterObject.get("REQ_MODAL_PREMIUM")+"";
		    String coverageTerm=afterObject.get("COVERAGE_TERM")+"";
		    String sumAssured=afterObject.get("SUM_ASSURED")+"";
		    String atp=afterObject.get("ATP")+"";
		    String totalReqPremium=afterObject.get("TOTAL_REQ_PREMIUM")+"";
		    String nonForfeiture=afterObject.get("NON_FORFEITURE")+"";
		    String bonusOption=afterObject.get("BONUS_OPTION")+"";
		    String modeOfPay=afterObject.get("MODE_OF_PAY")+"";
		    String productName=afterObject.get("PRODUCT_NAME")+"";
		    String modalPremium=afterObject.get("MODAL_PREMIUM")+"";
		    String afyp=afterObject.get("AFYP")+"";
		    String vestingAge=afterObject.get("VESTING_AGE")+"";
		    String effectiveDate=afterObject.get("EFFECTIVE_DATE")+"";
		    String deathBenefit=afterObject.get("DEATH_BENEFIT")+"";
		    String gipPayoutDay=afterObject.get("GIP_PAYOUT_DAY")+"";
		    String gipPayoutMethod=afterObject.get("GIP_PAYOUT_METHOD")+"";
		    String smokerClass=afterObject.get("SMOKER_CLASS")+"";
		    String empDiscount=afterObject.get("EMP_DISCOUNT")+"";
		    String guaranteeDeathBenefit=afterObject.get("GUARANTEE_DEATH_BENEFIT")+"";
		    String saveMoreTomorrow=afterObject.get("SAVE_MORE_TOMORROW")+"";
		    String coverageString=afterObject.get("COVERAGE_STRING")+"";
		    String maturityAge=afterObject.get("MATURITY_AGE")+"";
		    String lifeEvent=afterObject.get("LIFE_EVENT")+"";
		    String gst=afterObject.get("GST")+"";
		    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
		    String mnylCaseMnylDetailId=insertionOrderId;
		    
		    if(!MethodUtil.isNull(wiName)) {
		    boolean exist=coverageDAO.getCaseIdExistOrNot(wiName);
		    if(!exist) {
		    	coverageDAO.insert_NG_NB_COVERAGE_DETAILS(wiName, premiumPayTerm, reqModalPremium, coverageTerm, sumAssured, atp, totalReqPremium, nonForfeiture, bonusOption, modeOfPay, productName, modalPremium, afyp, vestingAge, effectiveDate, deathBenefit, gipPayoutDay, gipPayoutMethod, smokerClass,empDiscount, guaranteeDeathBenefit, saveMoreTomorrow, coverageString, maturityAge, lifeEvent, mnylCaseMnylDetailId,gst);
		    }else {
		    	coverageDAO.update_NG_NB_COVERAGE_DETAILS(wiName, premiumPayTerm, reqModalPremium, coverageTerm, sumAssured, atp, totalReqPremium, nonForfeiture, bonusOption, modeOfPay, productName, modalPremium, afyp, vestingAge, effectiveDate, deathBenefit, gipPayoutDay, gipPayoutMethod, smokerClass,empDiscount, guaranteeDeathBenefit, saveMoreTomorrow, coverageString, maturityAge, lifeEvent, mnylCaseMnylDetailId,gst);
		    }
		    }else {
		    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_COVERAGE_DETAILS");
		    }
		}
	    */
	//=================================== END ===================:- MNYL_CASE_COVERAGE_DETAILS -: ========================================================================================================================================================
	  /*
		@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_FUND_SELECTED"}, groupId = "console-consumer-44042")
		public void consumeNG_NB_FUND_SELECTED(@Payload String data) {
			logger.info(data);
			
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
		    boolean exist=false;
		    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
		    String stp=afterObject.get("STP")+"";
		    String mnylCaseMnylDetailId=insertionOrderId;
		    
		    if(!MethodUtil.isNull(wiName)) {
		    /*
		    exist=coverageDAO.getCaseIdExistOrNot(wiName);
		    
		    if(!exist) {
		    	coverageDAO.insert_NG_NB_FUND_SELECTED(wiName,stp,mnylCaseMnylDetailId);
		    }else {
		    	coverageDAO.update_NG_NB_FUND_SELECTED(stp,wiName,mnylCaseMnylDetailId);
		    }
		    */
		    //////////////////////////////////////////////MNYL_CASE_PLAN_FUNS START////////////////////////////////////////////////////////////////
		   /* 
		    String mnylPlanInvestId=insertionOrderId;
		    String fundId=afterObject.get("FUND_NAME")+"";
		    String  mnylAllocatePt=afterObject.get("INITIAL_ALLOCATION")+"";
		    exist=casePlanFundDAO.getCasePlanFundsExistOrNot(wiName);
		    if(!exist)
		    {
		    	casePlanFundDAO.insert_MnylCasePlanFunds(wiName, fundId, mnylAllocatePt,mnylPlanInvestId);
		    }else
		    {
		    	casePlanFundDAO.update_MnylCasePlanFunds(wiName, fundId, mnylAllocatePt,mnylPlanInvestId);
		    }
		    
            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		    }else {
		    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_FUND_SELECTED");
		    }
	   }
	
	  */
	    /*
		//----------------------------------------------------: Dolphin Table NG_NB_PAYMENT_DETAILS :----------------------------------------------------
		/*
		@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_PAYMENT_DETAILS"}, groupId = "console-consumer-44037")
		public void consumeNG_NB_PAYMENT_DETAILS(@Payload String data) {
			logger.info(data);
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
		    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		    String bankAccNo=afterObject.get("BANK_ACC_NO")+"";
		    String micrCode=afterObject.get("MICR_CODE")+"";
		    String ifscCode=afterObject.get("IFSC_CODE")+"";
		    String bankName=afterObject.get("BANK_NAME")+"";
		    String initPremPaid=afterObject.get("INIT_PREM_PAID")+"";
		    String initPremMethod=afterObject.get("INIT_PREM_METHOD")+"";
		    String modeOfPay=null;//afterObject.get("MODE_OF_PAY")+"";
		    String mnylProposerId=afterObject.get("INSERTIONORDERID")+"";
		    if(!MethodUtil.isNull(wiName)) {
		    boolean exist=paymentDAO.paymentDetailoExistOrNot(wiName);
		    if(!exist) {
		    	paymentDAO.insert_NG_NB_PAYMENT_DETAILS(wiName, bankAccNo, micrCode, ifscCode, bankName, initPremPaid, initPremMethod, modeOfPay,mnylProposerId);
		    }else {
		    	paymentDAO.update_NG_NB_PAYMENT_DETAILS(wiName, bankAccNo, micrCode, ifscCode, bankName, initPremPaid, initPremMethod, modeOfPay,mnylProposerId);
		    }
		    }else {
		    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_PAYMENT_DETAILS");
		    }
		}
		*/
		//----------------------------------------------------: Dholphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :----------------------------------------------------
	
	
	//----------------------------------------------------: Dholphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :----------------------------------------------------
	  
		@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_RENEWAL_PREMIUM_DETAILS"}, groupId = "console-consumer-44037")
		public void consumeNG_NB_RENEWAL_PREMIUM_DETAILS(@Payload String data) {
			logger.info(data);
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
		    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		    String ccNo=afterObject.get("CC_NO")+"";
		    String ccExpiryDate=afterObject.get("CC_EXPIRY_DATE")+"";
			   
		    String bankAccountNumber=afterObject.get("BANK_ACCOUNT_NUMBER")+"";
		    String micrCode=afterObject.get("MICR_CODE")+"";
		    String ifscCode=afterObject.get("IFSC_CODE")+"";
		    //String bankNameBranch=afterObject.get("BANK_NAME_BRANCH")+"";
		    String billDrawDate1=afterObject.get("BILL_DRAW_DATE1")+"";
		    String ccExpiryDate2=afterObject.get("CC_EXPIRY_DATE")+"";
		    String ccNo2=afterObject.get("CC_NO")+"";
		    String payorSameProp=afterObject.get("PAYOR_SAME_PROP")+"";
		    
		    String accountHolderName =afterObject.get("ACCOUNT_HOLDER_NAME")+"";
		    String ccHolderName=afterObject.get("CC_HOLDER_NAME")+"";
		    String typeOfAccount=afterObject.get("TYPE_OF_ACCOUNT")+"";
		    String ccHolderName2=afterObject.get("CC_HOLDER_NAME")+"";
		    String accountHolderName2=afterObject.get("ACCOUNT_HOLDER_NAME")+"";
		    
		   
		    String renewalPremiumMethod=afterObject.get("RENEWAL_PREM_METHOD")+"";
		    String ccType=afterObject.get("CC_TYPE")+"";
		    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
		    String mnylProposerId=insertionOrderId;
		   
		    if(!MethodUtil.isNull(wiName)) {
		    boolean exist=paymentDAO.paymentDetailoExistOrNot(wiName);
		    if(!exist) {
		    	paymentDAO.insert_NG_NB_RENEWAL_PREMIUM_DETAILS(wiName,ccNo,ccExpiryDate,bankAccountNumber, micrCode, ifscCode,billDrawDate1,ccExpiryDate2,ccNo2, payorSameProp,accountHolderName,ccHolderName, typeOfAccount,ccHolderName2,accountHolderName2,renewalPremiumMethod,ccType);
		    }else {
		    	paymentDAO.update_NG_NB_RENEWAL_PREMIUM_DETAILS(wiName,ccNo,ccExpiryDate,bankAccountNumber, micrCode, ifscCode, billDrawDate1,ccExpiryDate2,ccNo2, payorSameProp,accountHolderName, ccHolderName, typeOfAccount,ccHolderName2,accountHolderName2,renewalPremiumMethod,ccType);
		    }
		    }else {
		    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_RENEWAL_PREMIUM_DETAILS");
		    }
		}
		
	
	 //----------------------------------------------------: Dholphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :----------------------------------------------------
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_NEFT_DETAILS"}, groupId = "console-consumer-44037")
	public void consumeNG_NB_NEFT_DETAILS(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String accNoNeft=afterObject.get("ACC_NO_NEFT")+"";
	    String micrNeft=afterObject.get("MICR_NEFT")+"";
	    String holderNameNeft=afterObject.get("HOLDER_NAME_NEFT")+"";
	    String ifscNeft=afterObject.get("IFSC_NEFT")+"";
	    String nameBranchNeft=afterObject.get("NAME_BRANCH_NEFT")+"";
	    String typeOfAccNeft=afterObject.get("TYPE_OF_ACC_NEFT")+"";
	    String mnylProposerId=afterObject.get("INSERTIONORDERID")+"";
	    if(!MethodUtil.isNull(wiName)) {
	    boolean exist=paymentDAO.paymentDetailoExistOrNot(wiName);
	    if(!exist) {
	    	paymentDAO.insert_NG_NB_NEFT_DETAILS(wiName,accNoNeft, micrNeft, holderNameNeft, ifscNeft, nameBranchNeft, typeOfAccNeft,mnylProposerId);
	    }else {
	    	paymentDAO.update_NG_NB_NEFT_DETAILS(accNoNeft, micrNeft, holderNameNeft, ifscNeft, nameBranchNeft, typeOfAccNeft,wiName);
	    }
	    }else {
	    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_NEFT_DETAILS");
	    }
	}
	*/
	
	//----------------------------------------------------:- MNYL_RIDER_DETAILS -:- ----------------------------------------------------:
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_LIST_RIDER_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_LIST_RIDER_DETAILS(@Payload String data) {
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String coverageTerm=afterObject.get("COVERAGE_TERM")+""; 
	    String sumAssured=afterObject.get("SUM_ASSURED")+"";
	    String modalPremium=afterObject.get("MODAL_PREMIUM")+"";
	    String insuredDetails=afterObject.get("INSURED_DETAILS")+"";
	    String riderType=afterObject.get("RIDER_TYPE")+"";
	    String gst=afterObject.get("GST")+"";
	    String riderDetailsRiderId=afterObject.get("INSERTIONORDERID")+"";
	    if(!MethodUtil.isNull(wiName)) {
	    Integer coverageDetailsForeignKey=riderDetailsDAO.coverageDetailsPrimaryKey(wiName);
	    if(coverageDetailsForeignKey!=null) {
	    boolean exist=riderDetailsDAO.getRiderDetailIdExistOrNot(riderDetailsRiderId);
	    if(!exist) {
	    	riderDetailsDAO.insert_NG_NB_LIST_RIDER_DETAILS(wiName,coverageTerm,sumAssured,modalPremium,insuredDetails,riderType,gst,riderDetailsRiderId,coverageDetailsForeignKey);
	    }else {
	    	riderDetailsDAO.update_NG_NB_LIST_RIDER_DETAILS(wiName,coverageTerm,sumAssured,modalPremium,insuredDetails,riderType,gst,riderDetailsRiderId);
	    }
	    }
	    }else {
	    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_LIST_RIDER_DETAILS");
	    }
	}
	*/
    ////----------------------------------------------------:- MNYL_RIDER_DETAILS -:- ----------------------------------------------------:

   ////----------------------------------------------------:- CASE_REQT -:- ----------------------------------------------------:
	
	@KafkaListener(topics = {"dolphinDevServer11.dbo.NG_NB_LIST_QC_REQUIREMENTS"}, groupId = "console-consumer-44040")
	public void consumeCASE_REQT(@Payload String data) {
		logger.info(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    
	    String requirementName=afterObject.get("REQUIREMENT_NAME")+""; 
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String reqStatus=afterObject.get("REQ_STATUS")+""; 
	    String orderedDate=afterObject.get("ORDERED_DATE")+"";
	    String receivedDate=afterObject.get("RECEIVED_DATE")+"";
	    
	    String caseReqId=afterObject.get("INSERTIONORDERID")+"";
	    if(!MethodUtil.isNull(wiName)) {
	    boolean exist=caseReqtDAO.getCaseIdExistOrNot(wiName);
	    if(!exist) {
	    	caseReqtDAO.insert_CASE_REQT(requirementName,wiName,reqStatus,orderedDate,receivedDate,caseReqId);
	    }else {
	    	caseReqtDAO.update_CASE_REQT(requirementName,wiName,reqStatus,orderedDate,receivedDate,caseReqId);
	    }
	    }else {
	    	logger.info(DPHConstants.WI_NAME_NULL+" IN CASE_REQT");
	    }
	}
	
   ////----------------------------------------------------:- MNYL_CASE_UW_DECN -:- ----------------------------------------------------:	


	/*
	@KafkaListener(topics = {"dolphinDevServer11.dbo.NG_NB_DECISION_SECTION_UW"}, groupId = "console-consumer-44040")
	public void consumeNG_NB_DECISION_SECTION_UW(@Payload String data) {
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String smokerClassRevised=afterObject.get("SMOKER_CLASS_REVISED")+""; 
	    String uwDecisionDate=null;//afterObject.get("UW_DECISIONED_DATE")+"";
	    String totalPremium=afterObject.get("TOTAL_PREMIUM")+"";
	    String assessedIncome=afterObject.get("ASSESSED_INCOME")+"";
	    if(!MethodUtil.isNull(wiName)) {
	    String caseUWDecnId=afterObject.get("INSERTIONORDERID")+"";;
	    boolean exist=uWDecisionDAO.getUWDecisionExistOrNot(wiName);
	    if(!exist) {
	    	uWDecisionDAO.insert_NG_NB_LIST_RIDER_DETAILS(wiName, smokerClassRevised, uwDecisionDate, totalPremium, assessedIncome, caseUWDecnId);
	    }else {
	    	uWDecisionDAO.update_NG_NB_LIST_RIDER_DETAILS(wiName, smokerClassRevised, uwDecisionDate, totalPremium, assessedIncome, caseUWDecnId);
	    }
	    }else {
	    	logger.info(DPHConstants.WI_NAME_NULL+" IN NG_NB_DECISION_SECTION_UW");
	    }
	}
   */
   ////----------------------------------------------------:- MNYL_CASE_UW_DECN -:- ----------------------------------------------------:	
	

   ////////////////////////////////////////////////////////WORKBASKET STARTS///////////////////////////////////////////////////////////
	/*
	@KafkaListener(topics = {"dolphinDevServer.dbo.WFCURRENTROUTELOGTABLE"}, groupId = "console-consumer-44035")
	public void consume_WFCURRENTROUTELOGTABLE(@Payload String data) {
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String processInstanceId=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("PROCESSINSTANCEID")+"");
	    String userId=afterObject.get("UserId")+""; 
	    String actionDateTime=afterObject.get("ActionDatetime")+"";
	    String workItemId=afterObject.get("WorkItemId")+"";
	    String activityId=afterObject.get("ActivityName")+"";
	    
	    String workBasketId="";
	    boolean exist=workBasketDAO.getWorkBasketExistOrNot(workBasketId);
	    if(!exist) {
	    	workBasketDAO.insert_WORKBASKET(processInstanceId, userId, actionDateTime, workItemId, activityId, workBasketId);
	    }else {
	    	workBasketDAO.update_WORKBASKET(processInstanceId, userId, actionDateTime, workItemId, activityId, workBasketId);
	    }
	   
	}
	*/
	
	
  //////////////////////////////////////////////////////WORKBASKET STARTS///////////////////////////////////////////////////////////
	
	
	
 /////////////////////////////////////////////////////PCLIENT ADDRESS STARTS////////////////////////////////////////////////////////
   /*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_L2BI_DETAILS"}, groupId = "console-consumer-44035")
	public void consume_NG_NB_L2BI_DETAILS(@Payload String data) {
		/*  
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    
	    String pcliId=afterObject.get("INSERTIONORDERID")+"";
	    String stPrCd=afterObject.get("STATE_UT")+"";
	    String ctryCd=afterObject.get("COUNTRY")+"";
	    String pcladrZipCd=afterObject.get("PIN_CODE")+"";
	    String mnylVillage=afterObject.get("VILLAGE_TOWN")+"";
	    String mnylLandmark=afterObject.get("LANDMARK")+"";
	    String mnylSector=afterObject.get("ROAD_AREA_SECTOR")+"";
	    String mnylHouseNo=afterObject.get("HOUSE_NO_APT_NAME")+"";
	    String mnylMobleNo1=afterObject.get("MOBILE_NO_1")+"";
	    String mnylMobleNo2=afterObject.get("MOBILE_NO_2")+"";
	    String mnylLandline1=afterObject.get("LANDLINE_NO")+"";
	    String mnylStdCode=afterObject.get("STD")+"";
	    String cityName=afterObject.get("CITY_DISTRICT")+"";
	    String stateName=afterObject.get("STATE_UT")+"";
	    logger.info("PCLIID is=="+pcliId);
	    boolean exist=pclientAddessDao.getPClientAddressSelectCRA(pcliId,DPHConstants.TWENTY_CRORE);
	    
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAddress(pcliId, "CRA", stPrCd, ctryCd, pcladrZipCd, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo1, mnylMobleNo2, mnylLandline1, mnylStdCode, cityName, stateName,DPHConstants.TWENTY_CRORE);
	    }else {
	    	pclientAddessDao.update_PClientAddress(pcliId, "CRA", stPrCd, ctryCd, pcladrZipCd, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo1, mnylMobleNo2, mnylLandline1, mnylStdCode, cityName, stateName,DPHConstants.TWENTY_CRORE);
	    }
	    
	    String stPrCdPerm=afterObject.get("PERM_STATE_UT")+"";
	    String ctryCdperm=afterObject.get("PERM_COUNTRY")+"";
	    String pcladrZipCdPerm=afterObject.get("PERM_PIN_CODE")+"";
	    String mnylVillagePerm=afterObject.get("PERM_VILLAGE_TOWN")+"";
	    String mnylLandmarkPerm=afterObject.get("PERM_LANDMARK")+"";
	    String mnylSectorPerm=afterObject.get("PERM_ROAD_AREA_SECTOR")+"";
	    String mnylHouseNoPerm=afterObject.get("PERM_HOUSE_NO_APT_NAME")+"";
	    String mnylMobleNo1Perm=afterObject.get("PERM_MOBILE_NO_1")+"";
	    String mnylMobleNo2Perm=afterObject.get("PERM_MOBILE_NO_2")+"";
	    String mnylLandline1Perm=afterObject.get("PERM_LANDLINE_NO")+"";
	    String mnylStdCodePerm=afterObject.get("PERM_STD")+"";
	    String cityNamePerm=afterObject.get("PERM_CITY_DISTRICT")+"";
	    String stateNamePerm=afterObject.get("PERM_STATE_UT")+"";
	    
	    exist=pclientAddessDao.getPClientAddressSelectPRA(pcliId,DPHConstants.TWENTY_CRORE);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAddress(pcliId, "PRA", stPrCdPerm, ctryCdperm, pcladrZipCdPerm, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo1Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, cityNamePerm, stateNamePerm,DPHConstants.TWENTY_CRORE);
	    }else {
	    	pclientAddessDao.update_PClientAddress(pcliId, "PRA", stPrCdPerm, ctryCdperm, pcladrZipCdPerm, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo1Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, cityNamePerm, stateNamePerm,DPHConstants.TWENTY_CRORE);
	    }

        */	    
		   ////////////////////////////////////////////////////PCLIENT_ADDRESS_CI STARTS////////////////////////////////////////// 
		   /* 
	       exist=pclientAddessDao.getPClientAddressCISelectCRA(pcliId);
		    if(!exist) {
		    	pclientAddessDao.insert_PClientAddressCI(pcliId, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo2, mnylMobleNo2, mnylLandline1, mnylStdCode, pcladrZipCd, "CRA", stPrCd, ctryCd, cityName, stateName);
		    }else {
		    	pclientAddessDao.update_PClientAddressCI(pcliId, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo2, mnylMobleNo2, mnylLandline1, mnylStdCode, pcladrZipCd, "CRA", stPrCd, ctryCd, cityName, stateName);
		    }
		    
		    exist=pclientAddessDao.getPClientAddressCISelectPRA(pcliId);
		    if(!exist) {
		    	pclientAddessDao.insert_PClientAddressCI(pcliId, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo2Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, pcladrZipCdPerm, "PRA", stPrCdPerm, ctryCdperm, cityNamePerm, stateNamePerm);
		    }else {
		    	pclientAddessDao.insert_PClientAddressCI(pcliId, mnylVillagePerm, mnylLandmarkPerm, mnylSectorPerm, mnylHouseNoPerm, mnylMobleNo2Perm, mnylMobleNo2Perm, mnylLandline1Perm, mnylStdCodePerm, pcladrZipCdPerm, "PRA", stPrCdPerm, ctryCdperm, cityNamePerm, stateNamePerm);
		    }
		    */
	        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// 
		
		    ////////////////////////////////////////////PCLIENT STARTS//////////////////////////////////////////////////////////////////
		    /*
		    String insured="Insured";
		    String occupation=afterObject.get("OCCUPATION")+""; 
		    String middleName=afterObject.get("MIDDLE_NAME")+"";
		    String firstName=afterObject.get("FIRST_NAME")+"";
		    String lastName=afterObject.get("LAST_NAME")+"";
		    String dob=afterObject.get("DOB")+"";
		    String gender=afterObject.get("GENDER")+"";
		    String typeOfVisa=afterObject.get("TYPE_OF_VISA")+"";
		    String nationality=afterObject.get("NATIONALITY")+"";
		    String natureOfDuties=afterObject.get("NATURE_OF_DUTIES")+"";
		    String maritalStatus=afterObject.get("MARITAL_STATUS")+"";
		    String incomeSource=afterObject.get("INCOME_SOURCE")+"";
		    
		    String title=afterObject.get("TITLE")+"";
		    String emailId=null;//afterObject.get("EMAIL_ID")+"";
		    String exactIncome=afterObject.get("EXACT_INCOME")+"";
		    String dobProof=afterObject.get("DOB_PROOF")+"";
		    String clientId=afterObject.get("CLIENT_ID")+"";
		    String relationshipWithProposer=afterObject.get("RELATIONSHIP_WITH_PROPOSER")+"";

		    String education=afterObject.get("EDUCATION")+"";   
		    String industryType=afterObject.get("INDUSTRY_TYPE")+"";   
		    String fatherNameHusbandName=afterObject.get("FATHER_NAME")+"";
		    if(MethodUtil.isNull(fatherNameHusbandName)){
		    	fatherNameHusbandName=afterObject.get("HUSBAND_NAME")+"";
		    }
		      
		    String organizationType=afterObject.get("ORGANIZATION_TYPE")+"";
		 
		   
		    
		    exist=pClientDAO.getPcliIdExistOrNot(pcliId,DPHConstants.TWENTY_CRORE);
		    if(!exist) {
		    	pClientDAO.insert_NG_NB_L2BI_DETAILS(pcliId,insured,occupation,middleName,firstName,lastName,dob,gender,typeOfVisa,nationality,natureOfDuties,maritalStatus,incomeSource,title,emailId,exactIncome,dobProof,clientId,relationshipWithProposer,education,industryType,fatherNameHusbandName,organizationType,DPHConstants.TWENTY_CRORE);
		    }else {
		    	pClientDAO.update_NG_NB_L2BI_DETAILS(pcliId,insured,occupation,middleName,firstName,lastName,dob,gender,typeOfVisa,nationality,natureOfDuties,maritalStatus,incomeSource,title,emailId,exactIncome,dobProof,clientId,relationshipWithProposer,education,industryType,fatherNameHusbandName,organizationType,DPHConstants.TWENTY_CRORE);
		    }
		    */
            ////////////////////////////////////////////PCLIENT ENDS//////////////////////////////////////////////////////////////////
	/*}	
    */
	
	/*
	@KafkaListener(topics = {"dolphinDevServer10.dbo.NG_NB_LIST_NOMINEE_DETAILS"}, groupId = "console-consumer-44035")
	public void consume_NG_NB_LIST_NOMINEE_DETAILS(@Payload String data) {
		/*
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String pcliId=afterObject.get("INSERTIONORDERID")+"";
	    String stPrCd=afterObject.get("STATE_UT")+"";
	    String ctryCd=afterObject.get("COUNTRY")+"";
	    String pcladrZipCd=afterObject.get("PIN_CODE")+"";
	    String mnylVillage=afterObject.get("VILLAGE_TOWN")+"";
	    String mnylLandmark=afterObject.get("LANDMARK")+"";
	    String mnylSector=afterObject.get("ROAD_AREA_SEC")+"";
	    String mnylHouseNo=null;//afterObject.get("HOUSE_NO_APT_NAME")+"";
	    String mnylMobleNo1=afterObject.get("MOBILE_NO_1")+"";
	    String mnylMobleNo2=afterObject.get("MOBILE_NO_2")+"";
	    String mnylLandline1=afterObject.get("LANDLINE_NO")+"";
	    String mnylStdCode=afterObject.get("STD")+"";
	    String cityName=afterObject.get("CITY_DISTRICT")+"";
	    String stateName=afterObject.get("STATE_UT")+"";
	    String  cpCliSameOwnerInd=  afterObject.get("SAME_AS_PROPOSER")+"";
	    boolean exist=pclientAddessDao.getPClientAddressSelectCRA(pcliId,DPHConstants.FOURTY_CRORE);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAddress(pcliId, "CRA", stPrCd, ctryCd, pcladrZipCd, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo1, mnylMobleNo2, mnylLandline1, mnylStdCode, cityName, stateName,DPHConstants.FOURTY_CRORE);
	    }else {
	    	pclientAddessDao.update_PClientAddress(pcliId, "CRA", stPrCd, ctryCd, pcladrZipCd, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo1, mnylMobleNo2, mnylLandline1, mnylStdCode, cityName, stateName,DPHConstants.FOURTY_CRORE);
	    }
	      
	    */
	    /////////////////////////////////////////////////////////////FOR PCLIENT ASSOCC STARTS //////////////////////////////////////////////////////
	    /*
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    exist=pclientAddessDao.getPClientAssocSelect(wiName);
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAssocNominees(wiName, cpCliSameOwnerInd,pcliId);
	    }else{
	    	pclientAddessDao.update_PClientAssocNominees(wiName, cpCliSameOwnerInd);
	    }
	    */
	    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	    
         ////////////////////////////////////////////////////PCLIENT_ADDRESS_CI STARTS////////////////////////////////////////// 
		/*
	    exist=pclientAddessDao.getPClientAddressCISelectCRA(pcliId);
		if(!exist) {
		pclientAddessDao.insert_PClientAddressCI(pcliId, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo2, mnylMobleNo2, mnylLandline1, mnylStdCode, pcladrZipCd, "CRA", stPrCd, ctryCd, cityName, stateName);
		}else {
		pclientAddessDao.update_PClientAddressCI(pcliId, mnylVillage, mnylLandmark, mnylSector, mnylHouseNo, mnylMobleNo2, mnylMobleNo2, mnylLandline1, mnylStdCode, pcladrZipCd, "CRA", stPrCd, ctryCd, cityName, stateName);
		}
	      
		*/
		//////////////////////////////////////////////////////PCLIENT_ASSOCC_CI STARTS////////////////////////////////////////////////////////
		/*
	    exist=pclientAddessDao.getPClientAssocCISelect(pcliId);       //VALUES OF PCLIID will be given by Mangaleshwar
	    if(!exist) {
	    	pclientAddessDao.insert_PClientAssocCiNominees(pcliId, cpCliSameOwnerInd);
	    }else{
	    	pclientAddessDao.update_PClientAssocCiNominees(pcliId, cpCliSameOwnerInd);
	    }
		*/
       //////////////////////////////////////////////////////PCLIENT_ASSOCC_CI  ENDS////////////////////////////////////////////////////////
	    
	   ///////////////////////////////////////////////////PCLIENT STARTS////////////////////////////////////////////////////////////
			    
		//String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		/*
		String nominee="Nominee";
		String middleName=afterObject.get("MIDDLE_NAME")+"";
		String firstName=afterObject.get("FIRST_NAME")+"";
		String lastName=afterObject.get("LAST_NAME")+"";
		String dob=afterObject.get("DOB")+"";
		String gender=afterObject.get("GENDER")+"";
		String relationshipProposer=afterObject.get("RELATIONSHIP_PROPOSER")+"";
		
		String nationality=afterObject.get("NATIONALITY")+"";
		String percentage=afterObject.get("PERCENTAGE")+"";
		
		String title=afterObject.get("TITLE")+"";
		String emailId=afterObject.get("EMAIL_ID")+"";
		String clientId=afterObject.get("CLIENT_ID")+"";
		
		String education=null;//afterObject.get("EDUCATION")+"";   
		String industryType=null;//afterObject.get("INDUSTRY_TYPE")+"";
		String panNumber=afterObject.get("PAN_NUMBER")+"";
		String reasonForNomination=afterObject.get("REASON_FOR_NOMINATION")+"";
		
		
		exist=pClientDAO.getPcliIdExistOrNot(pcliId,DPHConstants.FOURTY_CRORE);
		if(!exist) {
			pClientDAO.insert_NG_NB_LIST_NOMINEE_DETAILS(pcliId,nominee,middleName,firstName,lastName,dob,gender,relationshipProposer,nationality,percentage,title,emailId,clientId,education,industryType,panNumber,reasonForNomination,DPHConstants.FOURTY_CRORE);
		}else {
			pClientDAO.update_NG_NB_LIST_NOMINEE_DETAILS(pcliId,nominee,middleName,firstName,lastName,dob,gender,relationshipProposer,nationality,percentage,title,emailId,clientId,education,industryType,panNumber,reasonForNomination,DPHConstants.FOURTY_CRORE);
		}
        */
		//////////////////////////////////////////////////PCLIENT ENDS///////////////////////////////////////////////////////////////
	    
	//}	
	
   
	
	///////////////////////////////////////////////////////PCLIENT ASSOC STARTS////////////////////////////////////////////////////////
    /*
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_FEMALE_INFORMATION"}, groupId = "console-consumer-44035")
	public void consume_NG_NB_FEMALE_INFORMATION(@Payload String data) {
	   
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		String isPregnentActivities=afterObject.get("ARE_YOU_PREGNANT")+"";
		//String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
		boolean isExists=false;
		isExists=pclientAddessDao.getPClientAssocSelect(wiName);
		if(!isExists) {
			//pclientAddessDao.insert_PClientAssocFemaleInformation(wiName, isPregnentActivities,insertionOrderId);
		}else {
			pclientAddessDao.update_PClientAssocFemaleInformation(wiName, isPregnentActivities);
		}
		
		
       ////////////////////////////////////////////////////////PCLIENT ASSOC CI STARTS/////////////////////////////////////////////////////////
		
//		String cpClId="";//will be told by Mangaleshwar
//		isExists=pclientAddessDao.getPClientAssocCISelect(cpClId);
//		if(!isExists) {
//			pclientAddessDao.insert_PClientAssocFemaleCIInformation(cpClId, isPregnentActivities);
//		}else {
//			pclientAddessDao.update_PClientAssocFemaleCIInformation(cpClId, isPregnentActivities);
//		}
		
      ////////////////////////////////////////////////////////PCLIENT ASSOC CI ENDS/////////////////////////////////////////////////////////
	}
    */
	/////////////////////////////////////////////////////////PCLIENT ASSOC ENDS//////////////////////////////////////////////////////////////
	
	
    ////////////////////////////////////////////////////////PCLIENT ASSOC CI STARTS/////////////////////////////////////////////////////////
	/*
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_LIFE_STYLE_INFO"}, groupId = "console-consumer-44035")
	public void consume_NG_NB_LIFE_STYLE_INFO(@Payload String data) {
	
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		String hazardousProp=afterObject.get("HAZARDOUS_PROP")+"";
		if("null".equals(hazardousProp.trim()) || "".equals(hazardousProp.trim()) ) {
			hazardousProp=afterObject.get("HAZARDOUS_INSUR")+"";
		}
		boolean isExists=false;
        isExists=pclientAddessDao.getPClientAssocSelect(wiName);
		if(!isExists) {
			//pclientAddessDao.insert_PClientAssocCILifeStyleInfo(cpClId, hazardousProp);
		}else {
			pclientAddessDao.update_PClientAssocLifeStyleInfo(wiName, hazardousProp);
		}
		
     
	}
    */
	 ////////////////////////////////////////////////////////PCLIENT ASSOC CI ENDS/////////////////////////////////////////////////////////
	
	
	
	
	
	
	////////////////////////////////////////////////NG_NB_QUESTIONARRIE SECTION STARTS////////////////////////////////////////////////////////////
	/*
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_MEDICAL_INFORMATION_INSURED"}, groupId = "console-consumer-44035")
	public void consume_NG_NB_MEDICAL_INFORMATION_INSURED(@Payload String data) {
	 
		List<String> insertBtach=new ArrayList<String>();
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String tableName="QUESTIONNAIRE_SELECTION";
	    String columnNames[]= {"CASE_ID","QVALUE"};
	    String values[]=new String[2];
	    String caseId=afterObject.get("WI_NAME")+"";
	    values[0]=caseId;
	    String diabetes=afterObject.get("DIABETES")+"";
	    values[1]=diabetes;
	    String existingQueries=MethodUtil.insertScript( tableName, columnNames, values, "");
	    insertBtach.add(existingQueries);
	    String managingDiabetes=afterObject.get("MANAGING_DIABETES")+"";
	    values[1]=managingDiabetes;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String diabeticFor=afterObject.get("DIABETIC_FOR")+"";
	    values[1]=diabeticFor;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String diabetesComplication=afterObject.get("DIABETES_COMPLICATIONS")+"";
	    values[1]=diabetesComplication;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String diabetesOtherDetails=afterObject.get("DIABETES_OTHER_DETAILS")+"";
	    values[1]=diabetesOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String hypertensionBP=afterObject.get("HYPERTENSION_BP")+"";
	    values[1]=hypertensionBP;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String bpUnderControl=afterObject.get("BP_UNDER_CONTROL")+"";
	    values[1]=bpUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String cholestrolUnderControl =afterObject.get("CHOLESTEROL_UNDER_CONTROL")+"";
	    values[1]=cholestrolUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String thyroidUnderControl=afterObject.get("THYROID_UNDER_CONTROL")+"";
        values[1]=thyroidUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String bpCholestrolUnderControl=afterObject.get("BP_CHOLESTEROL_DETAILS")+"";
        values[1]=bpCholestrolUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String heartDisease=afterObject.get("HEART_DISORDER")+"";
        values[1]=heartDisease;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfChestPain=afterObject.get("HISTORY_OF_CHEST_PAIN")+"";
        values[1]=historyOfChestPain;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String chestPainOtherDetails=afterObject.get("CHEST_PAIN_OTHER_DETAILS")+"";
        values[1]=chestPainOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String lungDisorder=afterObject.get("LUNG_DISORDERS")+"";
        values[1]=lungDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfTuberclosis=afterObject.get("HISTORY_OF_TUBERCULOSIS")+"";
        values[1]=historyOfTuberclosis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String alergyBrochitis=afterObject.get("ALLERGIC_BRONCHITIS")+"";
        values[1]=alergyBrochitis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfAsthma=afterObject.get("HISTORY_OF_ASTHMA")+"";
        values[1]=historyOfAsthma;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String lungDisorderDetails=afterObject.get("LUNG_DISORDERS_DETAILS")+"";
        values[1]=lungDisorderDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String liverRelatedDisorder=afterObject.get("LIVER_RELATED_DISORDER")+"";
        values[1]=liverRelatedDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfJuindice=afterObject.get("HISTORY_OF_JAUNDICE")+"";
        values[1]=historyOfJuindice;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String indigestionConstipation=afterObject.get("INDIGESTION_CONSTIPATION")+"";
        values[1]=indigestionConstipation;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyPfGalBladder=afterObject.get("HISTORY_OF_GALL_BLADDER")+"";
        values[1]=historyPfGalBladder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfStones=afterObject.get("HISTORY_OF_STONES")+"";
        values[1]=historyOfStones;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String liverOtherDetails=afterObject.get("LIVER_OTHER_DETAILS")+"";
        values[1]=liverOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String abnormalGrowth=afterObject.get("ABNORMAL_GROWTH_OR_STD")+"";
        values[1]=abnormalGrowth;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfIron=afterObject.get("HISTORY_OF_IRON_DEFICIENCY")+"";
        values[1]=historyOfIron;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfLipoma=afterObject.get("HISTORY_OF_LIPOMA")+"";
        values[1]=historyOfLipoma;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String abnormalGrowthOtherDetails=afterObject.get("ABNORMAL_GROWTH_OTHER_DETAILS")+"";
        values[1]=abnormalGrowthOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String kidneyDisOrder =afterObject.get("KIDNEY_DISORDER")+"";
        values[1]=kidneyDisOrder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String historyOfUti=afterObject.get("HISTORY_OF_UTI")+"";
        values[1]=historyOfUti;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String historyOfKidneySurgery=afterObject.get("HISTORY_OF_KIDNEY_SURGERY")+"";
        values[1]=historyOfKidneySurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfStone=afterObject.get("HISTORY_OF_STONE")+"";
        values[1]=historyOfStone;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String kidneyOtherDetails=afterObject.get("KIDNEY_OTHER_DETAILS")+"";
        values[1]=kidneyOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String neurologyProblem=afterObject.get("NEUROLOGICAL_PROBLEM")+"";
        values[1]=neurologyProblem;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String neurologyDetails=afterObject.get("NEUROLOGICAL_DETAILS")+"";
        values[1]=neurologyDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String muscularJointDisorder=afterObject.get("MUSCULAR_JOINT_DISORDERS")+"";
        values[1]=muscularJointDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String backPainSlipDisc=afterObject.get("BACK_PAIN_SLIP_DISC")+"";
        values[1]=backPainSlipDisc;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String suggestedphysioTherapy=afterObject.get("SUGGESTED_PHYSIOTHERAPY")+"";
        values[1]=suggestedphysioTherapy;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfhairLineFracture=afterObject.get("HISTORY_OF_HAIRLINE_FRACTURE")+"";
        values[1]=historyOfhairLineFracture;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String osteoarthiritis=afterObject.get("HISTORY_OF_OSTEOARTHRITIS")+"";
        values[1]=osteoarthiritis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfAnyFracture=afterObject.get("HISTORY_OF_ANY_FRACTURE")+"";
        values[1]=historyOfAnyFracture;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String muscularJointDetails=afterObject.get("MUSCULAR_JOINT_DETAILS")+"";
        values[1]=muscularJointDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfHopitalization=afterObject.get("HISTORY_OF_HOSPITALIZATION")+"";
        values[1]=historyOfHopitalization;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hopitalixzationForEver=afterObject.get("HOSPITALIZATION_FOR_FEVER")+"";
        values[1]=hopitalixzationForEver;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForPoisining=afterObject.get("HOSPITALIZATION_OF_POISONING")+"";
        values[1]=hospitalizationForPoisining;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForAccident=afterObject.get("HOSPITALIZATION_FOR_ACCIDENT")+"";
        values[1]=hospitalizationForAccident;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForcSection=afterObject.get("HOSPITALIZED_FOR_CSECTION")+"";
        values[1]=hospitalizationForcSection;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hopitalizedForMalaira=afterObject.get("HOSPITALIZED_FOR_MALARIA")+"";
        values[1]=hopitalizedForMalaira;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfCold=afterObject.get("HISTORY_OF_COLD")+"";
        values[1]=historyOfCold;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForOtherDetails=afterObject.get("HOSPITALIZATION_OTHER_DETAILS")+"";
        values[1]=hospitalizationForOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String advisedTestXRAYSurgery=afterObject.get("ADVISED_TESTS_XRAY_SURGERY")+"";
        values[1]=advisedTestXRAYSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfAccidentSurgery=afterObject.get("HISTORY_OF_ACCIDENT_SURGERY")+"";
        values[1]=historyOfAccidentSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfAppendixSurgery=afterObject.get("HISTORY_OF_APPENDIX_SURGERY")+"";
        values[1]=historyOfAppendixSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfPilesSurgery=afterObject.get("HISTORY_OF_PILES_SURGERY")+"";
        values[1]=historyOfPilesSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfStoneSurgery=afterObject.get("HISTORY_OF_STONE_SURGERY")+"";
        values[1]=historyOfStoneSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String surgeryForInsertionRod=afterObject.get("SURGERY_FOR_INSERTION_RODS")+"";
        values[1]=surgeryForInsertionRod;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String sightCorrectionLasik=afterObject.get("SIGHT_CORRECTION_LASIK")+"";
        values[1]=sightCorrectionLasik;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfCatractSurgery=afterObject.get("HISTORY_OF_CATARACT_SURGERY")+"";
        values[1]=historyOfCatractSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String surgeryForDNS=afterObject.get("SURGERY_FOR_DNS")+"";
        values[1]=surgeryForDNS;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyMRIForBack=afterObject.get("HISTORY_MRI_FOR_BACK")+"";
        values[1]=historyMRIForBack;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String normalHealthCheckUp=afterObject.get("HEALTH_CHECK_UP_NORMAL")+"";
        values[1]=normalHealthCheckUp;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String bloodInvestigation=afterObject.get("BLOOD_INVESTIGATIONS")+"";
        values[1]=bloodInvestigation;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String bloodTestUsg=afterObject.get("BLOOD_TEST_USG_DURING_PREGNANCY")+"";
        values[1]=bloodTestUsg;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfTestBlodDonation=afterObject.get("HISTORY_OF_TEST_BLOOD_DONATION")+"";
        values[1]=historyOfTestBlodDonation;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        
	    String anyOther=afterObject.get("ANY_OTHER_PLEASE_SPECIFY")+"";
	    values[1]=anyOther;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String daignosedCongentalanomaly=afterObject.get("DIAGNOSED_CONGENITAL_ANOMALY")+"";
	    values[1]=daignosedCongentalanomaly;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String congenitalAnomaly=afterObject.get("CONGENITAL_ANOMALY_DETAILS")+"";
	    values[1]=congenitalAnomaly;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String hadGeneticTesting=afterObject.get("HAD_GENETIC_TESTING")+"";
	    values[1]=hadGeneticTesting;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String geneticTestingDetails=afterObject.get("GENETIC_TESTING_DETAILS")+"";
	    values[1]=geneticTestingDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String covidQuestion=afterObject.get("COVID_QUESTIONS")+"";
	    values[1]=covidQuestion;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String contactWithSuspect=afterObject.get("CONTACT_WITH_SUSPECT")+"";
	    values[1]=contactWithSuspect;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String quarantine=afterObject.get("ADVISED_QUARANTINE_1")+"";
	    values[1]=quarantine;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String travelAbroad1year=afterObject.get("TRAVEL_ABROAD_1_YEAR")+"";
	    values[1]=travelAbroad1year;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String adviceQuarantine=afterObject.get("ADVISED_QUARANTINE_2")+"";
	    values[1]=adviceQuarantine;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String specifyCountries=afterObject.get("SPECIFY_COUNTRIES_1")+"";
	    values[1]=specifyCountries;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String durationOfStay=afterObject.get("DURATION_OF_STAY_1")+"";
	    values[1]=durationOfStay;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String dateOfReturnTIndia=afterObject.get("DATE_OF_RETURN_INDIA_1")+"";
	    values[1]=dateOfReturnTIndia;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String plantravelOverseas=afterObject.get("PLAN_TRAVEL_OVERSEAS")+"";
	    values[1]=plantravelOverseas;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String specifyCountries2=afterObject.get("SPECIFY_COUNTRIES_2")+"";
	    values[1]=specifyCountries2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String durationOfstay2=afterObject.get("DURATION_OF_STAY_2")+"";
        values[1]=durationOfstay2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String dateOfIndiaReturn2=afterObject.get("DATE_OF_RETURN_INDIA_2")+"";
        values[1]=dateOfIndiaReturn2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String advisewToBeTested=afterObject.get("ADVISED_TO_BE_TESTED")+"";
        values[1]=advisewToBeTested;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String awaitingTestResult=afterObject.get("AWAITING_TEST_RESULT")+"";
        values[1]=awaitingTestResult;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String experienceSymtom=afterObject.get("EXPERIENCED_SYMPTOMS")+"";
        values[1]=experienceSymtom;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String persistantCough=afterObject.get("PERSISTENT_COUGH")+"";
        values[1]=persistantCough;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String consultDoctor1=afterObject.get("CONSULT_DOCTOR_1")+"";
        values[1]=consultDoctor1;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String anyTreatmentGiven=afterObject.get("ANY_TREATMENT_GIVEN_1")+"";
        values[1]=anyTreatmentGiven;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String exactDiagnisis1=afterObject.get("EXACT_DIAGNOSIS_1")+"";
        values[1]=exactDiagnisis1;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String madOfFullRecovery1=afterObject.get("MADE_FULL_RECOVERY_1")+"";
        values[1]=madOfFullRecovery1;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String adviceSelfIsolate=afterObject.get("ADVISED_SELF_ISOLATE")+"";
        values[1]=adviceSelfIsolate;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String consultDoctor2=afterObject.get("CONSULT_DOCTOR_2")+"";
        values[1]=consultDoctor2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String anyTreatmentGiven2=afterObject.get("ANY_TREATMENT_GIVEN_2")+"";
        values[1]=anyTreatmentGiven2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String exactDiagnosis=afterObject.get("EXACT_DIAGNOSIS_2")+"";
        values[1]=exactDiagnosis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String madeFullRecovery=afterObject.get("MADE_FULL_RECOVERY_2")+"";
        values[1]=madeFullRecovery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String currentlyGoodHealth=afterObject.get("CURRENTLY_GOOD_HEALTH")+"";
        values[1]=currentlyGoodHealth;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String provideDetails=afterObject.get("PROVIDE_DETAILS")+"";
        values[1]=provideDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerInvest=afterObject.get("CANCER_INVEST")+"";
        values[1]=cancerInvest;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerDetails=afterObject.get("CANCER_DETAILS")+"";
        values[1]=cancerDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerParent=afterObject.get("CANCER_PARENT")+"";
        values[1]=cancerParent;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerparentDetails=afterObject.get("CANCER_PARENT_DETAILS")+"";
        values[1]=cancerparentDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String hepatitisBC=afterObject.get("HEPATITIS_B_C")+"";
        values[1]=hepatitisBC;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String hepatiticBCDEtails=afterObject.get("HEPATITIS_B_C_DETAILS")+"";
        values[1]=hepatiticBCDEtails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String recurrCough=afterObject.get("RECURR_COUGH")+"";
        values[1]=recurrCough;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String recurrCoughDetails=afterObject.get("RECURR_COUGH_DETAILS")+"";
        values[1]=recurrCoughDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String travelOutSide=afterObject.get("TRAVEL_OUTSIDE")+"";
        values[1]=travelOutSide;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String travelOutSideDetails=afterObject.get("TRAVEL_OUTSIDE_DETAILS")+"";
        values[1]=travelOutSideDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String familyHeartSixty=afterObject.get("FAMILY_HEART_SIXTY")+"";
        values[1]=familyHeartSixty;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String aidsDisorder=afterObject.get("AIDS_DISORDER")+"";
        values[1]=aidsDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String biospiesDisorder=afterObject.get("BIOSPIES_DISORDER")+"";
        values[1]=biospiesDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String attachMedicalReport=afterObject.get("ATTACH_MEDICAL_REPORT")+"";
        values[1]=attachMedicalReport;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    questionArreDao.consume_NG_NB_MEDICAL_INFORMATION(caseId, insertBtach);
        
	}
	*/
	/*
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_MEDICAL_INFORMATION_PROPOSER"}, groupId = "console-consumer-44035")
	public void consume_NG_NB_MEDICAL_INFORMATION_PROPOSER(@Payload String data) {
	
		List<String> insertBtach=new ArrayList<String>();
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String tableName="QUESTIONNAIRE_SELECTION";
	    String columnNames[]= {"CASE_ID","QVALUE"};
	    String values[]=new String[2];
	    String caseId=afterObject.get("WI_NAME")+"";
	    values[0]=caseId;
	    String diabetes=afterObject.get("DIABETES")+"";
	    values[1]=diabetes;
	    String existingQueries=MethodUtil.insertScript( tableName, columnNames, values, "");
	    insertBtach.add(existingQueries);
	    String managingDiabetes=afterObject.get("MANAGING_DIABETES")+"";
	    values[1]=managingDiabetes;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String diabeticFor=afterObject.get("DIABETIC_FOR")+"";
	    values[1]=diabeticFor;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String diabetesComplication=afterObject.get("DIABETES_COMPLICATIONS")+"";
	    values[1]=diabetesComplication;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String diabetesOtherDetails=afterObject.get("DIABETES_OTHER_DETAILS")+"";
	    values[1]=diabetesOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    String hypertensionBP=afterObject.get("HYPERTENSION_BP")+"";
	    values[1]=hypertensionBP;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String bpUnderControl=afterObject.get("BP_UNDER_CONTROL")+"";
	    values[1]=bpUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String cholestrolUnderControl =afterObject.get("CHOLESTEROL_UNDER_CONTROL")+"";
	    values[1]=cholestrolUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String thyroidUnderControl=afterObject.get("THYROID_UNDER_CONTROL")+"";
        values[1]=thyroidUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String bpCholestrolUnderControl=afterObject.get("BP_CHOLESTEROL_DETAILS")+"";
        values[1]=bpCholestrolUnderControl;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String heartDisease=afterObject.get("HEART_DISORDER")+"";
        values[1]=heartDisease;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfChestPain=afterObject.get("HISTORY_OF_CHEST_PAIN")+"";
        values[1]=historyOfChestPain;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String chestPainOtherDetails=afterObject.get("CHEST_PAIN_OTHER_DETAILS")+"";
        values[1]=chestPainOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String lungDisorder=afterObject.get("LUNG_DISORDERS")+"";
        values[1]=lungDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfTuberclosis=afterObject.get("HISTORY_OF_TUBERCULOSIS")+"";
        values[1]=historyOfTuberclosis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String alergyBrochitis=afterObject.get("ALLERGIC_BRONCHITIS")+"";
        values[1]=alergyBrochitis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfAsthma=afterObject.get("HISTORY_OF_ASTHMA")+"";
        values[1]=historyOfAsthma;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String lungDisorderDetails=afterObject.get("LUNG_DISORDERS_DETAILS")+"";
        values[1]=lungDisorderDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String liverRelatedDisorder=afterObject.get("LIVER_RELATED_DISORDER")+"";
        values[1]=liverRelatedDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfJuindice=afterObject.get("HISTORY_OF_JAUNDICE")+"";
        values[1]=historyOfJuindice;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String indigestionConstipation=afterObject.get("INDIGESTION_CONSTIPATION")+"";
        values[1]=indigestionConstipation;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyPfGalBladder=afterObject.get("HISTORY_OF_GALL_BLADDER")+"";
        values[1]=historyPfGalBladder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfStones=afterObject.get("HISTORY_OF_STONES")+"";
        values[1]=historyOfStones;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String liverOtherDetails=afterObject.get("LIVER_OTHER_DETAILS")+"";
        values[1]=liverOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String abnormalGrowth=afterObject.get("ABNORMAL_GROWTH_OR_STD")+"";
        values[1]=abnormalGrowth;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfIron=afterObject.get("HISTORY_OF_IRON_DEFICIENCY")+"";
        values[1]=historyOfIron;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String historyOfLipoma=afterObject.get("HISTORY_OF_LIPOMA")+"";
        values[1]=historyOfLipoma;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String abnormalGrowthOtherDetails=afterObject.get("ABNORMAL_GROWTH_OTHER_DETAILS")+"";
        values[1]=abnormalGrowthOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String kidneyDisOrder =afterObject.get("KIDNEY_DISORDER")+"";
        values[1]=kidneyDisOrder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String historyOfUti=afterObject.get("HISTORY_OF_UTI")+"";
        values[1]=historyOfUti;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String historyOfKidneySurgery=afterObject.get("HISTORY_OF_KIDNEY_SURGERY")+"";
        values[1]=historyOfKidneySurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfStone=afterObject.get("HISTORY_OF_STONE")+"";
        values[1]=historyOfStone;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String kidneyOtherDetails=afterObject.get("KIDNEY_OTHER_DETAILS")+"";
        values[1]=kidneyOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String neurologyProblem=afterObject.get("NEUROLOGICAL_PROBLEM")+"";
        values[1]=neurologyProblem;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String neurologyDetails=afterObject.get("NEUROLOGICAL_DETAILS")+"";
        values[1]=neurologyDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String muscularJointDisorder=afterObject.get("MUSCULAR_JOINT_DISORDERS")+"";
        values[1]=muscularJointDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String backPainSlipDisc=afterObject.get("BACK_PAIN_SLIP_DISC")+"";
        values[1]=backPainSlipDisc;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String suggestedphysioTherapy=afterObject.get("SUGGESTED_PHYSIOTHERAPY")+"";
        values[1]=suggestedphysioTherapy;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfhairLineFracture=afterObject.get("HISTORY_OF_HAIRLINE_FRACTURE")+"";
        values[1]=historyOfhairLineFracture;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String osteoarthiritis=afterObject.get("HISTORY_OF_OSTEOARTHRITIS")+"";
        values[1]=osteoarthiritis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfAnyFracture=afterObject.get("HISTORY_OF_ANY_FRACTURE")+"";
        values[1]=historyOfAnyFracture;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String muscularJointDetails=afterObject.get("MUSCULAR_JOINT_DETAILS")+"";
        values[1]=muscularJointDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfHopitalization=afterObject.get("HISTORY_OF_HOSPITALIZATION")+"";
        values[1]=historyOfHopitalization;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hopitalixzationForEver=afterObject.get("HOSPITALIZATION_FOR_FEVER")+"";
        values[1]=hopitalixzationForEver;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForPoisining=afterObject.get("HOSPITALIZATION_OF_POISONING")+"";
        values[1]=hospitalizationForPoisining;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForAccident=afterObject.get("HOSPITALIZATION_FOR_ACCIDENT")+"";
        values[1]=hospitalizationForAccident;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForcSection=afterObject.get("HOSPITALIZED_FOR_CSECTION")+"";
        values[1]=hospitalizationForcSection;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hopitalizedForMalaira=afterObject.get("HOSPITALIZED_FOR_MALARIA")+"";
        values[1]=hopitalizedForMalaira;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfCold=afterObject.get("HISTORY_OF_COLD")+"";
        values[1]=historyOfCold;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String hospitalizationForOtherDetails=afterObject.get("HOSPITALIZATION_OTHER_DETAILS")+"";
        values[1]=hospitalizationForOtherDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String advisedTestXRAYSurgery=afterObject.get("ADVISED_TESTS_XRAY_SURGERY")+"";
        values[1]=advisedTestXRAYSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfAccidentSurgery=afterObject.get("HISTORY_OF_ACCIDENT_SURGERY")+"";
        values[1]=historyOfAccidentSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfAppendixSurgery=afterObject.get("HISTORY_OF_APPENDIX_SURGERY")+"";
        values[1]=historyOfAppendixSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfPilesSurgery=afterObject.get("HISTORY_OF_PILES_SURGERY")+"";
        values[1]=historyOfPilesSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfStoneSurgery=afterObject.get("HISTORY_OF_STONE_SURGERY")+"";
        values[1]=historyOfStoneSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String surgeryForInsertionRod=afterObject.get("SURGERY_FOR_INSERTION_RODS")+"";
        values[1]=surgeryForInsertionRod;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String sightCorrectionLasik=afterObject.get("SIGHT_CORRECTION_LASIK")+"";
        values[1]=sightCorrectionLasik;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfCatractSurgery=afterObject.get("HISTORY_OF_CATARACT_SURGERY")+"";
        values[1]=historyOfCatractSurgery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String surgeryForDNS=afterObject.get("SURGERY_FOR_DNS")+"";
        values[1]=surgeryForDNS;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyMRIForBack=afterObject.get("HISTORY_MRI_FOR_BACK")+"";
        values[1]=historyMRIForBack;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String normalHealthCheckUp=afterObject.get("HEALTH_CHECK_UP_NORMAL")+"";
        values[1]=normalHealthCheckUp;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String bloodInvestigation=afterObject.get("BLOOD_INVESTIGATIONS")+"";
        values[1]=bloodInvestigation;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String bloodTestUsg=afterObject.get("BLOOD_TEST_USG_DURING_PREGNANCY")+"";
        values[1]=bloodTestUsg;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String historyOfTestBlodDonation=afterObject.get("HISTORY_OF_TEST_BLOOD_DONATION")+"";
        values[1]=historyOfTestBlodDonation;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        
	    String anyOther=afterObject.get("ANY_OTHER_PLEASE_SPECIFY")+"";
	    values[1]=anyOther;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String daignosedCongentalanomaly=afterObject.get("DIAGNOSED_CONGENITAL_ANOMALY")+"";
	    values[1]=daignosedCongentalanomaly;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String congenitalAnomaly=afterObject.get("CONGENITAL_ANOMALY_DETAILS")+"";
	    values[1]=congenitalAnomaly;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String hadGeneticTesting=afterObject.get("HAD_GENETIC_TESTING")+"";
	    values[1]=hadGeneticTesting;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String geneticTestingDetails=afterObject.get("GENETIC_TESTING_DETAILS")+"";
	    values[1]=geneticTestingDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String covidQuestion=afterObject.get("COVID_QUESTIONS")+"";
	    values[1]=covidQuestion;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String contactWithSuspect=afterObject.get("CONTACT_WITH_SUSPECT")+"";
	    values[1]=contactWithSuspect;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
	    String quarantine=afterObject.get("ADVISED_QUARANTINE_1")+"";
	    values[1]=quarantine;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String travelAbroad1year=afterObject.get("TRAVEL_ABROAD_1_YEAR")+"";
	    values[1]=travelAbroad1year;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String adviceQuarantine=afterObject.get("ADVISED_QUARANTINE_2")+"";
	    values[1]=adviceQuarantine;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String specifyCountries=afterObject.get("SPECIFY_COUNTRIES_1")+"";
	    values[1]=specifyCountries;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String durationOfStay=afterObject.get("DURATION_OF_STAY_1")+"";
	    values[1]=durationOfStay;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String dateOfReturnTIndia=afterObject.get("DATE_OF_RETURN_INDIA_1")+"";
	    values[1]=dateOfReturnTIndia;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String plantravelOverseas=afterObject.get("PLAN_TRAVEL_OVERSEAS")+"";
	    values[1]=plantravelOverseas;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    String specifyCountries2=afterObject.get("SPECIFY_COUNTRIES_2")+"";
	    values[1]=specifyCountries2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
        String durationOfstay2=afterObject.get("DURATION_OF_STAY_2")+"";
        values[1]=durationOfstay2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String dateOfIndiaReturn2=afterObject.get("DATE_OF_RETURN_INDIA_2")+"";
        values[1]=dateOfIndiaReturn2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String advisewToBeTested=afterObject.get("ADVISED_TO_BE_TESTED")+"";
        values[1]=advisewToBeTested;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String awaitingTestResult=afterObject.get("AWAITING_TEST_RESULT")+"";
        values[1]=awaitingTestResult;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String experienceSymtom=afterObject.get("EXPERIENCED_SYMPTOMS")+"";
        values[1]=experienceSymtom;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String persistantCough=afterObject.get("PERSISTENT_COUGH")+"";
        values[1]=persistantCough;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String consultDoctor1=afterObject.get("CONSULT_DOCTOR_1")+"";
        values[1]=consultDoctor1;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String anyTreatmentGiven=afterObject.get("ANY_TREATMENT_GIVEN_1")+"";
        values[1]=anyTreatmentGiven;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String exactDiagnisis1=afterObject.get("EXACT_DIAGNOSIS_1")+"";
        values[1]=exactDiagnisis1;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String madOfFullRecovery1=afterObject.get("MADE_FULL_RECOVERY_1")+"";
        values[1]=madOfFullRecovery1;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String adviceSelfIsolate=afterObject.get("ADVISED_SELF_ISOLATE")+"";
        values[1]=adviceSelfIsolate;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String consultDoctor2=afterObject.get("CONSULT_DOCTOR_2")+"";
        values[1]=consultDoctor2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String anyTreatmentGiven2=afterObject.get("ANY_TREATMENT_GIVEN_2")+"";
        values[1]=anyTreatmentGiven2;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String exactDiagnosis=afterObject.get("EXACT_DIAGNOSIS_2")+"";
        values[1]=exactDiagnosis;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String madeFullRecovery=afterObject.get("MADE_FULL_RECOVERY_2")+"";
        values[1]=madeFullRecovery;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String currentlyGoodHealth=afterObject.get("CURRENTLY_GOOD_HEALTH")+"";
        values[1]=currentlyGoodHealth;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String provideDetails=afterObject.get("PROVIDE_DETAILS")+"";
        values[1]=provideDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerInvest=afterObject.get("CANCER_INVEST")+"";
        values[1]=cancerInvest;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerDetails=afterObject.get("CANCER_DETAILS")+"";
        values[1]=cancerDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerParent=afterObject.get("CANCER_PARENT")+"";
        values[1]=cancerParent;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String cancerparentDetails=afterObject.get("CANCER_PARENT_DETAILS")+"";
        values[1]=cancerparentDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String hepatitisBC=afterObject.get("HEPATITIS_B_C")+"";
        values[1]=hepatitisBC;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String hepatiticBCDEtails=afterObject.get("HEPATITIS_B_C_DETAILS")+"";
        values[1]=hepatiticBCDEtails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String recurrCough=afterObject.get("RECURR_COUGH")+"";
        values[1]=recurrCough;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String recurrCoughDetails=afterObject.get("RECURR_COUGH_DETAILS")+"";
        values[1]=recurrCoughDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String travelOutSide=afterObject.get("TRAVEL_OUTSIDE")+"";
        values[1]=travelOutSide;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String travelOutSideDetails=afterObject.get("TRAVEL_OUTSIDE_DETAILS")+"";
        values[1]=travelOutSideDetails;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String familyHeartSixty=afterObject.get("FAMILY_HEART_SIXTY")+"";
        values[1]=familyHeartSixty;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String aidsDisorder=afterObject.get("AIDS_DISORDER")+"";
        values[1]=aidsDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String biospiesDisorder=afterObject.get("BIOSPIES_DISORDER")+"";
        values[1]=biospiesDisorder;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    
        String attachMedicalReport=afterObject.get("ATTACH_MEDICAL_REPORT")+"";
        values[1]=attachMedicalReport;
	    existingQueries=MethodUtil.insertScript( tableName, columnNames, values, existingQueries);
	    insertBtach.add(existingQueries);
	    
	    questionArreDao.consume_NG_NB_MEDICAL_INFORMATION(caseId, insertBtach);
        
	}
	*/

     /*
	@KafkaListener(topics = {"dolphinDevServer11.dbo.NG_NB_WELCOME_CALL"}, groupId = "console-consumer-44040")
	public void consume_NG_NB_WELCOME_CALL(@Payload String data) {
	    logger.info(data);
		JSONObject parentObject=new JSONObject(data);
		JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String insertionOrderId=afterObject.get("INSERTIONORDERID")+"";
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		String finalDisposition=afterObject.get("POSV_RESPONSE")+""; 
		String notes=afterObject.get("WC_NOTES")+"";
		boolean exists=welcomeCallDao.ExistOrNot(wiName);
		if(!exists) {
		//	welcomeCallDao.insert_NG_NB_WELCOME_CALL(insertionOrderId, wiName, finalDisposition, notes);  Will happen in EXT table
		}else {
			welcomeCallDao.update_NG_NB_WELCOME_CALL(wiName, finalDisposition, notes);
		}
		
	}
	*/
}
   ////////////////////////////////////////////////NG_NB_QUESTIONARRIE SECTION   ENDS////////////////////////////////////////////////////////////

