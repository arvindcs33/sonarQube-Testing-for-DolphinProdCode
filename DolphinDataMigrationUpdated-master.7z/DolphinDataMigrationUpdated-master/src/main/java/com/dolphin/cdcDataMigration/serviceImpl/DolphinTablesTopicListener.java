package com.dolphin.cdcDataMigration.serviceImpl;



import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.DAOImpl.AgentDAO;
import com.dolphin.cdcDataMigration.DAOImpl.CaseAgentDAO;
import com.dolphin.cdcDataMigration.DAOImpl.CaseReqtDAO;
import com.dolphin.cdcDataMigration.DAOImpl.CaseUwDecnDAO;
import com.dolphin.cdcDataMigration.DAOImpl.CoverageDAO;
import com.dolphin.cdcDataMigration.DAOImpl.DolphinAppCaseDAO;
import com.dolphin.cdcDataMigration.DAOImpl.DolphinCustomerDeclarationDAO;
import com.dolphin.cdcDataMigration.DAOImpl.PaymentDAO;
import com.dolphin.cdcDataMigration.DAOImpl.RiderDetailsDAO;
import com.dolphin.cdcDataMigration.util.MethodUtil;


@Service
public class DolphinTablesTopicListener {
	
	private final Logger logger = LoggerFactory.getLogger(DolphinTablesTopicListener.class);
	

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	@Autowired
	DolphinAppCaseDAO  dolphinAppCaseDAO;
	
	@Autowired 
	DolphinCustomerDeclarationDAO dolphinCustomerDeclarationDAO;
	
	@Autowired
	CaseAgentDAO  caseAgentDAO;
	
	@Autowired
	AgentDAO  agentDAO;
	
	@Autowired
	PaymentDAO paymentDAO;
	
	@Autowired
	CoverageDAO coverageDAO;
	
	@Autowired
	RiderDetailsDAO riderDetailsDAO;
	
	@Autowired
	CaseReqtDAO caseReqtDAO;
	
	@Autowired
	CaseUwDecnDAO caseUwDecnDAO;
	/*
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_CEIP_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_CEIP_DETAILS(@Payload String data) {
    	
    	try{
    		
    	
    	JSONObject parentObject=new JSONObject(data);
    	
    	JSONObject payload=parentObject.getJSONObject("payload");
	    System.out.println(payload);
    	JSONObject afterObject=payload.getJSONObject("after");
    	System.out.println(afterObject);
	    String bdmID=afterObject.get("BDM_ID")+"";
	    System.out.println(bdmID);
	    String enrollerID=afterObject.get("ENROLLER_ID")+"";
	    System.out.println(enrollerID);
	    String finderID=afterObject.get("FINDER_ID")+"";
	    System.out.println(finderID);
    	String businessType=afterObject.get("BUSINESS_TYPE")+"";
    	System.out.println(businessType);
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    System.out.println(wiName);
	    String companyName=afterObject.get("NAME_OF_COMPANY")+"";
	    System.out.println(companyName);
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_CEIP_DETAILS(bdmID, enrollerID, finderID, businessType,companyName, wiName);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_CEIP_DETAILS(bdmID, enrollerID, finderID, businessType,companyName, wiName);
	    }
    	}catch(Exception ec){
    		ec.printStackTrace();
    	}
	}

    */
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_EXT_TABLE"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_EXT_TABLE(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String planName=afterObject.get("PLAN_NAME")+"";
	    String channel=afterObject.get("CHANNEL")+"";
	    String workStatus=afterObject.get("WORK_STATUS")+"";
	    String l2BiName=afterObject.get("L2BI_NAME")+"";
	    String priorityType=afterObject.get("PRIORITY_TYPE")+"";
	    String medNonMed=afterObject.get("MED_NON_MED")+"";
	    
	    
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_EXT_TABLE(wiName, planName, channel, workStatus,l2BiName, priorityType,medNonMed);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_EXT_TABLE(wiName, planName, channel, workStatus,l2BiName, priorityType,medNonMed);
	    }
	    
	    
	    ////////////////////////////////////: Dholphin Table NG_NB_EXT_TABLE Payment Details 7-SEP-2020 :////////////////////////////////////
	    String payorClientId=afterObject.get("PAYOR_CLIENT_ID")+"";
		    
	    exist=paymentDAO.paymentDetailoExistOrNot(wiName);
	    if(!exist) {
	    	paymentDAO.insert_NG_NB_EXT_TABLE(payorClientId,wiName);
	    }else {
	    	paymentDAO.update_NG_NB_EXT_TABLE(payorClientId,wiName);
	    }
       ////////////////////////////////////: Dholphin Table NG_NB_EXT_TABLE Payment Details 7-SEP-2020 :////////////////////////////////////
	    
	    
	    String adjustedAfyp=afterObject.get("ADJUSTED_AFYP")+"";
	    String adjustedMfyp=afterObject.get("ADJUSTED_MFYP")+"";
	    
       
	   exist=coverageDAO.getCaseIdExistOrNot(wiName); 
	    if(!exist) {
	    	coverageDAO.insert_NG_NB_EXT_TABLE1(wiName,adjustedAfyp, adjustedMfyp);
	    }else {
	    	coverageDAO.update_NG_NB_EXT_TABLE1(adjustedAfyp, adjustedMfyp,wiName);
	    }
	    
	    
	}
	
	/*
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_POLICY_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_POLICY_DETAILS(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String appRecieveDate=afterObject.get("APP_RECEIVE_DATE")+"";
	    String proposalNumber=afterObject.get("PROPOSAL_NO")+"";
	    String objOfInsurance=afterObject.get("OBJ_OF_INSURANCE")+"";
	    String ruralurbanSocial=afterObject.get("RURAL_URBAN_SOCIAL")+"";
	    String srcOfSale=afterObject.get("SRC_OF_SALE")+"";
	    String prevProposalNumber=afterObject.get("PREV_PROPOSAL_NO")+"";
	    String crmLeadid=afterObject.get("CRM_LEAD_ID")+"";
	    String productSolution=afterObject.get("PRODUCT_SOLUTION")+"";
	    String comboProposalNumber=afterObject.get("COMBO_PROPOSAL_NO")+"";
	    String lifeStage=afterObject.get("LIFE_STAGE")+"";
	    String qRops=afterObject.get("QROPS")+"";
	    String sparcLeadSrc=afterObject.get("SPARC_LEAD_SRC")+"";
	    
	    
	    
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_POLICY_DETAILS(wiName, appRecieveDate, proposalNumber, objOfInsurance,ruralurbanSocial, srcOfSale,prevProposalNumber,crmLeadid,productSolution,comboProposalNumber,lifeStage,qRops,sparcLeadSrc);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_POLICY_DETAILS(wiName, appRecieveDate, proposalNumber, objOfInsurance,ruralurbanSocial, srcOfSale,prevProposalNumber,crmLeadid,productSolution,comboProposalNumber,lifeStage,qRops,sparcLeadSrc);
	    }
	    
	}
	

	
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_PROPOSER_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_PROPOSER_DETAILS(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String eiaNoAvailable=afterObject.get("EIA_NO_AVAILABLE")+"";
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_PROPOSER_DETAILS(wiName, eiaNoAvailable);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_PROPOSER_DETAILS(wiName, eiaNoAvailable);
	    }
	    
	}
	
	
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_LIST_AGENT_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_LIST_AGENT_DETAILS(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String goCode=afterObject.get("GO_CODE")+"";
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_LIST_AGENT_DETAILS(wiName, goCode);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_LIST_AGENT_DETAILS(wiName, goCode);
	    }
	    
	}
	
	
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_POLICY_VALIDATION_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_POLICY_VALIDATION_DETAILS(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String satrightPassCode=afterObject.get("STRAIGHT_PASS_CASE")+"";
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_POLICY_VALIDATION_DETAILS(wiName, satrightPassCode);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_POLICY_VALIDATION_DETAILS(wiName, satrightPassCode);
	    }
	    
	}
	
	
	
	
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_DEFENCE_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_DEFENCE_DETAILS(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String defenceChannelCase=afterObject.get("DEFENCE_CHANNEL_CASE")+"";
	    String armyNumber=afterObject.get("ARMY_NUMBER")+"";
	    String unitName=afterObject.get("UNIT_NAME")+"";
	    
	    boolean exist=dolphinAppCaseDAO.getAppCaseExistOrNot(wiName);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_DEFENCE_DETAILS(wiName, defenceChannelCase,armyNumber,unitName);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_DEFENCE_DETAILS(wiName, defenceChannelCase,armyNumber,unitName);
	    }
	    
	}
	*/
	
	/*
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_CUSTOMER_INFORMATION"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_DEFENCE_DETAILS(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String custId=afterObject.get("CUSTOMER_ID")+"";
	    String caseId=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String customerSignDate=afterObject.get("CUSTOMER_SIGN_DATE")+"";
	    String replacePolicySale=afterObject.get("REPLACEMENT_POLICY_SALE")+"";
	    String custClassification=afterObject.get("AXIS_CUST_CLASS")+"";
	    boolean exist=dolphinCustomerDeclarationDAO.getAppCaseExistOrNot(caseId);
	    if(!exist) {
	    	dolphinCustomerDeclarationDAO.insert_NG_NB_CUSTOMER_INFORMATION(custId,caseId, customerSignDate, custId, replacePolicySale, custClassification);
	    }else {
	    	dolphinCustomerDeclarationDAO.update_NG_NB_CUSTOMER_INFORMATION(custId,caseId, customerSignDate, custId, replacePolicySale, custClassification);
	    }
	   
	    
	}
	
	
	@KafkaListener(topics = {"dolphinDevServer2.dbo.NG_NB_AGENT_INFORMATION"}, groupId = "console-consumer-44036")
	public void consumeNG_NB_AGENT_INFORMATION(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    boolean exist=false;
		///////////////////////////////////////////////////////APP CASE TABLE EXEC/////////////////////////////////////////
	
        String caseId=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    
        String sp_cert_no=afterObject.get("SP_CERTI_NO")+"";
	    exist=dolphinAppCaseDAO.getAppCaseExistOrNot(caseId);
	    if(!exist) {
	    	dolphinAppCaseDAO.insert_NG_NB_AGENT_INFORMATION(caseId, sp_cert_no);
	    }else {
	    	dolphinAppCaseDAO.update_NG_NB_AGENT_INFORMATION(caseId, sp_cert_no);
	    }
	    
		///////////////////////////////////////////////////////APP CASE TABLE EXEC/////////////////////////////////////////
		
		
		/////////////////////////////////////////////////////CUSTOMER DECLARATION STARTS////////////////////////////////////////
		
	    String mnylSSNCode=afterObject.get("SSN_CODE")+"";
	    String mnylApplicationID=afterObject.get("APPLICATION_ID")+"";
	    String solId=afterObject.get("SOL_ID")+"";
	    String agentSignDate=afterObject.get("AGENT_SIGN_DATE")+"";
	    String wmsSerialNumber=afterObject.get("WMS_SERIAL_NO")+"";
	    exist=dolphinCustomerDeclarationDAO.getAppCaseExistOrNot(caseId);
	    if(!exist) {
	    	dolphinCustomerDeclarationDAO.insert_NG_NB_AGENT_INFORMATION(caseId, mnylSSNCode, mnylApplicationID, solId, agentSignDate,wmsSerialNumber);
	    }else {
	    	dolphinCustomerDeclarationDAO.update_NG_NB_AGENT_INFORMATION(caseId, mnylSSNCode, mnylApplicationID, solId, agentSignDate,wmsSerialNumber);
	    }
       /////////////////////////////////////////////////////CUSTOMER DECLARATION ENDS////////////////////////////////////////
      
	    
	   //////////////////////////////////////////////////////////////CASE AGENT EXEC//////////////////////////////////////////////////// 
	   String agentCode=afterObject.get("AGENT_CODE")+""; 
	   String agentName=afterObject.get("AGENT_NAME")+""; 
	   String commissionShare= afterObject.get("COMMISSION_SHARE")+"";
	   exist=caseAgentDAO.getCaseAgentExistOrNot(caseId);
	   if(!exist) {
		   caseAgentDAO.insert_NG_NB_AGENT_INFORMATION(caseId, agentCode, agentName, commissionShare);
	   }else {
		   caseAgentDAO.update_NG_NB_AGENT_INFORMATION(caseId, agentCode, agentName, commissionShare);
	   }
       //////////////////////////////////////////////////////////////CASE AGENT EXEC//////////////////////////////////////////////////// 
	   
	   ///////////////////////////////////////////////MNYL AGENt START/////////////////////////////////////////////////////////////////
	   String spCrtFktNumber=afterObject.get("SP_CRTFKT_NUMBER")+"";
	   exist=agentDAO.getAgentExistOrNot(agentCode);
	    if(!exist) {
	    	agentDAO.insert_NG_NB_AGENT_INFORMATION(agentCode, spCrtFktNumber);
	    }else {
	    	agentDAO.update_NG_NB_AGENT_INFORMATION(agentCode, spCrtFktNumber);
	    }
      ///////////////////////////////////////////////MNYL  AGENT END/////////////////////////////////////////////////////////////////
	}
	
	
	@KafkaListener(topics = {"dolphinDevServer1.dbo.NG_NB_LIST_AGENT_DETAILS_GRID"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_LIST_AGENT_DETAILS_GRID(@Payload String data) {
		System.out.println(data);
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
		String strAgentCd=afterObject.get("AGENT_CODE")+"";
	    String strAgentName=afterObject.get("AGENT_NAME")+"";
	    String strAgentStatus=afterObject.get("AGENT_STATUS")+"";
	    String goCode=afterObject.get("GO_CODE")+"";
	    String afterJoiningDate=afterObject.get("AGENT_JOINING_DATE")+"";
	    String reportingManagerCode=afterObject.get("REPORTING_MANAGER_CODE")+"";
	    String reportingManagerName=afterObject.get("REPORTING_MANAGER_NAME")+"";
	    String agentContactNumber=afterObject.get("AGENT_CONTACT_NUMBER")+"";
	    String agentEmail=afterObject.get("AGENT_EMAIL")+"";
	    String currentUlipStartDate=afterObject.get("CURR_ULIP_START_DATE")+"";
	    String currentUlipEndDate=afterObject.get("CURR_ULIP_END_DATE")+"";
	    String previousUlipStartDate=afterObject.get("PREV_ULIP_START_DATE")+"";
	    String previousUlipEndDate=afterObject.get("PREV_ULIP_END_DATE")+"";
	    String currentAmlStartDate=afterObject.get("CURR_AML_START_DATE")+"";
	    String currentAmlEndDate=afterObject.get("CURR_AML_END_DATE")+"";
	    String previousAmlStartDate=afterObject.get("PREV_AML_START_DATE")+"";
	    String previousAmlEndDate=afterObject.get("PREV_AML_END_DATE")+"";
	    boolean exist=agentDAO.getAgentExistOrNot(strAgentCd);
	    if(!exist) {
	    	agentDAO.insert_NG_NB_LIST_AGENT_DETAILS_GRID(strAgentCd, strAgentName, strAgentStatus, goCode, afterJoiningDate, reportingManagerCode, reportingManagerName, agentContactNumber, agentEmail, currentUlipStartDate, currentUlipEndDate, previousUlipStartDate, previousUlipEndDate, currentAmlStartDate, currentAmlEndDate, previousAmlStartDate, previousAmlEndDate);
	    }else {
	    	agentDAO.update_NG_NB_LIST_AGENT_DETAILS_GRID(strAgentCd, strAgentName, strAgentStatus, goCode, afterJoiningDate, reportingManagerCode, reportingManagerName, agentContactNumber, agentEmail, currentUlipStartDate, currentUlipEndDate, previousUlipStartDate, previousUlipEndDate, currentAmlStartDate, currentAmlEndDate, previousAmlStartDate, previousAmlEndDate);
	    }
	}
	
	*/
	
	//********************************************************************************************START ARVIND CODE ON DATE 4TH SEP 2020 ***********************************************************************************************************************
	
    //=================================== START ===================:- MNYL_CASE_COVERAGE_DETAILS -: ========================================================================================================================================================
		
		@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_COVERAGE_DETAILS"}, groupId = "console-consumer-44035")
		public void consumeNG_NB_COVERAGE_DETAILS(@Payload String data) {
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
			String wiName=MethodUtil.removeUnRequiredCharacterCaseId( afterObject.get("WI_NAME")+"") ;
			
		    String premiumPayTerm=afterObject.get("PREMIUM_PAY_TERM")+"";
		    String reqModalPremium=afterObject.get("REQ_MODAL_PREMIUM")+"";
		    String coverageTerm=afterObject.get("COVERAGE_TERM")+"";
		    String sumAssured=afterObject.get("SUM_ASSURED")+"";
		    String atp=afterObject.get("ATP")+"";
		    String totalReqPremium=afterObject.get("TOTAL_REQ_PREMIUM")+"";
		    String nonForfeiture=afterObject.get("NON_FORFEITURE")+"";
		    String bonusOption=afterObject.get("BONUS_OPTION")+"";
		    String modeOfPay=afterObject.get("MODE_OF_PAY")+"";
		    String productName=afterObject.get("PRODUCT_NAME")+"";
		    String modalPremium=afterObject.get("MODAL_PREMIUM")+"";
		    String afyp=afterObject.get("AFYP")+"";
		    String vestingAge=afterObject.get("VESTING_AGE")+"";
		    String effectiveDate=afterObject.get("EFFECTIVE_DATE")+"";
		    String deathBenefit=afterObject.get("DEATH_BENEFIT")+"";
		    String gipPayoutDay=afterObject.get("GIP_PAYOUT_DAY")+"";
		    String gipPayoutMethod=afterObject.get("GIP_PAYOUT_METHOD")+"";
		    String smokerClass=afterObject.get("SMOKER_CLASS")+"";
		    String empDiscount=afterObject.get("EMP_DISCOUNT")+"";
		    String guaranteeDeathBenefit=afterObject.get("GUARANTEE_DEATH_BENEFIT")+"";
		    String saveMoreTomorrow=afterObject.get("SAVE_MORE_TOMORROW")+"";
		    String coverageString=afterObject.get("COVERAGE_STRING")+"";
		    String maturityAge=afterObject.get("MATURITY_AGE")+"";
		    String lifeEvent=afterObject.get("LIFE_EVENT")+"";
		    
		    
		    
		    boolean exist=coverageDAO.getCaseIdExistOrNot(wiName);
		    if(!exist) {
		    	coverageDAO.insert_NG_NB_COVERAGE_DETAILS(wiName, premiumPayTerm, reqModalPremium, coverageTerm, sumAssured, atp, totalReqPremium, nonForfeiture, bonusOption, modeOfPay, productName, modalPremium, afyp, vestingAge, effectiveDate, deathBenefit, gipPayoutDay, gipPayoutMethod, smokerClass,empDiscount, guaranteeDeathBenefit, saveMoreTomorrow, coverageString, maturityAge, lifeEvent);
		    }else {
		    	coverageDAO.update_NG_NB_COVERAGE_DETAILS(wiName, premiumPayTerm, reqModalPremium, coverageTerm, sumAssured, atp, totalReqPremium, nonForfeiture, bonusOption, modeOfPay, productName, modalPremium, afyp, vestingAge, effectiveDate, deathBenefit, gipPayoutDay, gipPayoutMethod, smokerClass,empDiscount, guaranteeDeathBenefit, saveMoreTomorrow, coverageString, maturityAge, lifeEvent);
		    }
		}
		
	//=================================== END ===================:- MNYL_CASE_COVERAGE_DETAILS -: ========================================================================================================================================================
	
		@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_FUND_SELECTED"}, groupId = "console-consumer-44035")
		public void consumeNG_NB_FUND_SELECTED(@Payload String data) {
			
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
		    boolean exist=false;
		    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		    String stp=afterObject.get("STP")+"";
		    exist=coverageDAO.getCaseIdExistOrNot(wiName);
		    if(!exist) {
		    	coverageDAO.insert_NG_NB_FUND_SELECTED(wiName,stp);
		    }else {
		    	coverageDAO.update_NG_NB_FUND_SELECTED(stp,wiName);
		    }
		    
		}
	
	
	
		//----------------------------------------------------: Dolphin Table NG_NB_PAYMENT_DETAILS :----------------------------------------------------
		
		@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_PAYMENT_DETAILS"}, groupId = "console-consumer-44035")
		public void consumeNG_NB_PAYMENT_DETAILS(@Payload String data) {
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
		    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		    String bankAccNo=afterObject.get("BANK_ACC_NO")+"";
		    String micrCode=afterObject.get("MICR_CODE")+"";
		    String ifscCode=afterObject.get("IFSC_CODE")+"";
		    String bankName=afterObject.get("BANK_NAME")+"";
		    String initPremPaid=afterObject.get("INIT_PREM_PAID")+"";
		    String initPremMethod=afterObject.get("INIT_PREM_METHOD")+"";
		    String modeOfPay=afterObject.get("MODE_OF_PAY")+"";
		    
		    boolean exist=paymentDAO.paymentDetailoExistOrNot(wiName);
		    if(!exist) {
		    	paymentDAO.insert_NG_NB_PAYMENT_DETAILS(wiName, bankAccNo, micrCode, ifscCode, bankName, initPremPaid, initPremMethod, modeOfPay);
		    }else {
		    	paymentDAO.update_NG_NB_PAYMENT_DETAILS(wiName, bankAccNo, micrCode, ifscCode, bankName, initPremPaid, initPremMethod, modeOfPay);
		    }
		}
		
		//----------------------------------------------------: Dholphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :----------------------------------------------------
	
	
	//----------------------------------------------------: Dholphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :----------------------------------------------------
	
		@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_RENEWAL_PREMIUM_DETAILS"}, groupId = "console-consumer-44035")
		public void consumeNG_NB_RENEWAL_PREMIUM_DETAILS(@Payload String data) {
			JSONObject parentObject=new JSONObject(data);
	    	JSONObject payload=parentObject.getJSONObject("payload");
		    JSONObject afterObject=payload.getJSONObject("after");
		    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
		    String bankAccountNumber=afterObject.get("BANK_ACCOUNT_NUMBER")+"";
		    String micrCode=afterObject.get("MICR_CODE")+"";
		    String ifscCode=afterObject.get("IFSC_CODE")+"";
		    String bankNameBranch=afterObject.get("BANK_NAME_BRANCH")+"";
		    String billDrawDate1=afterObject.get("BILL_DRAW_DATE1")+"";
		    String ccExpiryDate=afterObject.get("CC_EXPIRY_DATE")+"";
		    String ccNo=afterObject.get("CC_NO")+"";
		    String payorSameProp=afterObject.get("PAYOR_SAME_PROP")+"";
		    String typeOfAccount=afterObject.get("TYPE_OF_ACCOUNT")+"";
		    String ccHolderName=afterObject.get("CC_HOLDER_NAME")+"";
		    String accountHolderName=afterObject.get("ACCOUNT_HOLDER_NAME")+"";
		    String renewalPremiumMethod=afterObject.get("RENEWAL_PREM_METHOD")+"";
		    
		    boolean exist=paymentDAO.paymentDetailoExistOrNot(wiName);
		    if(!exist) {
		    	paymentDAO.insert_NG_NB_RENEWAL_PREMIUM_DETAILS(wiName,bankAccountNumber, micrCode, ifscCode, bankNameBranch, billDrawDate1, ccExpiryDate, ccNo, payorSameProp, typeOfAccount, ccHolderName, accountHolderName,renewalPremiumMethod);
		    }else {
		    	paymentDAO.update_NG_NB_RENEWAL_PREMIUM_DETAILS(bankAccountNumber, micrCode, ifscCode, bankNameBranch, billDrawDate1, ccExpiryDate, ccNo, payorSameProp, typeOfAccount, ccHolderName, accountHolderName,renewalPremiumMethod,wiName);
		    }
		}
		
		
	 //----------------------------------------------------: Dholphin Table NG_NB_RENEWAL_PREMIUM_DETAILS :----------------------------------------------------
	
	@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_NEFT_DETAILS"}, groupId = "console-consumer-44035")
	public void consumeNG_NB_NEFT_DETAILS(@Payload String data) {
		JSONObject parentObject=new JSONObject(data);
    	JSONObject payload=parentObject.getJSONObject("payload");
	    JSONObject afterObject=payload.getJSONObject("after");
	    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
	    String accNoNeft=afterObject.get("ACC_NO_NEFT")+"";
	    String micrNeft=afterObject.get("MICR_NEFT")+"";
	    String holderNameNeft=afterObject.get("HOLDER_NAME_NEFT")+"";
	    String ifscNeft=afterObject.get("IFSC_NEFT")+"";
	    String nameBranchNeft=afterObject.get("NAME_BRANCH_NEFT")+"";
	    String typeOfAccNeft=afterObject.get("TYPE_OF_ACC_NEFT")+"";
	    
	    boolean exist=paymentDAO.paymentDetailoExistOrNot(wiName);
	    if(!exist) {
	    	paymentDAO.insert_NG_NB_NEFT_DETAILS(wiName,accNoNeft, micrNeft, holderNameNeft, ifscNeft, nameBranchNeft, typeOfAccNeft);
	    }else {
	    	paymentDAO.update_NG_NB_NEFT_DETAILS(accNoNeft, micrNeft, holderNameNeft, ifscNeft, nameBranchNeft, typeOfAccNeft,wiName);
	    }
	}
	
//******************************** -:- STARTS -:- *******************************************-: Development by Arvind on date 9th SEP 2020 :- ***************************************************************************************************************************
	
	//=================================== -:- START-:-====================-:- MNYL_RIDER_DETAILS -:- ========================================================================================================================================================
	
			@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_LIST_RIDER_DETAILS"}, groupId = "console-consumer-44035")
			public void consumeNG_NB_LIST_RIDER_DETAILS(@Payload String data) {
				JSONObject parentObject=new JSONObject(data);
		    	JSONObject payload=parentObject.getJSONObject("payload");
			    JSONObject afterObject=payload.getJSONObject("after");
			    
			    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
			    String coverageTerm=afterObject.get("COVERAGE_TERM")+""; 
			    String sumAssured=afterObject.get("SUM_ASSURED")+"";
			    String modalPremium=afterObject.get("MODAL_PREMIUM")+"";
			    String insuredDetails=afterObject.get("INSURED_DETAILS")+"";
			    String riderType=afterObject.get("RIDER_TYPE")+"";
			    String gst=afterObject.get("GST")+"";
			    
			  
			    
			    
			    boolean exist=riderDetailsDAO.getCaseDetailIdExistOrNot(wiName);
			    if(!exist) {
			    	riderDetailsDAO.insert_NG_NB_LIST_RIDER_DETAILS(wiName,coverageTerm,sumAssured,modalPremium,insuredDetails,riderType,gst);
			    }else {
			    	riderDetailsDAO.update_NG_NB_LIST_RIDER_DETAILS(wiName,coverageTerm,sumAssured,modalPremium,insuredDetails,riderType,gst);
			    }
			}
			

	//=================================== -:- END -:- ====================-:- MNYL_RIDER_DETAILS -:- ========================================================================================================================================================

	
	//=================================== -:- START-:-====================-:- MNYL_RIDER_DETAILS -:- ========================================================================================================================================================
			
			@KafkaListener(topics = {"dolphinDevServer.dbo.CASE_REQT"}, groupId = "console-consumer-44035")
			public void consumeCASE_REQT(@Payload String data) {
				JSONObject parentObject=new JSONObject(data);
		    	JSONObject payload=parentObject.getJSONObject("payload");
			    JSONObject afterObject=payload.getJSONObject("after");
			    
			    String requirementName=afterObject.get("REQUIREMENT_NAME")+""; 
			    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
			    String reqStatus=afterObject.get("REQ_STATUS")+""; 
			    String orderedDate=afterObject.get("ORDERED_DATE")+"";
			    String receivedDate=afterObject.get("RECEIVED_DATE")+"";
			    
			  
			    boolean exist=caseReqtDAO.getCaseIdExistOrNot(wiName);
			    if(!exist) {
			    	caseReqtDAO.insert_CASE_REQT(requirementName,wiName,reqStatus,orderedDate,receivedDate);
			    }else {
			    	caseReqtDAO.update_CASE_REQT(requirementName,wiName,reqStatus,orderedDate,receivedDate);
			    }
			}
			

	//=================================== -:- END -:- ====================-:- MNYL_RIDER_DETAILS -:- ========================================================================================================================================================


//******************************** -:- ENDS -:- *******************************************-: Development by Arvind on date 9th SEP 2020 :- ***************************************************************************************************************************


//******************************** -:- STARTS -:- *******************************************-: Development by Arvind on date 11th SEP 2020 :- ***************************************************************************************************************************


	//=================================== -:- START -:- ====================-:- MNYL_CASE_UW_DECN -:- ========================================================================================================================================================

			@KafkaListener(topics = {"dolphinDevServer.dbo.NG_NB_DECISION_SECTION_UW"}, groupId = "console-consumer-44035")
			public void consumeNG_NB_DECISION_SECTION_UW(@Payload String data) {
				JSONObject parentObject=new JSONObject(data);
		    	JSONObject payload=parentObject.getJSONObject("payload");
			    JSONObject afterObject=payload.getJSONObject("after");
			    
			    String wiName=MethodUtil.removeUnRequiredCharacterCaseId(afterObject.get("WI_NAME")+"");
			    String smokerClassRevised=afterObject.get("SMOKER_CLASS_REVISED")+""; 
			    String totalPremium=afterObject.get("TOTAL_PREMIUM")+"";
			    String assessedIncome=afterObject.get("ASSESSED_INCOME")+"";
			    
			    
			  
			    boolean exist=caseUwDecnDAO.getCaseIdExistOrNot(wiName);
			    if(!exist) {
			    	caseUwDecnDAO.insert_NG_NB_DECISION_SECTION_UW(wiName,smokerClassRevised,totalPremium,assessedIncome);
			    }else {
			    	caseUwDecnDAO.update_NG_NB_DECISION_SECTION_UW(wiName,smokerClassRevised,totalPremium,assessedIncome);
			    }
			}
			

	//=================================== -:- END -:- ====================-:- MNYL_CASE_UW_DECN -:- ========================================================================================================================================================

			
//******************************** -:- ENDS -:- *******************************************-: Development by Arvind on date 11th SEP 2020 :- ***************************************************************************************************************************

	
}

	

