package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;
import com.dolphin.cdcDataMigration.util.MethodUtil;

@Service
public class CoverageDAO {


	private final Logger logger = LoggerFactory.getLogger(DolphinAppCaseDAO.class);

	@Autowired
	DolphinConfiguration  dolphinConfiguration;
	
	public boolean getCaseIdExistOrNot(String wiName) {
	
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_CASE_ID);
	    	pstmt.setString(counter, wiName);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("MNYL_CASE_ID Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	
	public void insert_NG_NB_COVERAGE_DETAILS(String wiName,String premiumPayTerm,String reqModalPremium,
			String coverageTerm,String sumAssured,String atp,String totalReqPremium,String nonForfeiture,
			String bonusOption,String modeOfPay,String productName,String modalPremium,String afyp,
			String vestingAge,String effectiveDate,String deathBenefit,String gipPayoutDay,String gipPayoutMethod,
			String smokerClass,String empDiscount, String guaranteeDeathBenefit,String saveMoreTomorrow,
			String coverageString,String maturityAge, String lifeEvent) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_COVERAGE_DETAILS);
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer premiumPayTermInt=MethodUtil.StringToIntConverter(wiName);
	        Integer sumAssuredInt=MethodUtil.StringToIntConverter(sumAssured);
	        Integer totalReqPremiumInt=MethodUtil.StringToIntConverter(totalReqPremium);
	        Integer modeOfPayInt=MethodUtil.StringToIntConverter(modeOfPay);
	        Integer productNameInt=MethodUtil.StringToIntConverter(productName);
	        Integer modalPremiumInt=MethodUtil.StringToIntConverter(modalPremium);
	        Integer afypInt=MethodUtil.StringToIntConverter(afyp);
	        Integer vestingAgeInt=MethodUtil.StringToIntConverter(vestingAge);
	        Long effectiveDateInt=MethodUtil.StringToLongConverter(effectiveDate);
	        Integer guaranteeDeathBenefitInt=MethodUtil.StringToIntConverter(guaranteeDeathBenefit);
	        
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);
	        }
	          if(premiumPayTermInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,premiumPayTermInt);
	        }
	        pstmt.setString(counter++,reqModalPremium);
	        pstmt.setString(counter++,coverageTerm);
	        
	        if(sumAssuredInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,sumAssuredInt);	
	        }
	        
	        
	        
	        pstmt.setString(counter++,atp);
	        
	        if(totalReqPremiumInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,totalReqPremiumInt);	
	        }
	        
	        pstmt.setString(counter++,nonForfeiture);
	        
	        pstmt.setString(counter++,bonusOption);
	        
	        
	        if(modeOfPayInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,modeOfPayInt);	
	        }
	        
	        if(productNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,productNameInt);	
	        }
	        
	        if(modalPremiumInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,modalPremiumInt);	
	        }
	        
	        if(afypInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,afypInt);	
	        }
	        
	        if(vestingAgeInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,vestingAgeInt);	
	        }
	        
	        
	        if(effectiveDateInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(effectiveDateInt));
	        }
	        
	        pstmt.setString(counter++,deathBenefit);
	        pstmt.setString(counter++,gipPayoutDay);
	        pstmt.setString(counter++,gipPayoutMethod);
	        
	        pstmt.setString(counter++,smokerClass);
	        pstmt.setString(counter++,empDiscount);
	        
	        if(guaranteeDeathBenefitInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,guaranteeDeathBenefitInt);
	        }
	        
	        pstmt.setString(counter++,saveMoreTomorrow);
	        pstmt.setString(counter++,coverageString);
	        pstmt.setString(counter++,maturityAge);
	        pstmt.setString(counter++,lifeEvent);
	       
	        pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_COVERAGE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_COVERAGE_DETAILS(String wiName,String premiumPayTerm,String reqModalPremium,
			String coverageTerm,String sumAssured,String atp,String totalReqPremium,String nonForfeiture,
			String bonusOption,String modeOfPay,String productName,String modalPremium,String afyp,
			String vestingAge,String effectiveDate,String deathBenefit,String gipPayoutDay,String gipPayoutMethod,
			String smokerClass,String empDiscount, String guaranteeDeathBenefit,String saveMoreTomorrow,
			String coverageString,String maturityAge, String lifeEvent) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_COVERAGE_DETAILS);
	        
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer premiumPayTermInt=MethodUtil.StringToIntConverter(wiName);
	        Integer sumAssuredInt=MethodUtil.StringToIntConverter(sumAssured);
	        Integer totalReqPremiumInt=MethodUtil.StringToIntConverter(totalReqPremium);
	        Integer modeOfPayInt=MethodUtil.StringToIntConverter(modeOfPay);
	        Integer productNameInt=MethodUtil.StringToIntConverter(productName);
	        Integer modalPremiumInt=MethodUtil.StringToIntConverter(modalPremium);
	        Integer afypInt=MethodUtil.StringToIntConverter(afyp);
	        Integer vestingAgeInt=MethodUtil.StringToIntConverter(vestingAge);
	        Integer effectiveDateInt=MethodUtil.StringToIntConverter(effectiveDate);
	        Integer guaranteeDeathBenefitInt=MethodUtil.StringToIntConverter(guaranteeDeathBenefit);
	        
	        
	          if(premiumPayTermInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,premiumPayTermInt);
	        }
	        pstmt.setString(counter++,reqModalPremium);
	        pstmt.setString(counter++,coverageTerm);
	        
	        if(sumAssuredInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,sumAssuredInt);	
	        }
	        
	        
	        
	        pstmt.setString(counter++,atp);
	        
	        if(totalReqPremiumInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,totalReqPremiumInt);	
	        }
	        
	        pstmt.setString(counter++,nonForfeiture);
	        
	        pstmt.setString(counter++,bonusOption);
	        
	        
	        if(modeOfPayInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,modeOfPayInt);	
	        }
	        
	        if(productNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,productNameInt);	
	        }
	        
	        if(modalPremiumInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,modalPremiumInt);	
	        }
	        
	        if(afypInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,afypInt);	
	        }
	        
	        if(vestingAgeInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,vestingAgeInt);	
	        }
	        
	        
	        if(effectiveDateInt==null) {
	        	pstmt.setNull(counter++,Types.DATE);
	        }else {
	        	pstmt.setTimestamp(counter++,new Timestamp(effectiveDateInt));
	        }
	        
	        pstmt.setString(counter++,deathBenefit);
	        pstmt.setString(counter++,gipPayoutDay);
	        pstmt.setString(counter++,gipPayoutMethod);
	        
	        pstmt.setString(counter++,smokerClass);
	        pstmt.setString(counter++,empDiscount);
	        
	        if(guaranteeDeathBenefitInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++,guaranteeDeathBenefitInt);
	        }
	        
	        pstmt.setString(counter++,saveMoreTomorrow);
	        pstmt.setString(counter++,coverageString);
	        pstmt.setString(counter++,maturityAge);
	        pstmt.setString(counter++,lifeEvent);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setNull(counter++,wiNameInt);
	        }
	        pstmt.execute();
	       
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_COVERAGE_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	

	public void insert_NG_NB_FUND_SELECTED(String wiName,String stp) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_FUND_SELECTED);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);;	
	        }
	        pstmt.setString(counter++,stp);
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_FUND_SELECTED Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_FUND_SELECTED(String stp,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_FUND_SELECTED);
	        pstmt.setString(counter++, stp);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,wiNameInt);
	        }
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_FUND_SELECTED Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void insert_NG_NB_EXT_TABLE1(String wiName,String adjustedAfyp,String adjustedMfyp) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
			conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_EXT_TABLE1);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++, Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	        pstmt.setString(counter++,adjustedAfyp);
	        pstmt.setString(counter++, adjustedMfyp);
	    	pstmt.execute();
	    	
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_EXT_TABLE1 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_EXT_TABLE1(String adjustedAfyp,String adjustedMfyp,String wiName) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
			Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_EXT_TABLE1);
	        pstmt.setString(counter++, adjustedAfyp);
	        pstmt.setString(counter++, adjustedMfyp);
	        if(wiNameInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);	
	        }else {
	        	pstmt.setInt(counter++, wiNameInt);
	        }
	        
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_EXT_TABLE1 Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	
	
	
	public void insert_NG_NB_SUC_PARAMETERS(String fsa,String msa) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_SUC_PARAMETERS);
	        pstmt.setString(counter++, fsa);
	        pstmt.setString(counter++, msa);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_SUC_PARAMETERS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	public void update_NG_NB_SUC_PARAMETERS(String fsa,String msa) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_SUC_PARAMETERS);
	        pstmt.setString(counter++, fsa);
	        pstmt.setString(counter++, msa);
	    	pstmt.execute();
	    }catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_SUC_PARAMETERS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	


}
