package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;
import com.dolphin.cdcDataMigration.util.MethodUtil;

public class RiderDetailsDAO {
	
	private final Logger logger=LoggerFactory.getLogger(DolphinAppCaseDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration;

	public boolean getCaseDetailIdExistOrNot(String wiName) {
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_CASE_MNYL_DETAIL_ID);
	    	pstmt.setString(counter, wiName);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("SELECT_MNYL_CASE_MNYL_DETAIL_ID Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}

	public void insert_NG_NB_LIST_RIDER_DETAILS(String wiName, String coverageTerm,
			String sumAssured, String modalPremium, String insuredDetails, String riderType, String gst) {
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_NG_NB_LIST_RIDER_DETAILS);
	        
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer sumAssuredInt=MethodUtil.StringToIntConverter(sumAssured);
	        Integer modalPremiumInt=MethodUtil.StringToIntConverter(modalPremium);
	        Integer gstInt=MethodUtil.StringToIntConverter(gst);
	        
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter,coverageTerm);
	        
	        if(sumAssuredInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,sumAssuredInt);	
	        }
	        
	        if(modalPremiumInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,modalPremiumInt);	
	        }
	        
	        pstmt.setString(counter,insuredDetails);
	        pstmt.setString(counter,riderType);
	        
	        if(gstInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,gstInt);	
	        }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("INSERT_NG_NB_LIST_RIDER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
	}

	public void update_NG_NB_LIST_RIDER_DETAILS(String wiName, String coverageTerm,
			String sumAssured, String modalPremium, String insuredDetails, String riderType, String gst) {
		// TODO Auto-generated method stub
		
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_NG_NB_LIST_RIDER_DETAILS);
	      
	        Integer wiNameInt=MethodUtil.StringToIntConverter(wiName);
	        Integer sumAssuredInt=MethodUtil.StringToIntConverter(sumAssured);
	        Integer modalPremiumInt=MethodUtil.StringToIntConverter(modalPremium);
	        Integer gstInt=MethodUtil.StringToIntConverter(gst);
	        
	        if(wiNameInt==null) {
		      pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, wiNameInt);
		    }
	        
	        pstmt.setString(counter,coverageTerm);
	        
	        if(sumAssuredInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,sumAssuredInt);	
	        }
	        
	        if(modalPremiumInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,modalPremiumInt);	
	        }
	        
	        pstmt.setString(counter,insuredDetails);
	        pstmt.setString(counter,riderType);
	        
	        if(gstInt==null) {
	        	pstmt.setNull(counter++,Types.INTEGER);
	        }else {
	        	pstmt.setInt(counter++,gstInt);	
	        }
	        
	        pstmt.execute();
	        
		}catch(Exception ec) {
	    	logger.error("UPDATE_NG_NB_LIST_RIDER_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		
	}

}
