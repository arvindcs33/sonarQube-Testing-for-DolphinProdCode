package com.dolphin.cdcDataMigration.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dolphin.cdcDataMigration.serviceImpl.DolphinTablesTopicListener;

public class MethodUtil {

	private static final Logger logger = LoggerFactory.getLogger(DolphinTablesTopicListener.class);
	
	public static String removeUnRequiredCharacterCaseId(String caseId) {
	     if(caseId==null || "".equals(caseId) || "null".equals(caseId)) {
	    	 return caseId;
	     }
		
		String tempCaseId=caseId;
		tempCaseId=tempCaseId.replaceAll("-", "");
		tempCaseId=tempCaseId.replaceAll("NB", "");
		tempCaseId=tempCaseId.replaceAll("Dolphin", "");
		return tempCaseId;
	}
	
   public static Integer StringToIntConverter(String input) {
	   Integer returnVal=null;
	   if(input==null || "".equals(input.trim())) {
		   return null;
	   }
	   try {
		   returnVal=Integer.parseInt(input);
	   }catch(Exception ec) {
		   logger.error("Exception while converting String to Number",ec);
		   returnVal=null;
	   }
	   return returnVal;
   }
   
   public static Long StringToLongConverter(String input) {
	   
	   Long returnVal=null;
	   if(input==null || "".equals(input.trim())) {
		   return null;
	   }
	   try {
		   returnVal=Long.parseLong(input);
	   }catch(Exception ec) {
		   logger.error("Exception while converting String to Long",ec);
		   returnVal=null;
	   }
	   return returnVal;
   }
}
