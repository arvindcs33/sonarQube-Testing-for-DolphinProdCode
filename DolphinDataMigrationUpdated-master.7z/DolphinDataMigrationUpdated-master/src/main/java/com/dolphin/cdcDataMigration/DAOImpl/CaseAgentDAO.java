package com.dolphin.cdcDataMigration.DAOImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.cdcDataMigration.DolphinConfiguration;
import com.dolphin.cdcDataMigration.util.DPHConstants;

@Service
public class CaseAgentDAO {

	private final Logger logger = LoggerFactory.getLogger(CaseAgentDAO.class);
	
	@Autowired
	DolphinConfiguration dolphinConfiguration; 
	
	public boolean getCaseAgentExistOrNot(String wiName) {
		
		boolean returnOut=false;
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
	    	int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	    	pstmt=conn.prepareStatement(DPHConstants.SELECT_MNYL_CASE_AGENT);
	    	pstmt.setString(counter, wiName);
	    	ResultSet rset=pstmt.executeQuery();
	    	if(rset.next()) {
	    		returnOut=true;
	    	}
	    }catch(Exception ec) {
	    	logger.error("NG_NB_CEIP_DETAILS Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
		
		return returnOut;
	}
	
	
	public void insert_NG_NB_AGENT_INFORMATION(String wiName,String agentCode,String agentName,String commissionShare) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try {
			
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.INSERT_CA_NG_NB_AGENT_INFORMATION);
	    	if("null".equals(wiName)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(wiName));
		    }
	    	pstmt.setString(counter++, agentCode);
	    	pstmt.setString(counter++, agentName);
	    	if("null".equals(commissionShare)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(commissionShare));
		    }
	    	
	    	pstmt.execute();
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
	public void update_NG_NB_AGENT_INFORMATION(String wiName,String agentCode,String agentName,String commissionShare) {
		Connection conn=null;
	    PreparedStatement pstmt=null;
		try 
		{
			int counter=1;
	    	conn= dolphinConfiguration.getDolphinConnection();
	        pstmt=conn.prepareStatement(DPHConstants.UPDATE_CA_NG_NB_AGENT_INFORMATION);
	    	pstmt.setString(counter++, agentCode);
	    	pstmt.setString(counter++, agentName);
	    	if("null".equals(commissionShare)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(commissionShare));
		    }
	    	
	    	if("null".equals(wiName)) {
		    	pstmt.setNull(counter++, Types.INTEGER);	
		    }else {
		      pstmt.setInt(counter++, Integer.parseInt(wiName));
		    }
	    	
	    	
	    	
	    }catch(Exception ec) {
	    	logger.error("NG_NB_AGENT_INFORMATION Error",ec);
	    }
	    finally {
	    	if(conn!=null) {
	    		try {
	    		conn.close();
	    		}catch(Exception ec) {
	    			logger.error("error while closing the connection",ec);
	    		}
	    		
	    	}
	    	if(pstmt!=null) {
	    	    try {
	    		   pstmt.close();
		    	}catch(Exception ec) {
		    		logger.error("error while closing the connection",ec);
		    	}
	    	}
	    }
	}
	
	
}
