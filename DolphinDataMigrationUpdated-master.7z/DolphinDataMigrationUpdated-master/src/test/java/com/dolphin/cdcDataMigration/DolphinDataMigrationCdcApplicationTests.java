package com.dolphin.cdcDataMigration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DolphinDataMigrationCdcApplicationTests {

	@Test
	void contextLoads() {
	}

}
